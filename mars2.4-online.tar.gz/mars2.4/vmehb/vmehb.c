/* add CONTRIBUTIONS or CONT_UPD here */

/*
    vmehb - VME bus driver of PCI/VME bus adaptor Model 616-618 of Bit3.
    --------------------------------------------------------------------
    Copyright (C) May 1997  Natalia Kruszynska <natalia@nikhef.nl>
    Sponsored and instigated by 
	NIKHEF - Amsterdam
	DESY   - Hamburg
    within the technical support of Hermes Collaboration in Physics.

    Thanks for contribution in alphabetical order to:
	A.J.Aranyosi	<aja@mit.edu> for a neat 2.2 port
	Thomas Bogend	<tsbogend@alpha.franken.de> DMA on alpha PC
	Andries Brouwer <aeb@cwi.nl>
	Dave Cattermole <dmc@mrc-lmb.cam.ac.uk> testing it on alpha PC
	David Chrisman  <David.Chrisman@cern.ch> extensions for Model 618
	Marcin Dalecki  <dalecki@math.uni-goettingen.de> 
	Jay Estabrook   <jay@digital.com> DMA on alpha PC
	Lisa. G.Gorn	<gorn@phys.ufl.edu> for 618/2.2 updates and tests
	David Grothe	<dave@gcom.com>
	Eric Kasten     <kasten@ncsl.msu.edu> for a neat 2.1.90+ version
                        (grab it if you can run beta Linux)

        H.J Mathes      < mathes@ik3.fzk.de> byte access and byte spaces
	Hiroyuki Okamura<okamura@phy.saitama-u.ac.jp> (interrupts)
	Henk Peek	<henkp@nikhef.nl> 
        Klaus Schossmaier<Klaus.Schossmaier@cern.ch>
	Ruud van Wijk   <ruud@nikhef.nl>

    and to  these who are not yet listed here  and who have caught
    some hidden bug and send it to me. 

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
*/
/*
    CONTENTS:  main body of the driver
	also small dependence on system flags , as 2.1 have
	changed typer of parameters in file_operations...
	Because of changes in syscalls - every one of
	FILE_OPERATIONS is preceeded by the comment of the
	form
	== SYSCALL =====================================
/*
 * The following  prefixes are consequently used in the code:
 *	vme_		- configuration data of a vme space
 *	bit3_		- device  structure members
 *	uio_		- request structure members (UNIX hickup)
 *	mmap_		- mmap structure members (mmap call )
 *	vmehb_		- big routines of the driver 
 *	Va_		- base auxiliary routines (vmehb_aux.c)
 *	Vm_		- semaphoring & setup inlines (vme_conf.h)
 *	Bit3_		- hardware access inline primitives (bit3_reg.h)
 *	set_		- internal tracing functions, mostly inactive
 */

#include	"vmehb_conf.h"
#include	"vmehb_aux.c"
/* --- predefinitions of the functions ---------------------------*/
static int vmehb_dev_access(int cminor,unsigned int vme_addr,char *buf,unsigned int count,int rw);


/* --- FILE OPERATIONS  ------------------------------------------*/

/* === LSEEK =====================================================*/
/* lseek   is  implemented on 2_0 because of int count parameter!! */
#ifdef	LIN2_0

static int vmehb_lseek(struct inode * inode, struct file * file, off_t offset, int orig)
{
	/* we have to put it to deal with 32 bits offset of vme32	*/
	file->f_pos = offset;
	return(0);
}
#endif
/* === READ ======================================================*/
#ifdef	LIN2_1_27
#ifdef LIN2_2
static ssize_t vmehb_read(struct file *file,char *buf
					,size_t count,loff_t *ppos)
#else
static long vmehb_read(struct inode *node,struct file *file,char *buf
					, unsigned long count)
#endif
#endif
#ifdef	LIN2_0
static int vmehb_read(struct inode *node,struct file *file,char *buf
					, int count)
#endif
{
	return(vmehb_dev_access(vme_minor,(unsigned int)(file->f_pos),buf,
		(unsigned int)count,VME_READ));
} /* end vmehb_read() */

/* === WRITE =====================================================*/
#ifdef LIN2_1_27
#ifdef	LIN2_2
static ssize_t vmehb_write(struct file *file,const char *buf
					,size_t count,loff_t *ppos)
#else
static int vmehb_write(struct inode *node,struct file *file,const char *buf
			,unsigned long count)
#endif
#endif
#ifdef LIN2_0
static int vmehb_write(struct inode *node,struct file *file,const char *buf
			,int count)
#endif
{
	return(vmehb_dev_access(vme_minor ,(unsigned int)(file->f_pos)
		,buf, (unsigned int)count,VME_WRITE));
} /* end vmehb_write() */

/* === MMAP ======================================================*/
#ifdef LIN2_2
static int vmehb_mmap(struct file *file
				,struct vm_area_struct *vma)
#else
static int vmehb_mmap(struct inode *node,struct file *file
				,struct vm_area_struct *vma)
#endif
{
	int err,size,PCIoff;
	/* MMAP implementation:
	** I do not allow programs to mmap when we are running
	** DMA access, because we can not prevent the Adaptor
	** Cable to be accessed by the mapping tasks during DMA.
	** I assume that the Manager decides on one mode at
        ** a time. The community of Linux hackers is challenged 
	** to find the solution allowing mapped pages to "hang on" 
	** waiting  for DMA done instead of waiting for 
	** "swap back" ;-)))  (I am not a hacker, I am a real time 
	** programmer.... I don't d(c)are )
	**      (C)		May 97 <natalia@nikhef.nl>
	*/
	/*
	** current notes: limitation to slow or check modes removed
	** for the test time:
	if(bit3_slow_control == 0 && bit3_pio_delay == 0)
		return(-ENODEV);
	*/
	Vm_down(&bit3_sem); 	/* SEM */
	// VME_WRITE forces the check to be done incl the hardest verify...
#	ifdef LIN2_4		/* for new <linux/mm.h>, H. Okamura */
	err = Va_check_access((u32)(vma->vm_pgoff * PAGE_SIZE),(char *)0,0x1000,VME_WRITE,vme_minor);
#	else
	err = Va_check_access((u32)(vma->vm_offset),(char *)0,0x1000,VME_WRITE,vme_minor);
#	endif	/* LIN2_4 */
	if(err)
	{
		Vm_up(&bit3_sem); 	/* SEM */
		return(err);
	}
	size = vma_get_end(vma) - vma_get_start(vma);
#	ifdef LIN2_4			/* for new <linux/mm.h>, H. Okamura */
	if((err = Va_map_map((u32)(vma->vm_pgoff * PAGE_SIZE),size)) < 0)
#	else
	if((err = Va_map_map((u32)(vma->vm_offset),size)) < 0)
#	endif	/* LIN2_4 */
	{
		Vm_up(&bit3_sem); 	/* SEM */
		return(err);
	}
	PCIoff	= err * 0x1000;
	/* take care for alphas !!! */
	/* trial correction for smp machines (debug) !!! */
	if((remap_page_range(vma_get_start(vma)
			   ,bit3_hard3 + PCIoff
			   //,Vm_remap(bit3_hard3 + PCIoff,size)
			   ,size
			   ,vma_get_page_prot(vma))))
	{
		Vm_up(&bit3_sem); 	/* SEM */
		return(-ENOMEM);
	}
	/* if head				*/
	if(bit3_first == (struct vme_frag *)0)
	{
		bit3_first = (struct vme_frag *)kmalloc(sizeof(struct vme_frag)
					,GFP_KERNEL);
		BIT3_TRACE(("vmehb: set head for mmap to %x\n",bit3_first));
		bit3_next = bit3_first;
		if(bit3_first == (struct vme_frag *)0)
		{
			Vm_up(&bit3_sem); 	/* SEM */
			printk("vmehb: Cannot alloc list head for map\n");
			return(-EIO);
		}
	}
	else
	{
		bit3_next->next = (struct vme_frag *)kmalloc(sizeof(struct vme_frag)
					,GFP_KERNEL);
		BIT3_TRACE(("vmehb: set next for mmap to %x\n",bit3_next->next));
		if(bit3_next->next == (struct vme_frag *)0)
		{
			Vm_up(&bit3_sem); 	/* SEM */
			printk("vmehb: Cannot alloc list slot for map\n");
			return(-EIO);
		}
		bit3_next	= bit3_next->next;
	}
	bit3_next->pid	= current->pid;
#	ifdef LIN2_4			/* for new <linux/mm.h>, H. Okamura */
	bit3_next->vadr = vma->vm_pgoff * PAGE_SIZE;
#	else
	bit3_next->vadr = vma->vm_offset;
#	endif	/* LIN2_4 */
	bit3_next->from	= uio_n_map;
	bit3_next->pages= uio_n_len;
	bit3_next->next	= (struct vme_frag *)0;
	// Vm_list_maps();
//  A.J.Aranyosi proposed to reconstruct node parameter but
//  Eric Kasten have added the following cute correction
#ifdef LIN2_2
	//vma->vm_file = file; 	
	//file->f_count++;
#else
	vma_set_inode(vma,node);
	inode_inc_count(node);
#endif
	Vm_up(&bit3_sem); 				/* SEM */
	return(0);
} /* end vmehb_mmap() */

/* === IOCTL =====================================================*/
static int vmehb_ioctl(struct inode *node,struct file *file,
			unsigned int cmd, unsigned long arg)
{
	int size,err;
	long argval;
	struct	irq_data	 idata,*idp;
	struct	vme_irq	*vip;
	vme_dev_p = (struct vme_dev	*)&(vme_config[vme_minor]);
	size = _IOC_SIZE(cmd);
	switch(cmd) {
	case	VME_IRQ_ACK: 	/* IOCTL  b 13 */
		idp = &idata;
		err = verify_area(VERIFY_READ ,(char *)arg,size);
		if(err)
			return(err);
		Vm_down(&bit3_sem);		/* SEM */
		Vm_copy_from_user((char *)idp,(char *)arg,size);
		bit3_acks_pending(idp->level)--;
VMEHB1_TRACE(("vmehb: ACK level %d pending %d\n",idp->level,bit3_acks_pending (idp->level)));
		if(bit3_acks_pending(idp->level) <= 0)
		{
			bit3_acks_pending(idp->level) = 0;
			bit3_VME_irq_allow &= (1 < idp->level);
		}
		if(!bit3_VME_irq_allow)
		{
			// enable remote itnerrupt transfer
			Bit3_vme_intr(bit3_base0,1);
		}
		Vm_up(&bit3_sem);			/* SEM */
		return(0);
	case	VME_IRQ_REQUEST: /* IOCTL b 14 */
		idp = &idata;
		err = verify_area(VERIFY_READ ,(char *)arg,size);
		if(err)
			return(err);
		Vm_down(&bit3_sem);		/* SEM */
		Vm_copy_from_user((char *)idp,(char *)arg,size);
		vip = Va_vme_find_irq(idp->level,idp->vector,NULL,NULL);
		if(vip == (VIP)0 || idp->sig == 0)
		{
			Vm_up(&bit3_sem);			/* SEM */
			return(-EINVAL);
		}
		
		vip->sig      = idp->sig;
		vip->task     = current;
		vip->response = idp->response;
		if(idp->response)
		{
			printk("vmehb: request RORA service  of level %d by %d\n");
		}
		Va_vme_mkfrom_irq(vip);
		Vm_up(&bit3_sem);			/* SEM */
		return(0);
	case	VME_IRQ_FREE:	/* IOCTL b 15 */
		idp = &idata;
		Vm_check_suser;
		err = verify_area(VERIFY_READ ,(char *)arg,size);
		if(err)
			return(err);
		Vm_down(&bit3_sem);		/* SEM */
		Vm_copy_from_user((char *)idp,(char *)arg,size);
		Va_vme_free_irq(idp->level,idp->vector,idp->handler);
		Vm_up(&bit3_sem);			/* SEM */
		return(0);
	case	VME_IRQ_CLEAR:	/* IOCTL b 16 */
		Vm_down(&bit3_sem);		/* SEM */
		Va_vme_clear_irq();
		Vm_up(&bit3_sem);			/* SEM */
		return(0);
	case	VME_IRQ_LIST:	/* IOCTL b 17 */
		Vm_down(&bit3_sem);		/* SEM */
		Va_vme_list_irq();
		Vm_up(&bit3_sem);			/* SEM */
		return(0);
	case	VME_GET_SPACE:  /* IOCTL b 0 */
		err = verify_area(VERIFY_WRITE,(void *)arg,size);
		if(err)
			return(err);
		Vm_copy_to_user((char *)arg,(char *)vme_dev_p,size);
		return(0);
	case	VME_SET_SPACE:	/* IOCTL b 1 */
		Vm_check_suser;
		err = verify_area(VERIFY_READ ,(void *)arg,size);
		if(err)
			return(err);
		Vm_down(&bit3_sem);		/* SEM */
		Vm_copy_from_user((char *)vme_dev_p,(char *)arg,size);
		Vm_up(&bit3_sem);			/* SEM */
		return(0);
	case	VME_CHECK_ACCESS:	/* IOCTL b 2 */
		err = verify_area(VERIFY_READ ,(void *)arg,size);
		if(err)
			return(err);
		Vm_get_uval(argval,(long *)arg); /**/
		if(bit3_pio_delay == argval)
		{
			Vm_report_driver();
			return(0);
		}
		if(argval < 0 || argval > 400)
			return(-EINVAL);
		Vm_check_suser;
		Vm_down(&bit3_sem);		/* SEM */
		bit3_pio_delay = argval;
		Vm_up(&bit3_sem);			/* SEM */
		Vm_report_driver();
		return(0);
	case	VME_SLOW_CONTROL:	/* IOCTL b 3 */
		err = verify_area(VERIFY_READ ,(void *)arg,size);
		if(err)
			return(err);
		Vm_get_uval(argval,(long *)arg); /**/
		if(bit3_slow_control == argval)
		{
			Vm_report_driver();
			return(0);
		}
		if(argval < 0 || argval > 400)
			return(-EINVAL);
		Vm_check_suser;
		Vm_down(&bit3_sem);		/* SEM */
		bit3_slow_control = argval;
		if(argval)	
		{
			//safe_free DMA buffer
			(void)Vm_dma_mem_free((int)bit3_dma_addr,bit3_dma_size);
			bit3_dma_addr = (unsigned long *)1;
		}
		else
		{
			// alloc & address DMA buffer
			bit3_dma_addr = (unsigned long *)
				Vm_dma_mem_alloc(bit3_dma_size);
			if(bit3_dma_addr == (unsigned long *)1)
			{
         printk("vmehb: WARNING requested DMA but in slow control only\n");
                        	bit3_slow_control = 1;
			}
			else
			{
				// ev fixed mapping here
			}
		}	
		Vm_up(&bit3_sem);			/* SEM */
		Vm_report_driver();
		return(0);
	case	VME_DMA_CONTROL:	/* IOCTL b 4 */
		err = verify_area(VERIFY_READ ,(void *)arg,size);
		if(err)
			return(err);
		Vm_get_uval(argval,(long *)arg); /**/
		if(bit3_irq_used == argval)
		{
			Vm_report_driver();
			return(0);
		}
		if(argval < 0 || argval > 400)
			return(-EINVAL);
		Vm_check_suser;
		Vm_down(&bit3_sem);		/* SEM */
		bit3_irq_used = argval;
		Vm_up(&bit3_sem);			/* SEM */
		Vm_report_driver();
		return(0);
	case	VME_SET_AM:	/* IOCTL b 5 */
		Vm_check_suser;
		err = verify_area(VERIFY_READ ,(void *)arg,size);
		if(err)
			return(err);
		Vm_get_uval(argval,(long *)arg); /**/
		Vm_down(&bit3_sem);		/* SEM */
		vme_am = argval;
		Vm_up(&bit3_sem);			/* SEM */
		printk("vmebh: dev %s , minor %d am changed to x%x\n"
			,vme_name
			,vme_minor
			,vme_am
			);
		return(0);
	case	VME_SET_DMAMOD:	/* IOCTL b 6 */
		Vm_check_suser;
		err = verify_area(VERIFY_READ ,(void *)arg,size);
		if(err)
			return(err);
		Vm_get_uval(argval,(long *)arg); /**/
		if(    argval != 0 
		   &&  argval != RC2_DMA_BLK_SEL
	           &&  argval != RC2_DMA_PAUSE)
			return(-EINVAL);
		Vm_down(&bit3_sem);		/* SEM */
		vme_dmamod = argval;
		Vm_up(&bit3_sem);			/* SEM */
		printk("vmehb: dev %s , minor %d dmamod changed to %s\n"
			,vme_name
			,vme_minor
			,argval == RC2_DMA_PAUSE   ? "pause" :
			 argval == RC2_DMA_BLK_SEL ? "block" : "non block"
			);
		return(0);
	case	VME_CRATE_OFF:	/* IOCTL b  10 */
		if(bit3_VME_on == 0)
		{
			printk("vmehb: Vme crate already off\n");
			return (0);
		}
		Vm_check_suser;
		printk("vmehb: Vme crate going   off\n");
		Vm_down(&bit3_sem);		/* SEM */
		bit3_VME_on = 0;
		Vm_up(&bit3_sem);			/* SEM */
		return(0);
	case	VME_CRATE_ON: /* IOCTL b  11  */
		if(bit3_VME_on == 1)
		{
			printk("vmehb: Vme crate already on\n");
			return 0;
		}
		Vm_check_suser;
		Vm_down(&bit3_sem);		/* SEM */
		printk("vmehb: Vme crate going   on \n");
		if(Bit3_init(bit3_base0) < 0) 
		{
			bit3_VME_on = 0;
			printk("vmehb: ioctl can not initialize VME crate\n");
			Vm_up(&bit3_sem);		/* SEM */
			return(-ENODEV);
		}
		bit3_VME_on = 1;
		if(bit3_VME_on == 0)
		{
			printk("vmehb: Crate is still OFF !!!!\n");
		}
		Vm_up(&bit3_sem);			/* SEM */
		return(0);
	case	VME_GET_CRATE:      /* IOCTL b  12  */
		err = verify_area(VERIFY_WRITE,(void *)arg,size);
		if(err)
			return(err);
		Vm_down(&bit3_sem);		/* SEM */
		*((int *)argval) = bit3_VME_on;
		Vm_up(&bit3_sem);			/* SEM */
		Vm_copy_to_user((char *)arg,(char *)&argval,size);
		return(0);
	/* inserted by H. Okamura: from here */
	case	VME_RESET:         /* IOCTL b  40  */
		if(bit3_VME_on == 0)
		{
			printk("vmehb: Vme crate is off\n");
			return(-ENODEV);
		}
		Vm_check_suser;
		printk("vmehb: resetting Vme ...");
		Bit3_r_set(bit3_base0,REM_CMD1,RC1_RESET_REM);
		/* now wait 2 sec allowing other task interrupt */
		current->state = TASK_INTERRUPTIBLE;
#		ifdef LIN2_2
		schedule_timeout(HZ*2);
#		else
		current->timeout = jiffies + HZ*2;
		schedule();
		current->timeout = 0;
#		endif /* LIN2_2 */
		Bit3_r_set(bit3_base0,REM_CMD1,0);
		printk(" done.\n");
		return(0);
	/* inserted by H. Okamura:  to  here */
	case	VME_CLEAR_MAPS:		/* IOCTL b 61 */
		Vm_check_suser;
		printk("vmehb: suser unmapping all mappings!!!\n");
		Vm_list_maps();
		Vm_down(&bit3_sem);		/* SEM */
		Vm_clear_maps(0);
		Vm_up(&bit3_sem);			/* SEM */
		return(0);
	case	VME_TRACE_ZOMBIES:	/* IOCTL b 62 */
		Vm_check_suser;
		if(bit3_wakeups)
		{
			printk("vmehb: Try to wake a sleeping beauty\n");
zombie2:
			if((bit3_wait_struct->task->pid) <= 0)
			{
				printk("vmehb: No sleeping beauties %lx  seen (wake %d)\n"
					,(unsigned long)bit3_wait_struct->task
					,bit3_wakeups);
				if(bit3_wakeups) --bit3_wakeups;
				print_trace();
			}
			else
			{
				printk("vmehb: Kissing a beauty task %lx :%d (%x)\n"
					,(unsigned long)bit3_wait_struct->task
					,bit3_wait_struct->task->pid
					,bit3_wait_struct->task->pid
					);
				print_trace();
				bit3_wakeups--;
				wake_up(bit3_wait_q);	/* wakeups */
			}
		}
		else
		{
			printk("vmehb: bit3_wakeups == 0 , try anyway\n");
			goto zombie2;
		}
		return(0);
	case	VME_TRACE_INFO:		/* IOCTL b 63 */
		print_trace();
		Vm_list_regs();
		Vm_list_maps();
		return(0);
	default:
		return -EINVAL;
	}
	return(0);
}
/* === OPEN ======================================================*/
static int vmehb_open(struct inode *node,struct file *file)
{
	MOD_INC_USE_COUNT;
	/**/
#if	GATHER_SCATTER_VME
#endif	GATHER_SCATTER_VME
	return	0;
}
/* === RELEASE ===================================================*/
#ifdef LIN2_2
static int vmehb_release(struct inode *node,struct file *file) 
#else
static void vmehb_release(struct inode *node,struct file *file) 
#endif
{
	MOD_DEC_USE_COUNT;
	/**/
	// printk("vmehb: close unmaps process %d\n",current->pid);
	Vm_down(&bit3_sem);			/* SEM */
	Vm_clear_maps(current->pid);
	// Vm_list_maps ();
	Vm_up(&bit3_sem);				/* SEM */
	/**/
#ifdef LIN2_2
	return 0;
#endif
} /* end of vmehb_release() */

static struct file_operations vmehb_ops = {
#ifdef LIN2_4
	THIS_MODULE,		/* module owner */
#endif
#ifdef LIN2_0
	vmehb_lseek,		
#else
	NULL,			/* use system's & check by r/w */
#endif
	vmehb_read,
	vmehb_write,
	NULL,
	NULL,
	vmehb_ioctl,		/* ioctl	*/
	vmehb_mmap,		/* mmap		*/
	vmehb_open,
#ifdef LIN2_2
	NULL,			/* flush	*/
#endif
	vmehb_release,
	NULL,
	NULL,
	NULL,
	NULL,
};
/* --- end of FILE OPERATIONS  -----------------------------------*/

/* --- base VME access functions   -------------------------------*/
static int vmehb_dev_access(int cminor,unsigned int vme_addr,char *buf,unsigned int count,int rw)
{
// PATCH-2.2.1 to get the VME BLOCK FIFO devices working nicely
// PATCH-2.2.4 to get  read/write length up to 2GB
//	to access more than bit3_dma_size ( def 0x8000)
//
	// variables to cut the transfer into DMA mangeable pieces
	unsigned long p_count,p_len,p_cnt,p_back; 
	char *p_buf;
	// variable to keep hidden parameter
	int vme_function;
// END PATCH-2.2.1
	int 	err;
	if(bit3_VME_on == 0)
		return(-ENODEV);
	VMEHB2_TRACE(("vmehb2: dev_access %x %x %x %x\n",cminor,vme_addr,count,rw));
	bit3_error = 0; // necessary paranoia because of mmap
	Vm_down(&bit3_sem);	 /* SEM */  
	err = Va_check_access(vme_addr,buf,count,rw,cminor);
	if(err)
	{
		VMEHB2_TRACE(("vmehb2: check failed %d\n",err));
		Vm_up(&bit3_sem);	 /* SEM */
		return(err);
	}
	/* this flag is set compile-time or later by ioctl	*/
	/* excluding DMA and invoking the delayed PIO access	*/
	/* to check the VME configuration for VME bus errors	*/
	if(bit3_pio_delay)
		goto pio_access;
	/* this flag is set compile-time or later by ioctl	*/
	/* excluding DMA and invoking the PIO access for slow	*/
	/* control access with mmap allowed			*/
	if(bit3_slow_control)
		goto pio_access;
	/* this is the DAQ trigger DMA/PIO distribution 	*/
	if(count > vme_pio && vme_mod > 1)/**/
		goto dma_access;
	else
		goto pio_access;
	/**/
dma_access:
// PATCH-2.2.1 to get the VME BLOCK FIFO devices working nicely
// 	On cards with ID = #82 the bit RC2_DMA_PAUSE causes address 
// 	to stay not updated ( that is so, tested in Dec 99)
// 	On cards with ID != #82 adaptor updates always the address 
// 	on the border of each block of 256 bytes (ID #80)
//	Notify me if you have another card ID ( look into dmesg)
// PATCH-2.2.4 to get  read/write length up to 2GB
//	to access more than bit3_dma_size ( def 0x8000)
//		<natalia@nikhef.nl>
//
	// Exceptions of a standard DMA handling for VME BLOCK FIFO 
	// and for extra long access are made here
	if(vme_fun & 0x8) {
		// goto multi_dma_access; // debug  ONLY.
		if (bit3_card_id == 0x82)  vme_dmamod |= RC2_DMA_PAUSE; 
		else  {
			/* cutting for VME block boundary */
			p_len   = 256 - (vme_addr & 0xff);	
                     	goto multi_dma_access;
		}
	} else   if(count > bit3_dma_size)  {
		/* cutting for MAX_DMA_SIZE */
		p_len = bit3_dma_size;
		goto multi_dma_access;
	} 
// END PATCH-2.2.4
// END PATCH-2.2.1
	// Standard DMA handling of one DMA block
	if((err = Va_dma_map(vme_addr,(char *)buf,count,rw)))
	{
		VMEHB2_TRACE(("vmehb2: DMA map failed %d\n",err));
		count = err;
		goto end_dma;
	}
	count = Va_dma_access((u32)vme_addr,count,(char *)buf,rw);
end_dma:
	Va_dma_clean();
end_tail_pio:
	bit3_error  = 0;
	Vm_up(&bit3_sem);		/* SEM */
	VMEHB3_TRACE(("vmehb: DMA done\n"));
	return(count);
// PATCH-2.2.1 to get the VME BLOCK FIFO devices working nicely
// PATCH-2.2.4 to get  read/write length up to 2GB
//
multi_dma_access:
	// Blocked DMA access for special cases
	p_count = count;
	p_buf   = buf;
	p_back  = 0;

	// Main bulk in blocks of p_len
	while(p_count >= p_len) {
		VMEHB3_TRACE(("vmehb: L  %8x  at %8x \n",p_back,(int)p_buf)); 
		if((err = Va_dma_map(vme_addr,(char *)p_buf,p_len,rw)))
		{
VMEHB3_TRACE(("vmehb: MULTI-DMA map failed %d at count %x\n",err,p_back));
			count = err;
			goto end_dma;
		}
		p_cnt = Va_dma_access((u32)vme_addr,p_len,(char *)p_buf,rw);
		if(p_cnt < p_len | bit3_error) {
	VMEHB3_TRACE(("vmehb: MULTI-DMA access failed after %x\n",p_cnt));
			count = p_back + p_cnt;
			goto end_dma;
		}
		p_back  += p_len;
		p_buf    = (char *)((unsigned int)buf + p_back);
		// small length - FIFO otherwise memory
		if(p_len == bit3_dma_size) vme_addr+= p_len;
		// access and count bytes
		p_count -= p_len;
	}
	// Tail
	if(p_back < count ) {
		p_len = count - p_back;
		if(p_len < 4) goto tail_pio;
		VMEHB3_TRACE(("vmehb: Td  %8x  at %8x \n",p_back,(int)p_buf)); 
		if((err = Va_dma_map(vme_addr,(char *)p_buf,p_len,rw)))
		{
VMEHB3_TRACE(("vmehb: MULTI-DMA map failed %d at count %x\n",err,p_back));
			count = err;
			goto end_dma;
		}
		p_cnt = Va_dma_access((u32)vme_addr,p_len,(char *)p_buf,rw);
		if(p_cnt < p_len | bit3_error) {
	VMEHB3_TRACE(("vmehb: MULTI-DMA access failed after %x\n",p_cnt));
			count = p_back + p_cnt;
			goto end_dma;
		}
		p_back  += p_len;
		count = p_back;
		goto end_dma;

		// when we are left with less than what can carry DMA
tail_pio:
		VMEHB3_TRACE(("vmehb: Tp  %8x  at %8x \n",p_back,(int)p_buf)); 
		if((err = Va_pio_map(vme_addr,p_len)) < 0)
		{
			VMEHB2_TRACE(("vmehb2: tail PIO map failed %d\n",err));
			Vm_up(&bit3_sem);	 /* SEM */
			return(err);
		}
		p_cnt = Va_pio_access(vme_addr,p_len,p_buf,rw);
	 	count = p_back + p_cnt;
		goto end_tail_pio;
	}
//PATCH 2.2.6 - bad end to multi_dma with round count missing stopper added
	goto end_tail_pio;		
// end  PATCH 2.2.6
pio_access:
	if((err = Va_pio_map(vme_addr,count)) < 0)
	{
		VMEHB2_TRACE(("vmehb2: PIO map failed %d\n",err));
		Vm_up(&bit3_sem);	 /* SEM */
		return(err);
	}
	if(count > vme_pio)
	{
		printk("vmehb: pio on %s too long %d , allowed %d\n"
			,vme_name,count,vme_pio );
		Vm_up(&bit3_sem);	 /* SEM */
		return(-EINVAL);
	}
	count = Va_pio_access(vme_addr,count,buf,rw);
//end_pio:
	Vm_up(&bit3_sem);	 /* SEM */
	return(count);
} /* end vmehb_dev_access() */
/* --- end of base VME access functions   ------------------------*/

/* --- LEAF DRIVERS EXPORTS  in vmehb_syms -----------------------*/
static int request_vme_irq(int level,int vector,VME_HAN handler,char * from)
{
	/* INTERRUPT services for leaf drivers:
	 * Here the drivers of VME devices can (dis)connect their 
	 * interrupt handler routines
	 * The user level of this service is implemented without  
	 * user level handlers via signal requests and ev ACK ioctls
	 */
	if(!suser())
		return (-EPERM);
	if(level < MIN_IRQ_LEVEL || level > MAX_IRQ_LEVEL)
		return -EINVAL;
	if((bit3_n = Va_vme_find_irq(level,vector,handler,from)) == (VIP)0)
		return -ENOMEM;
	bit3_n->task = (struct task_struct *)NULL;
	Bit3_vme_intr(bit3_base0,1);
	return(0);
} /* end request_vme_irq */
/*----------------------------------------*/
static void free_vme_irq(int level,int vector,VME_HAN handler)
{
	Va_vme_free_irq(level,vector,handler);
	return;
} /* end free_vme_irq */
/*----------------------------------------*/
/*  
 *  vmehb pages (de)assigning for device drivers 
 *  of VME hardware ( just skipping fs parameters !!)
*/
static unsigned long vmehb_dev_mmap(int cminor, unsigned int vme_addr
				,unsigned int size)
{
	int err,PCIoff;
	/* MAPPING services for leaf drivers:
	 * This routine is added to allow drivers of VME devices
	 * to reserve pages on vmehb device. It returns the kernel
	 * pointer to the first physical VME address assigned.
	 * All the limitations are the same as for vmehb_mmap!!!
	 * i.e. it collides with DMA !!!
	 *      (C)		Dec 97 <natalia@nikhef.nl>
	*/
	/*
	** current notes: limitation to slow or check modes removed
	** for the test time:
	if(bit3_slow_control == 0 && bit3_pio_delay == 0)
		return(-ENODEV);
	*/
	Vm_down(&bit3_sem); 	/* SEM */
	/* set the approppriate vme space data */	
	// vme_dev_p = (struct vme_dev	*)&(vme_config[cminor]);
	if((err = Va_check_access(
			(u32)vme_addr,(char *)0,0x1000,VME_WRITE,cminor)))
	{
		Vm_up(&bit3_sem); 	/* SEM */
		return(err);
	}
	if((err = Va_map_map((u32)vme_addr,size)) < 0)
	{
		Vm_up(&bit3_sem); 	/* SEM */
		return(err);
	}
	PCIoff	= err * 0x1000;
	/* if head				*/
if(bit3_first == (struct vme_frag *)0)
	{
		bit3_first = (struct vme_frag *)kmalloc(sizeof(struct vme_frag)
					,GFP_KERNEL);
		VMEHB_TRACE(("vmehb: set head for mmap to %x\n",bit3_first));
		bit3_next = bit3_first;
		if(bit3_first == (struct vme_frag *)0)
		{
			Vm_up(&bit3_sem); 	/* SEM */
			printk("vmehb: Cannot alloc list head for map\n");
			return(-EIO);
		}
	}
	else
	{
		bit3_next->next = (struct vme_frag *)kmalloc(sizeof(struct vme_frag)
					,GFP_KERNEL);
		if(bit3_next->next == (struct vme_frag *)0)
		{
			Vm_up(&bit3_sem); 	/* SEM */
			printk("vmehb: Cannot alloc list slot for map\n");
			return(-EIO);
		}
		bit3_next	= bit3_next->next;
	}
	bit3_next->pid	= 0xffffffff;
	bit3_next->vadr = vme_addr;
	bit3_next->from	= uio_n_map;
	bit3_next->pages= uio_n_len;
	bit3_next->next	= (struct vme_frag *)0;
	Vm_list_maps();

	Vm_up(&bit3_sem); 				/* SEM */
	return(bit3_base3 + PCIoff);
} /* end vmehb_dev_mmap() */
/* -----------------------------------*/
static unsigned long vmehb_dev_unmap(int cminor, unsigned int vme_addr
				,unsigned int size)
{
	/* here should come neat unmapping.... */
	Vm_clear_maps(0xffffffff);
	return(0);
} /* end vmehb_dev_unmap() */
/* -----------------------------------*/
static unsigned long vmehb_dev_read(int cminor, unsigned int vme_addr,char * buf , unsigned int count)
{
	vme_dev_p = (struct vme_dev	*)&(vme_config[cminor]);
	return(vmehb_dev_access(cminor,vme_addr,buf,count,VME_DEV_READ));
} /* end vmehb_dev_read */
/* -----------------------------------*/
static unsigned long vmehb_dev_write(int cminor, unsigned int vme_addr,char * buf , unsigned int count)
{
	vme_dev_p = (struct vme_dev	*)&(vme_config[cminor]);
	return(vmehb_dev_access(cminor,vme_addr,buf,count,VME_DEV_WRITE));
	return(0);
} /* end vmehb_dev_write */
/* --- end of LEAF DRIVERS EXPORTS  in vmehb_syms ----------------*/
/*
 * INTERRUPT ------------------------------------
 * here is interrupt handler, attached in init_mod
 * we try to make a good service routine out of him
 * we use goto as recommended by gnu ;-)))))))))))
 */
static char vmehb_dev_id[] = "vmehb"; /* just for identifier */
/**/
static void vmehb_irqhandler(int bit3_irq_line,void *dev_id,struct pt_regs *regs)
{
	int v;
	static  int callcnt = 0; // paranoia
	int command;
	int count, spurious;
	/* added by Eric Kasten  for full VME irq services....*/
	int i,rc,iackrc,cirq;
	VIP	vip;

	if(dev_id != vmehb_dev_id) return; /* interrupt from other device */
/* pending: */
	/* alien ? return ! */
	if(Bit3_irq_alien(bit3_base0)) 
		return;
/* old_pending:  ( because of mmap )*/
	if(bit3_error )
	{
		if(~bit3_dma_busy) bit3_error = 0;
	}
	count 		= 0;
	count++;
	command = 0;
	if(count > 1)
		printk("vmehb: IRQ's piling? count %d irq %x\n",count);
/* errors: */
	v = Bit3_r_get(bit3_base0,LOC_STATUS);
	if(v & LSR_CERROR_MASK)
	{
		callcnt++;
		if( callcnt > 0xffffff) {callcnt = 0;};
		command |= LC1_CLR_ERROR;
		Bit3_r_set(bit3_base0,LOC_CMD1,command);
		if(v & LSR_TIMEOUT_ERR) /**/
		{
			Bit3_r_get(bit3_base0,REM_PAGE_HI);
			Bit3_r_set(bit3_base0,LOC_CMD1,command);
		}
		bit3_error	|= v;
		if(v & LSR_NO_CONNECT) /**/
		{
			if(bit3_VME_on) printk("vmehb: VME crate is OFF!!\n");
			bit3_VME_on = 0;
			bit3_error  |= LSR_NO_CONNECT;
			Bit3_clear_status(bit3_base0);
			print_trace();
		} else {
			if(!bit3_VME_on) printk("vmehb: VME crate is ON!!\n");
			bit3_VME_on = 1;
		}
		if(bit3_dma_busy)
		{
			// disable DMA done irq and conclude the transfer
			v = 0;
			Bit3_r_set(bit3_base0,LDMA_CMD,v);
			bit3_dma_busy = 0;
			if(bit3_wakeups)
			{
				bit3_wakeups--;
				wake_up(bit3_wait_q);	/* wakeups */
			} else {
				printk("vmehb: no sleeper  while DMA busy!!\n");// paranoia
			}
		}
		return;
	} /* end of errors */
/* pr_interrupt: */
	v = Bit3_r_get(bit3_base0,LOC_STATUS);
	if(v & LSR_PR_STATUS)
	{
		VMEHB_TRACE(("Pr interrupt cleared here\n"));
		command |= LC1_CLR_PR_INT;
		Bit3_r_set(bit3_base0,LOC_CMD1,command);
		//bit3m617_pr_interrupts++;   //ERIC
		return;
	} /* end of pr_interrupt */
/* dma_done: */
	if(count> 1)
		printk("vmehb: IRQ pending count is %d irq %x\n",count,callcnt);
	v = Bit3_r_get(bit3_base0,LDMA_CMD);
	if(v & LDC_DMA_DONE)
	{
		VMEHB3_TRACE(("vmehb: dma done, wake the process\n"));
		/* Bit3_clear_status(bit3_base0); /**/
		v &= ~LDC_DMA_DONE;
		Bit3_r_set(bit3_base0,LDMA_CMD,v);
		count = 0;
		while(bit3_wakeups)
		{
#			ifdef LIN2_4	/* for kernel-2.4.x, H. Okamura */
			wake_up(bit3_wait_q);	/* wakeups */
			bit3_wakeups--;
#			else
			if(((int)(bit3_wait_struct->task->pid)) <= 0)
			{
				udelay(100);
				printk("vmehb: IRQ - no sleeper yet, delay 100 usec\n");
				if(count++ > 10)
				{
					printk("vmehb: IRQ lost task to wake up\n");
					return;
				}
				continue;
			}
			else
			{
				bit3_wakeups--;
				wake_up(bit3_wait_q);	/* wakeups */
			}
#			endif	/* LIN2_4 */
		}
		/* try here later return DEBUG */
		return;
	} //end dma done....
/* vme_backplane_interrupt: /*    */
	/* I would not allow don't care level !!! */
        v = Bit3_r_get(bit3_base0,LOC_INT_STATUS ) & 0xfe;
	VMEHB1_TRACE(("c0ffee000001\n"));
        while(v) {
            cirq = -1; /* sanity check */
	    spurious = 0;
            for(i = 8;i > 1;i--) {
                if(v & (1 << i)) {
                    cirq = i;
                    //bit3m617_backplane_interrupts++;
                    v &= (~(1<< i)) & 0xfe;
                    break;
                } // end if...
            } // end for ....
	    rc = 0;  
            if(cirq < 0) break; /* sanity check */
	
	    Bit3_r_set(bit3_base0,REM_CMD1,(cirq & RC1_IACK_MASK));
	    iackrc = Bit3_r_get(bit3_base0,REM_IACK);
	    VMEHB1_TRACE(("iack  %x\n",iackrc));
	    //bit3m617_irqrsp[cirq - 1] = iackrc; //ERIC
	
	    vip = bit3_f;
	    while(vip != (VIP)0 ) {
		spurious = 0;
		if(vip->level > cirq)
		    {vip = vip->n;continue;}
		if(vip->level  <  cirq) 
			break ;
		if(vip->vector && vip->vector != iackrc)
		    {vip = vip->n;continue;}
                if( vip->handler) {	// test
                // if(!rc && vip->handler) {
			spurious = 2;
			if(!rc) {rc = (vip->handler)(cirq,iackrc);}; /**/
        	    VMEHB1_TRACE(("Lev:  vector:      han: pid: rc: from: \n"));
                    VMEHB1_TRACE(("%3d,   %3x %8x  %3d  %3d  %s == %d\n"
                        ,vip->level
                        ,vip->vector
                        ,(int)(vip->handler)
                        ,vip->task? vip->task->pid :0
			,rc
                        ,(vip->from ? vip->from : "NULL")
		        ,spurious
                        ));
		/**/
	        } // end !rc && vip->handler
		if(vip->task)
		{
			if(vip->sig)
			{
				spurious +=1;
        	    VMEHB1_TRACE(("Lev:  vector: sig: pid: rc: RORA: from: \n"));
                    VMEHB1_TRACE(("%3d,   %3x %3d  %3d  %3d  %3d %s == %d\n"
                        ,vip->level
                        ,vip->vector
                        ,vip->sig
                        ,vip->task? vip->task->pid :0
			,rc
			,vip->response
                        ,(vip->from ? vip->from : "NULL")
		        ,spurious
                        ));
				/* for RORA services */
				if(vip->response)
				{
					bit3_VME_irq_allow |= (1<< vip->level);
					bit3_acks_pending(vip->level)++;
					printk(
			"vmehb: RORA irq - remote VME transfer suspended\n");
					// disable remote interrupt transfer
					Bit3_vme_intr(bit3_base0,0);
				}
				send_sig(vip->sig,vip->task,1);
			}
		}
		vip = vip->n;
	    } // end while(vip....
	} // end while(v).....
    /* on Local Interrupt Register */
/* pt_interrupt:  /**/
	/* on Remote Status Register */
	v = Bit3_r_get(bit3_base0,REM_STATUS);
	if(v & RSR_PT_STATUS)
	{
		printk("vmehb: Pt interrupt cleared here\n");
		command |= RC1_CLR_PT_INT;
		Bit3_r_set(bit3_base0,REM_CMD1,command);
		//bit3m617_pt_interrupts++; //ERIC
		return;
	} // end pt interrupt
/* spurious: */
    	VMEHB2_TRACE(("vmehb2: Something not cleared yet ??? \n"));
	Bit3_clear_status(bit3_base0);
	return;
	
}
/* ================================================================== */
/* PCI bus init */
#include	"pci_dev_probe.c"
/* WRAPPER	start*/
int mod617_init(void)
{
	unsigned long	addr[64];	/* for the alpha sake */
	if(!pcibios_present())
	{
		printk("vmehb: No BIOS, hence no VME available\n");
		return -ENODEV;
	}
	if(!pci_dev_config(PCI_VENDOR_ID_BIT3,
	            PCI_DEVICE_ID_BIT3_VME,&PCI_conf,"vmehb"))
	{
	    printk("vmehb: No device 617 ,checking for 618 now\n");
	    if(!pci_dev_config(PCI_VENDOR_ID_BIT3,
	       PCI_DEVICE_ID_BIT3_VME_618,&PCI_conf,"vmehb"))
	    {
	        printk("vmehb: No device 618 either, so may be 616 slow controls?\n");
	        bit3_slow_control = 1;
	        if(!pci_dev_config(PCI_VENDOR_ID_BIT3,
	           PCI_DEVICE_ID_BIT3_VME_616,&PCI_conf,"vmehb"))
	        {
	            printk("I did not see any known VME adaptor, bye bye!!\n");
	            return(-ENODEV);
	        }	
		else
                    printk("So you have got slow control 616 adaptor, nice\n");	
	    }
	    else
	        printk("You have got a 618 adaptor it seems...\n");
	} 
	else
		printk("You  have got a 617 adaptor, I think...\n");  
	// this now happens always
	{

		
	// Dave, do not leer here. This is single report on architecture, 
	// not really a CODE... Below I have added abstracting for 
	// int_line(s) with the contents in vmehb_conf.h.

#ifdef __alpha__
	printk("vmehb: bridge found, alpha processor\n");
#endif
#ifdef __i386__
	printk("vmehb: bridge found, i386  processor\n");
#endif
		pci_dev_info(PCI_conf,"vmehb");
		// ALPHA LX reports 2 over here but connects on 0x11
		// so we have abstracted in vmehb_conf.h for this purpose
		// Dave C. checking what should come here for ALPHA LX
		// bit3_irq_line is int, ..._int_line is unsigned char!!!
		// Take care Alpha boys  - Intel maid

		bit3_irq_line = Vm_irq_line(PCI_conf._int_line);
		printk("vmehb: requesting a line : %x\n",bit3_irq_line);
		/* 
		 * on alpha PCI addresses assigned are  4 bytes 
		 * If something changes - change PCI_ACCESS MASK 
		 * to 8 bytes 
		 */
		bit3_base0 = PCI_conf._base0 & PCI_ACCESS_MASK;
		bit3_hard0 = PCI_conf._base0 & PCI_ACCESS_MASK;
		bit3_hard2 = PCI_conf._base2 & PCI_ACCESS_MASK;
		bit3_hard3 = PCI_conf._base3 & PCI_ACCESS_MASK;

		if( (bit3_card_id = Bit3_init(bit3_base0)) < 0)
			bit3_VME_on = 0;
		else
			bit3_VME_on = 1;
#		ifdef LIN2_4		/* no need for 2.4.x, H. Okamura */
		init_waitqueue_head(bit3_wait_q);
#		else
		/* in the dense packed PCI  configurations lack of  mask
		 * over the I/O port address can cause unjust failure of
		 * check_region interpreting  type bits as start address  */
		if((addr[0] = check_region(PCI_conf._base0 & PCI_ACCESS_MASK,0x20))) 
		{
			BIT3_TRACE((" Region 0 on %x does not check \n" 
				,PCI_conf._base0));
		}
		if((addr[1]=check_region(PCI_conf._base1 & PCI_ACCESS_MASK,0x10000)))
		{
			BIT3_TRACE((" Region 1 on %x does not check\n"
				,PCI_conf._base1));
		}
		if((addr[2]=check_region(PCI_conf._base2 ,0x10000)))
		{
			BIT3_TRACE((" Region 2 on %x does not check\n"
				,PCI_conf._base2));
		}
		if((addr[3]=check_region(PCI_conf._base3,0x2000000)))
		{
			BIT3_TRACE((" Region 3 %x does not check\n"
				,PCI_conf._base3));
		}
		if(addr[0] || addr[1] || addr[ 2] || addr[ 3] )
		{
			printk(" check failure: %x %x %x %x \n"
				,addr[ 0],addr[1],addr[ 2],addr[ 3]);
			return(-ENODEV);
		}
		VMEHB2_TRACE(("vmehb2: Regions checked, interrupt on %x \n",bit3_irq_line));	
#		endif	/* LIN2_4 */
		if(request_irq(bit3_irq_line,vmehb_irqhandler,
			SA_INTERRUPT|SA_SHIRQ,"vmehb",vmehb_dev_id))
		{
			printk("vmehb: interrupt registration fault on level %d\n"
				,bit3_irq_line);
			return(-ENODEV);
		}
		/* we service normal & error, PT by ioctl only */
		Bit3_set_intr(bit3_base0,1,1,0);
		request_region(bit3_base0,0x20,"bit3_ior_0");
		/* changes for alpha sake */
		addr[2] = PCI_conf._base2;
		addr[3] = PCI_conf._base3;
		bit3_base2 = (unsigned long)Vm_remap(addr[2],0x10000	);
		bit3_base3 = (unsigned long)Vm_remap(addr[3],0x2000000	);
		printk("vmehb: Vm_remapped:  %lx (%x) %lx (%x)\n"
			,bit3_base2
			,PCI_conf._base2
			,bit3_base3
			,PCI_conf._base3
				);
		if(bit3_base2 == 0 || bit3_base3 == 0 )
		{
			printk("vmehb: can not map into kernel!!\n");
			free_irq(bit3_irq_line,NULL);
			release_region(bit3_base0,0x20	);
			return(-ENOMEM);	/* init phase	*/
		}
	}
	/* 
	 *  funny ways with the dynamic assignment of majors nrs 
	 *  when BIG_MAJOR =0 
	 */
	if((bit3_major= register_chrdev(BIT3_MAJOR,"vmehb",&vmehb_ops   )) < 0) 
	{
		BIT3_TRACE(("vmehb no major %d (fault %d) \n",BIT3_MAJOR,bit3_major));
		Bit3_set_intr(bit3_base0,0,0,0);
		free_irq(bit3_irq_line,NULL);
		release_region(bit3_base0,0x20	);
		return -EIO;
	}
	if (BIT3_MAJOR > 0)
		bit3_major = BIT3_MAJOR;
	BIT3_TRACE(("LOAD vmehb  as MODULE %d ( asked %d)  irq %d\n"
		,bit3_major,BIT3_MAJOR,bit3_irq_line));
	/* set up the device - see in vmehb_conf.h	*/

	/* export the symbols if 2.0.x				*/
	REGISTER_SYMTAB(&vmehb_syms);

	/* setup of device */
	addr[0] = (unsigned long) Vm_set_me_up() ;
	if(addr[0] == 0)
	{
		Vm_status("loaded");
		//Vm_status("   ...beta driver");	// add a neat comment
		Va_vme_test_irq();	/**/
		return 0;
	}
	/* disable all interrupts			*/
	Bit3_set_intr(bit3_base0,0,0,0);
	free_irq(bit3_irq_line,NULL);
	Vm_free((void *)bit3_base3);
	Vm_free((void *)bit3_base2);
	Vm_dma_mem_free((unsigned long)bit3_dma_addr,bit3_dma_size);
	release_region(bit3_base0,0x20	);
	return(-ENOMEM);
}
int init_module(void)
{
	Vm_status("starting ");		// add a neat starting message...
	return(mod617_init());
}
void cleanup_module(void)
{
	BIT3_TRACE(("UNLOAD vmehb %d ( %d) free intr %d\n"
			,bit3_major,BIT3_MAJOR,bit3_irq_line));
	/* disable all interrupts			*/
	Bit3_set_intr(bit3_base0,0,0,0);
	free_irq(bit3_irq_line,NULL);
	Vm_free((void *)bit3_base3);
	Vm_free((void *)bit3_base2);
	Vm_dma_mem_free((unsigned long)bit3_dma_addr,bit3_dma_size);
	release_region(bit3_base0,0x20	);
	if(bit3_major > 0)
		unregister_chrdev(bit3_major,"vmehb");
	else
		unregister_chrdev(BIT3_MAJOR,"vmehb");
	Vm_status("unloaded");		// add a neat starting message...
}
/* WRAPPER	end  	*/

/* add CONTRIBUTIONS or CONT_UPD here */

/*
    vmehb - VME bus driver of PCI/VME bus adaptor Model 616-618 of Bit3.
    --------------------------------------------------------------------
    Copyright (C) May 1997  Natalia Kruszynska <natalia@nikhef.nl>
    Sponsored and instigated by 
	NIKHEF - Amsterdam
	DESY   - Hamburg
    within the technical support of Hermes Collaboration in Physics.

    Thanks for contribution in alphabetical order to:
	A.J.Aranyosi	<aja@mit.edu> for a neat 2.2 port
	Thomas Bogend	<tsbogend@alpha.franken.de> DMA on alpha PC
	Andries Brouwer <aeb@cwi.nl>
	Dave Cattermole <dmc@mrc-lmb.cam.ac.uk> testing it on alpha PC
	David Chrisman  <David.Chrisman@cern.ch> extensions for Model 618
	Marcin Dalecki  <dalecki@math.uni-goettingen.de> 
	Jay Estabrook   <jay@digital.com> DMA on alpha PC
	Lisa. G.Gorn	<gorn@phys.ufl.edu> for 618/2.2 updates and tests
	David Grothe	<dave@gcom.com>
	Eric Kasten     <kasten@ncsl.msu.edu> for a neat 2.1.90+ version
                        (grab it if you can run beta Linux)

        H.J Mathes      < mathes@ik3.fzk.de> byte access and byte spaces
	Hiroyuki Okamura<okamura@phy.saitama-u.ac.jp> (interrupts)
	Henk Peek	<henkp@nikhef.nl> 
        Klaus Schossmaier<Klaus.Schossmaier@cern.ch>
	Ruud van Wijk   <ruud@nikhef.nl>

    and to  these who are not yet listed here  and who have caught
    some hidden bug and send it to me. 

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
*/
/*
    CONTENTS:
    vmehb_aux.c - intrinsic part of the driver, to be included where
		it is already included in vmehb.c. Separated to put
		apart medium level routines. Context dependent on vmehb.c!!
    Copyright (C) May 1997  Natalia Kruszynska <natalia@nikhef.nl>
*/
/*
 * The following  prefixes are consequently used in the code:
 *	vme_		- configuration data of a vme space
 *	bit3_		- device  structure members
 *	uio_		- request structure members (UNIX hickup)
 *	vmehb		- big routines of the driver 
 *      Va_		- base auxiliary routines
 *	Vm_		- semaphoring & setup inlines from vme_conf.h
 *	Bit3_		- hardware access inline primitives
 */
	/* 
         *   bit3_irq_used flag is used to switch the mode of DMA service
	 *   bit3_irq_used is 1 for IRQ service of DMA, negative for POLL
	 *   Absolute values of negative  bit3_irq_used  mean poll mode 
	 *   with :
	 *    < 1000	udelay  of (-bit3_irq_used) usec used on polling
	 *    > 1000    fancy tricks used for testing the interrupts
         */
static int Va_dma_count(u32 pos)
{
	u32 val;	 /* explicit, for alpha PC */
	u32 cc;
	int count;
	/* calculate VME pos from registers here	*/
	val = Bit3_err_addr(bit3_base0) ;
	cc = val - pos;	
	if (cc & 0x80000000)
	{
		cc = 0;
		val = 0;
	}
	VMEHB3_TRACE(("vmehb_a: Va_dma_count: \n"));
	count = cc;
	if(bit3_error & LSR_NO_CONNECT){ 
           printk("vmehb DMA: switch VME crate ON!!!\n" );return(0);}
	if(bit3_error & LSR_PARITY_ERR)
	   printk( "vmehb DMA: parity error VME range [%x,%x]\n" ,(int)pos,(int)val);
	if(bit3_error & LSR_REMBUS_ERR)
	   printk( "vmehb DMA: BERR on VME range [%x,%x]\n" ,(int)pos,(int)val);
	if(bit3_error & LSR_TIMEOUT_ERR)
	   printk( "vmehb DMA: timeout on VME range [%x,%x]\n" ,(int)pos,(int)val);
	if(bit3_error & LSR_LRC_ERR)
	   printk( "vmehb DMA: LRC on VME [%x,%x]\n" ,(int)pos,(int)val);
	if((bit3_error & LSR_ERROR_MASK) == 0)
	   VMEHB3_TRACE(("vmehb_a: DMA on VME [%x,%x]\n",(int)pos,(int)val));
	return(count);
} /* end Va_dma_count(u32 pos) /**/
/* --------------------------------------------------------- */
static int Va_check_access(u32 pos, char *buf,int count,
			int rw,int minor)
{
	/* if buf == 0, pos = vma->vm_offset , usable in mmap	*/
	int err;
	int verify;
	verify = (rw == VME_READ  ? VERIFY_WRITE :
	          rw == VME_WRITE ? VERIFY_READ  : VERIFY_NONE);
	/* frozen mapping ahead	DEBUG */
	bit3_free_ahead = 0;
	vme_dev_p       =
		(struct vme_dev  *)&(vme_config[minor]);
	uio_p            =
		(struct io_ahead *)&(bit3_dev_p->aheads[bit3_free_ahead]);
	bit3_free_ahead  = -1;
	uio_align 	 = 0;
	uio_pid	  	 = current->pid;

	/* check the address range			*/
	if((u32)(pos) > (u32)vme_maxad)
		 return(-EFAULT); 

	/* for mmap - align to the page size & return	*/
	if(buf == (char *)0)
	{
		if((pos) & 0xfff)
			return(-EINVAL);
		return(0);
	}

	/* for read/write - align to the data size & verify & return	*/
	/* only aligned counts , round to aligned 			*/
	if((pos) & (vme_mod - 1))
	{
		VMEHB2_TRACE (("vmehb2: pos %x\n , mod %xn",pos,vme_mod));
		return(-EFAULT);
	}
	while(count & (vme_mod - 1))
	{
		count++;
		uio_align++;
	};
	// paranoia check to be removed after debugging
	if(bit3_error)
	{
		VMEHB3_TRACE(("vmehb_a: should not show bit3_error here %x\n",bit3_error)); 
		return  0;
	}
	if (verify  == VERIFY_NONE)
		return 0;
	if( (err = verify_area(verify, buf,count)))
        {
                VMEHB3_TRACE(("vmehb2: not verified (flag %d) area %x\n"
                                ,verify,(unsigned long)buf));
                return err;
        }
	VMEHB2_TRACE(("vmehb2: check access finished:minor  %x\n",minor));
	return(0);
} /* end Va_check_access */
/* --------------------------------------------------------- */
static int Va_dma_map(u32 pos,char *buf,int count, int rw) 
{
	int val,i,err;
	uio_n_len	= count >> 12;
	if(count > bit3_dma_size)
		return -ENOMEM;
	if(count & 0xfff)
		uio_n_len += 1;
	if(bit3_error) 
	{
		VMEHB3_TRACE(("vmehb_a: Va_dma_map bit3_error %x\n",bit3_error));
		return -EIO;
	}
	uio_n_map = 0; /* as no dynamics allowed here because of fixed DMA */
	/* uio_n_map	= Bit3_map_alloc(bit3_base2,MR_DMA_PCI,uio_n_len); /* DEBUG */
	uio_addr	= (unsigned long)bit3_dma_addr;
	/* alpha - here some addressing considerations are stored */
	/*
	if(uio_addr & 0xff000000)
	{
		printk("vmehb: warning, dma address high %x\n",uio_addr);
	}
	*/
	uio_vadr	= pos;
	uio_dam		= vme_am;
	BIT3_TRACE(("DMA allocated on: %x map %x len %x align %x\n"
			,uio_addr,uio_n_map,uio_n_len,uio_align));
	uio_rw		= rw;		/* for write, for read 	*/
	if(uio_rw == VME_DEV_WRITE)
	{
		VMEHB2_TRACE(("vmehb2: From leaf driver\n"));
#		ifdef LIN2_4		/* for kernel-2.4.x, H. Okamura */
		memcpy((char *)bus_to_virt(uio_addr),buf,count - uio_align);
#		else
		memcpy((char *)uio_addr,buf,count - uio_align);
#		endif	/* LIN2_4 */
	} else
	if(uio_rw == VME_WRITE)
	{
		VMEHB2_TRACE(("vmehb2: From user\n"));
#		ifdef LIN2_4		/* for kernel-2.4.x, H. Okamura */
		Vm_copy_from_user((char *)bus_to_virt(uio_addr),buf,count - uio_align);
#		else
		Vm_copy_from_user((char *)uio_addr,buf,count - uio_align);
#		endif	/* LIN2_4 */
	}
	/* map the registers */
	val = DMAREG(uio_addr ,vme_swap,0);
	for(i = 0;i < uio_n_len;i++)
	{
		err=Bit3_p_set(bit3_base2,MR_DMA_PCI,uio_n_map + i,val);
		VMEHB2_TRACE(("vmehb2: DMA map %8x err %8x\n",val,err));
		val += 0x1000;
	}
	/* set the CSR's	*/
	val = BIT3DMA_COMMAND(vme_mod,vme_fu,uio_rw,0);
	/* the next call should have one more param = uio_n_map */
	Bit3_ldma(bit3_base0,uio_n_map,uio_addr,count,val);
	return(0);
} /* end Va_dma_map() */
/* --------------------------------------------------------- */
static int Va_dma_access(u32 pos,int count,char *buf,int rw)
{
	int  cnt;
	unsigned long flags;
	bit3_dma_busy = 1;
	cnt = count;
	VMEHB3_TRACE(("vmehb_a: DMA mod %x pos %x dir %x\n",vme_dmamod,pos,rw));
	VMEHB3_TRACE(("vmehb_a: DMA uio_vaddr %x , count %x\n",uio_vadr,count));
	Bit3_rdma(bit3_base0,uio_vadr,count);
	/* start DMA	(0 = poll, 1 = interrupt)		*/
	vme_dmamod |= RC2_CINT_DISABLE; /* inserted by H. Okamura */
	Bit3_lreg(bit3_base0,1,vme_dmamod,vme_am); /* 	*/
	DUMP_REGISTERS(bit3_base0); /* writes on VME 	*/
	bit3_dma_pid = current->pid;
	if(bit3_irq_used > 0) 	/* IRQ mode	*/
	{
		bit3_wakeups++;	
/* START CRITICAL */
		save_flags(flags);		
		cli();			
   		Bit3_dma_start(bit3_base0,bit3_irq_used);
		interruptible_sleep_on(bit3_wait_q);	/* int... H. Okamura */
		restore_flags(flags);
/* END   CRITICAL */
	}
	else	/* POLL modes */
	{
   		Bit3_dma_start(bit3_base0,bit3_irq_used); 
	}
	if(bit3_dma_pid != current->pid)
	{
		printk("vmehb: slept as %d woken %d\n",bit3_dma_pid,current->pid);
	}
	// there is no need to call that one when no errors, but
	// it can be made  to check out the transfer....
	if(bit3_error) count = Va_dma_count(pos);   /* in vmehb_aux.c */
        // DUMP_REGISTERS(bit3_base0); /* writes on VME 	*/
	// Vm_list_regs(); // paranoia check
/* clean_dma: */
	/* clean the administration of DMA */
	VMEHB3_TRACE(("vmehb_a: count %x cnt %x \n",count , cnt)); 
	if(cnt == count)
		count -=uio_align;
	if(uio_rw == VME_DEV_READ)
	{
		VMEHB2_TRACE(("vmehb2: To leaf driver\n"));
#		ifdef LIN2_4		/* for kernel-2.4.x, H. Okamura */
		memcpy(buf,(char *)bus_to_virt(uio_addr),count);
#		else
		memcpy(buf,(char *)uio_addr,count);
#		endif	/* LIN2_4 */
	} else if(uio_rw == VME_READ )
	{
#		ifdef LIN2_4		/* for kernel-2.4.x, H. Okamura */
		Vm_copy_to_user(buf,(char *)bus_to_virt(uio_addr),count  );
#		else
		Vm_copy_to_user(buf,(char *)uio_addr,count  );
#		endif	/* LIN2_4 */
	}
	/* Bit3_map_free (bit3_base2,MR_DMA_PCI,uio_n_len); /* DEBUG */
	return(count);
}// end Va_dma_access
static inline void Va_dma_clean() { 
	uio_pid		= 0;
	bit3_free_ahead = 0;
	bit3_dma_busy	= 0;
	
	vme_dmamod &= ~RC2_DMA_PAUSE; /* paranoia */
	if(!bit3_VME_irq_allow) // Here is bit pattern for RORA devices
	{
		vme_dmamod 	&= ~RC2_CINT_DISABLE;
		Bit3_lreg(bit3_base0,1,vme_dmamod,vme_am); /* 	*/
	}
	else
	{
		printk("vmehb: cannot enable irq , RORA hanging %x\n",bit3_VME_irq_allow);
	}

	return;
} /* end Va_dma_clean() */
/* --------------------------------------------------------- */
static int Va_pio_map(u32 pos,int count)
{
	int	i;
	int cnt,val,err;
	cnt		= count;
	uio_off	= pos & 0xfff;
	uio_n_len	= ((pos + count ) >> 12) -
                          ( pos           >> 12) + 1 ;
	if(bit3_dma_busy)
	{
		/* we come here only to implement readahead  NIY	*/
		/* Vm_down(&bit3_sem)	.... e.t.c, e.t.c.... 		*/
	}
	/* PIO para maps onto the first  2 reserved mapping registers 	*/
	/* the routine will return 0 , see  bit3_regs.h			*/
	uio_n_map	= Bit3_map_alloc(bit3_base2,MR_PCI_VME,uio_n_len); /* DEBUG */
	val = BIT3REG((u32)pos,vme_am,vme_fu,vme_swap,0); /**/
	for(i = 0;i < uio_n_len;i++)
	{
		err=Bit3_p_set(bit3_base2,MR_PCI_VME,uio_n_map + i,val);
		val += 0x1000;
	}
	err = Bit3_p_get(bit3_base2,MR_PCI_VME,uio_n_map);
	VMEHB2_TRACE(("vmehb2: am %x set %x got %x\n",vme_am,val,err));
	VMEHB2_TRACE(("vmehb2: PIO allocated from: %x regs  %x count %x (%d) off %x\n"
		,uio_n_map,uio_n_len,count,count,uio_off));
	return(0);
} /* end Va_pio_map() */

/* --------------------------------------------------------- */
static int Va_pio_access(u32 pos,int count,char *buf,int rw)
{
	int i,start,off,map;
	short	sval;
	char    bval;
	unsigned long bufaddr;
	/* attention alpha - lval is long in the sense of INTEL!! 32 bits */
	/* for alpha  several long castings added for user buffer e.t.c */
	u32	lval;    /* for alpha explicit type here */
	int	user;    /* to get along with vme_dev_read/write exports */
	start   = 0x1000 - uio_off;
	map	= uio_n_map;
	off	= uio_off;
	uio_rw  = rw;
	user    = 1;
	bufaddr = (unsigned long)buf;
	if((rw & 0x10)> 0)
		user = 0;
	if(( (rw& 0xf) == VME_WRITE) && (vme_mod == 4)) {goto write_32;}
	if(( (rw& 0xf) == VME_READ ) && (vme_mod == 4)) {goto read_32; }
	if(( (rw& 0xf) == VME_WRITE) && (vme_mod == 2)) {goto write_16;}
	if(( (rw& 0xf) == VME_READ ) && (vme_mod == 2)) {goto read_16; }
	if(( (rw& 0xf) == VME_WRITE) && (vme_mod == 1)) {goto write_8;}
	if(( (rw& 0xf) == VME_READ ) && (vme_mod == 1)) {goto read_8; }
	VMEHB2_TRACE(("vmehb2: invalid access\n"));
	return(-EINVAL);
write_16:
	VMEHB2_TRACE(("vmehb2:PIO write_16, rw = %d user %d err %x\n",rw,user,bit3_error));
	for(i = 0;i < count;i = i + vme_mod)
	{
		if(bit3_error)
		{
			count = i;
			goto clean_pio;
		}
		if(user)
			Vm_get_uval(sval,(short *)(bufaddr + i));
		else
			sval = *((short *)(bufaddr + i));
		writew(sval,bit3_base3 
			+ map * 0x1000
			+ off
			+ i);
		if(bit3_pio_delay) udelay(bit3_pio_delay);
	} /* end for w16... count */
	goto	clean_pio;
write_32:
	VMEHB2_TRACE(("vmehb2: PIO write_32, rw = %d user %d\n",rw,user));
	for(i = 0;i < count;i = i + vme_mod)
	{
		if(bit3_error)
		{
			count = i;
			goto clean_pio;
		}
		if(user)
			Vm_get_uval(lval,(u32 *)(bufaddr + i));
		else
			lval = *(u32 *)(bufaddr + i);
		writel(lval,bit3_base3 
			+ map * 0x1000
			+ off
			+ i);
		if(bit3_pio_delay) udelay(bit3_pio_delay);
	} /* end for w16... count */
	goto	clean_pio;
read_16:
	VMEHB2_TRACE(("vmehb2: PIO read_16, (rw,user,vmemod) = (%d,%d,%d) err %x\n",rw,user,vme_mod,bit3_error));
	for(i = 0;i < count;i = i + vme_mod)
	{
		if(bit3_error)
		{
			count = i;
			goto clean_pio;
		}
		sval = readw(bit3_base3 
				+ map * 0x1000
				+ off
				+ i);
		if(user)
			Vm_put_uval(sval, (unsigned short *)(bufaddr + i));
		else
			*((unsigned short *)(bufaddr + i)) = sval;

		if(bit3_pio_delay) udelay(bit3_pio_delay);
	} /* end for r16... count */
	goto	clean_pio;
read_32:
	VMEHB2_TRACE(("vmehb2: PIO read_32, rw = %d\n",rw));
	for(i = 0;i < count;i = i + vme_mod)
	{
		if(bit3_error)
		{
			count = i;
			goto clean_pio;
		}
		lval = readl(bit3_base3 
				+ map * 0x1000
				+ off
				+ i);
		if(user)
			Vm_put_uval( lval, (u32 *)(bufaddr + i));
		else
			*(u32 *)(bufaddr + i) = lval;
		if(bit3_pio_delay) udelay(bit3_pio_delay);
	} /* end for r32... count */
	goto	clean_pio;
write_8:
       for(i = 0;i < count;i = i + vme_mod)
       {
               if(bit3_error)
               {
                       count = i;
                       goto clean_pio;
               }
               if(user)
                       Vm_get_uval(bval,(short *)(bufaddr + i));
               else
                       bval = *((char *)(bufaddr + i));
               writeb(bval,bit3_base3
                       + map * 0x1000
                       + off
                       + i);
               if(bit3_pio_delay) udelay(bit3_pio_delay);
       } /* end for w8... count */
       goto    clean_pio;
read_8:
       VMEHB2_TRACE(("vmehb2: PIO read_8, (rw,user,vmemod) = (%d,%d,%d)\n",rw,user,vme_mod));
       for(i = 0;i < count;i = i + vme_mod)
       {
               if(bit3_error)
               {
                       count = i;
                       goto clean_pio;
               }
               bval = readb(bit3_base3
                               + map * 0x1000
                               + off
                               + i);
               if(user)
                       Vm_put_uval(bval, (unsigned char *)(bufaddr + i));
               else
                       *((unsigned char *)(bufaddr + i)) = bval;

               if(bit3_pio_delay) udelay(bit3_pio_delay);
       } /* end for r8... count */
       goto    clean_pio;
clean_pio:
	/* Bit3_map_free (bit3_base2,MR_PCI_VME,uio_n_len); /* DEBUG */
	return(count);
}/* end of Va_pio_access(u32 pos,int count,char *buf,int rw) 	*/

/* !!!!!  mmap auxiliaries   !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!! */
static int Va_map_map(u32 pos,int count)
{
	int	i;
	int cnt,val,err;
	cnt		= count;
	uio_off		= pos & 0xfff;
	uio_n_len	= ((pos + count ) >> 12) -
                          ( pos           >> 12)  ;
	if(count &0xfff)
		uio_n_len++;
	if(bit3_dma_busy)
	{
		/* we come here only to implement readahead  NIY	*/
		/* Vm_down(&bit3_sem)	.... e.t.c, e.t.c.... 		*/
	}
	// Here we introduce vmehb_conf.h function Vm_map_area_start()
	uio_n_map	= Bit3_map_find(bit3_base2,MR_PCI_VME,uio_n_len,
			Vm_map_area_start());
	if(uio_n_map    <= 0)
		return(-ENOMEM);
	val = BIT3REG((u32)pos,vme_am,vme_fu,vme_swap,0); /**/
	for(i = 0;i < uio_n_len;i++)
	{
		err=Bit3_p_set(bit3_base2,MR_PCI_VME,uio_n_map + i,val);
		val += 0x1000;
	}
	VMEHB2_TRACE(("vmehb2: MAP allocated from: %x regs  %x count %x(%d) off %x\n"
		,uio_n_map,uio_n_len,count,count,uio_off));
	return(uio_n_map);
} /* end Va_map_map() */

/* !!!!   interrupt auxiliaries   !!!!!!!!!!!!!!!!!!!!!!!!!! */
//////////////////////////////////////////////////////////
// Here is the place to implement your policy of security
// In NIKHEF as usual low, so one pid can call another's irq
// but warning is issued. Irq's of leaf handlers are secure
// from !suser() suser() can everything e.t.c.
// Comment out this one and add your own to your wish
// Returns -1 to refuse, 0 to ok the actions over vip.
// The similiar scheme can be done to mappings.....
// May be should, but NIKHEF does not mind ( see USER_ANARCHY ;-))

int	Va_vme_security_irq(VIP vip,pid_t call_pid)
{
	if(suser())
	{
	// suser priviledges 
		//  leaf driver -  should rmmod  it......
		if(vip->task == (struct task_struct *) NULL)
		{
			printk(
		"vmehb: root tries to remove %s driver's irq\n"
				,vip->from ? vip->from : "UNKNOWN");
			return(0);
		} else
		{
		// signal the user process and allow free 
			if(call_pid != vip->task->pid)
			{
				send_sig(SIGKILLVME,vip->task,1);
	printk("vmehb: root send killing signal to %s and removes IRQ\n",vip->from ? vip->from : "UNKNOWN" );
			}
			else
				printk("vmehb: root removes it's own irq %s\n"
					,vip->from ? vip->from : "UNKNOWN" );
			return(0);
		}
	} else {
	// mortal priviledges
		// leaf driver - hands off!!! notify....
		if(vip->task == (struct task_struct*) NULL)
		{
			printk(
		"vmehb: %d  tries to remove %s driver's irq\n "
				,call_pid
				,vip->from ? vip->from : "UNKNOWN");
			return(-1);
		}
		// we let them manage in more tasks, but we store
		// the message about - to keep an eye
		if(vip->task->pid != call_pid) {
			printk("vmehb: %d removing irq %s\n"
				,call_pid
				,vip->from ? vip->from : "UNKNOWN");
		}
		return (0);
	}

}
/* --------------------------------------------------------- */
//////////////////////////////////////////////////////////
// Va_vme_find_irq:
// Look at VIP structure. 
// This routine fills VIP as for a leaf driver ( no signalling 
// the user, no task struct needed ......). The ioctl should
// use it explicitely....
//
VIP	Va_vme_find_irq(int level,int vector,VME_HAN han,char *from)
{
	int	i;
	VIP	vip;		/* to store one's parent pointer */
	/*
	   Once more learned that it pays to estabilish CONSTANTS...  
	   I am not using Eric's don't care level 0, as I prefer
	   to keep a send_sig only users satisfied from here
	*/
	if(level > MAX_IRQ_LEVEL || level < MIN_IRQ_LEVEL )
		return((VIP)0);

/* add to the list of requests */
// alloc_new_vip:
	bit3_n	= bit3_f;
	vip	= (VIP) 0; 
	i	= 0;
	if(bit3_VME_irq_id > 0x7fff0) bit3_VME_irq_id = 0;
look_for_the_next_to_alloc: 
/* find last VIP of a level and place new VIP behind it from request.... */
	if(bit3_n == (VIP)0 )
	{
		bit3_n 		= (VIP)kmalloc(sizeof(struct vme_irq),GFP_KERNEL);
		if(bit3_n == (VIP)0)
		{
			VMEHB1_TRACE(("vmehb: Cannot alloc mem for IRQ request1\n"));
			return((VIP)0);
		}
		bit3_VME_irq++;
		bit3_VME_irq_id++;
		bit3_n->level	= level;
		bit3_n->task	= (struct task_struct *) 0;
		bit3_n->sig	= 0;
		bit3_n->vector  = vector;
		bit3_n->handler = han;
		bit3_n->from	= from;
		bit3_n->n       = ((VIP)0);
		if(vip != (VIP)0) {
			// This one was at the end at the moment
			vip->n 		= bit3_n;
		} else {
			bit3_f		= bit3_n;
		}
		return(bit3_n);
	} 
	/* some were installed before	*/
	if(bit3_n->level >= level)
	{
		vip	= bit3_n;
		bit3_n	= bit3_n->n;
		goto look_for_the_next_to_alloc;
	}
		bit3_n	  = (VIP)kmalloc(sizeof(struct vme_irq),GFP_KERNEL);
		if(bit3_n == (VIP)0)
 		{
                        VMEHB1_TRACE(("vmehb: Cannot alloc mem for IRQ request2\n"));
                        return((VIP)0);
                }
		bit3_VME_irq++;
		bit3_VME_irq_id++;
		bit3_n->level	= level;
		bit3_n->task	= (struct task_struct *) 0;
		bit3_n->sig	= 0;
		bit3_n->vector  = vector;
		bit3_n->handler = han;
		bit3_n->from	= from;
		if(vip != (VIP)0)
		{
			bit3_n->n = vip->n;
			vip->n    = bit3_n;
		}
		else
		{
			bit3_n->n = bit3_f;
			bit3_f    = bit3_n;
		}
		return(bit3_n);
}	/* end Va_vme_find_irq	*/

/* --------------------------------------------------------- */
int	Va_vme_free_irq(int level,int vector,VME_HAN han)
{
	VIP	vip;	/* to store one orq pointer */
	if(level > 9 || level < 0 )
		return 0;
	if(!(bit3_VME_irq)) return 0;
	bit3_n	= bit3_f;
	vip	= (VIP) 0; 
look_for_the_next_to_remove:
	if(bit3_n        == (VIP)0  ||
	   bit3_n->level < level)
	{
		VMEHB1_TRACE(("        not found\n"));
		return 0;
	}
	if(bit3_n->level   != level  ||
           bit3_n->handler != han    ||
           bit3_n->vector  != vector   )
	{
		vip 	= bit3_n;
		bit3_n 	= bit3_n->n;
		goto look_for_the_next_to_remove;
	}
	if(Va_vme_security_irq(bit3_n,current->pid) )
	{
		VMEHB1_TRACE(("        failed to remove\n"));
		return(0);
	}
	if(vip != (VIP)0) 
		vip->n = bit3_n->n;
	else
		bit3_f    = bit3_n->n;
	
	bit3_VME_irq--;
	if(bit3_n->from && bit3_n->task)
		kfree(bit3_n->from);
	kfree(bit3_n);
	bit3_n = ((VIP)0);
	return (1);
}	/* end Va_vme_free_irq	*/

/* --------------------------------------------------------- */
void	Va_vme_clear_irq()
{
	int	further;
	further = 1;
	bit3_n	= bit3_f;
look_for_the_next_to_clear:
	if(further & (bit3_n == (VIP)0))
	{
		bit3_f = ((VIP)0);
		bit3_VME_irq_id = 0;
		VMEHB1_TRACE(("VMEHB: free of added interrupts\n"));
		return;
	}
	if(Va_vme_security_irq(bit3_n,current->pid) )
	{
		VMEHB1_TRACE(("        failed to remove\n"));
		further = 0;
		return;
	}
	if(bit3_n->from && bit3_n->task)
		kfree(bit3_n->from);
	kfree(bit3_n);
	bit3_VME_irq--;
	bit3_n = bit3_n->n;
	goto look_for_the_next_to_clear;
}	/* end Vm_vme_clear_irq */

/* --------------------------------------------------------- */
void	Va_vme_list_irq()
{
	int i;
	if(!bit3_VME_irq)
	{
		printk("vmehb : no interrupt requests\n");
		return;
	}
	bit3_n	= bit3_f;
	printk("vmehb: Total of %d IRQ requests added\n",bit3_VME_irq);
	if(bit3_VME_irq_allow)
	{
		printk("       Lev: pending\n");
		for(i = 1; i < 7;i++)
			if(bit3_acks_pending(i))
				printk("        %d: %d\n",i,bit3_acks_pending(i));
	}
	printk("        Lev: vector: sig:       pid:   han:    from: \n");
look_for_the_next_to_list:
	if(bit3_n == (VIP)0)
		return;
	printk("        %3d,   %3x   %3d  %8d  %8x  %s\n"
		,bit3_n->level
		,bit3_n->vector
		,bit3_n->sig
		,(bit3_n->task    ? bit3_n->task->pid       :0)
		,(bit3_n->handler ? (int)(bit3_n->handler ) : 0)
		,(bit3_n->from   ? bit3_n->from             : "NULL")
		);
	bit3_n	= bit3_n->n;
	goto look_for_the_next_to_list;
}	/* end Va_vme_list_irq */
/* --------------------------------------------------------- */
//////////////////////////////////////////////////////////////////
// Here is the obligatory header made by all irq's connected
// via libvme , used in vme or not. Also one signal here.
void	Va_vme_mkfrom_irq(VIP	vip)
{
	/* make a standard header for non-driver users	*/
	/* any way is better than their own fancy 	*/
	if(vip == (VIP) NULL) {
		VMEHB1_TRACE(("VMEHB: Invalid vip reported by %d IRQs\n", bit3_VME_irq));
		return;
	}
	vip->from = (char *) kmalloc(sizeof(DEF_IRQ_FROM) + 40,GFP_KERNEL);
	if(vip->from == NULL) {
		VMEHB1_TRACE(("VMEHB: No mem to allocate IRQ ident\n"));
		return;
	}
	strcpy(vip->from,DEF_IRQ_FROM);
	sprintf(&(vip->from[sizeof(DEF_IRQ_FROM) - 1]),"%d:(%d,%x)"
		,bit3_VME_irq_id, vip->level,vip->vector);
	if(vip->response)
		strcat(vip->from," ACK");
}	/* end Va_vme_mkfrom_irq */
/* --------------------------------------------------------- */
void	Va_vme_test_irq()
{
#define TESTING_IRQ_IN_PROGRESS	0 /* to test by start of a driver */
#if TESTING_IRQ_IN_PROGRESS
	VIP	vip;
	/* simulating CAMAC driver  - the rest by vmecmd */
	vip = Va_vme_find_irq(4,0xca,NULL,"CAMSIM");
	vip->task = (struct task_struct *)NULL;
	Va_vme_list_irq();
	/*	/**/
#endif

}	/* end Va_vme_test_irq */

#ifndef __BIT3_REG_H
#define __BIT3_REG_H
/* add CONTRIBUTIONS  or CONT_UPD here */

/*
    vmehb - VME bus driver of PCI/VME bus adaptor Model 616-618 of Bit3.
    --------------------------------------------------------------------
    Copyright (C) May 1997  Natalia Kruszynska <natalia@nikhef.nl>
    Sponsored and instigated by 
	NIKHEF - Amsterdam
	DESY   - Hamburg
    within the technical support of Hermes Collaboration in Physics.

    Thanks for contribution in alphabetical order to:
	A.J.Aranyosi	<aja@mit.edu> for a neat 2.2 port
	Thomas Bogend	<tsbogend@alpha.franken.de> DMA on alpha PC
	Andries Brouwer <aeb@cwi.nl>
	Dave Cattermole <dmc@mrc-lmb.cam.ac.uk> testing it on alpha PC
	David Chrisman  <David.Chrisman@cern.ch> extensions for Model 618
	Marcin Dalecki  <dalecki@math.uni-goettingen.de> 
	Jay Estabrook   <jay@digital.com> DMA on alpha PC
	Lisa. G.Gorn	<gorn@phys.ufl.edu> for 618/2.2 updates and tests
	David Grothe	<dave@gcom.com>
	Eric Kasten     <kasten@ncsl.msu.edu> for a neat 2.1.90+ version
                        (grab it if you can run beta Linux)

        H.J Mathes      < mathes@ik3.fzk.de> byte access and byte spaces
	Hiroyuki Okamura<okamura@phy.saitama-u.ac.jp> (interrupts)
	Henk Peek	<henkp@nikhef.nl> 
        Klaus Schossmaier<Klaus.Schossmaier@cern.ch>
	Ruud van Wijk   <ruud@nikhef.nl>

    and to  these who are not yet listed here  and who have caught
    some hidden bug and send it to me. 

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
*/
#ifdef __KERNEL__

/**
 ** CONTENTS:
 ** The device hardware definition is copied from:
 **      Filename:   btpciio.h
 **      Purpose:    Bit 3 400-809 PCI Applications Toolkit
 **                  Adaptor Node Register Include File.
	
    The inline primitives and macros following the hardware definition
    are added by:
    Copyright (C) May 1997  Natalia Kruszynska <natalia@nikhef.nl>
*/

/******************************************************************************
**
**      Mapping Register Defines
**
******************************************************************************/
#define BIT3_LSR_BITS "\20\1CABLE\2LRCERR\3ITO\6INTPR\7RBERR\10PARERR"

#define MR_PCI_VME           0x0        /* PCI to VME Map RAM base offset       */
#define MR_PCI_VME_SIZE      0x8000     /* PCI to VME Map RAM size (bytes)      */

#define MR_VME_PCI           0x8000     /* VME to PCI Map RAM base offset       */
#define MR_VME_PCI_SIZE      0x4000     /* VME to PCI Map RAM size (bytes)      */

#define MR_DMA_PCI           0xC000     /* DMA to PCI Map RAM base offset       */
#define MR_DMA_PCI_SIZE      0x4000     /* DMA to PCI Map RAM size (bytes)      */

#define MR_BYTE_SWAP         (1<<3)     /* r/w, Byte swap bytes                 */
#define MR_WORD_SWAP         (1<<2)     /* r/w, Swap words                      */
#define MR_WBYTE_SWAP        (1<<1)     /* r/w, Byte Swap non-bytes             */
#define MR_RAM_INVALID       (1<<0)     /* r/w, Map register is invalid         */

#define VME_BYTE_SWAP        (4)     	/* r/w, Byte swap bytes                 */
#define VME_WORD_SWAP        (2)     	/* r/w, Swap words                      */
#define VME_WBYTE_SWAP       (1)        /* r/w, Byte Swap non-bytes             */

#define MR_ADDR_MASK       0xFFFFF000UL /* Mask for map address bits A31-A12    */
#define MR_REM_BUS_MASK    0x00000FFFUL /* Mask for remote address bits A11-A0  */

#define MR_AMOD_MASK       0x00000FC0UL /* Mask for address modifier bits       */
                                        /* AM5-AM0 for register bits A11-A6     */
#define MR_AMOD_SHIFT        6          /* Shift value for AMOD bits AM5-AM0    */

#define MR_FC_MASK           0x30       /* Mask for Mapping RAM Function Codes  */
#define MR_FC_RBIO           0x10       /* Remote Bus I/O Mapping function code */
#define MR_FC_RRAM           0x20       /* Remote RAM Mapping function code     */
#define MR_FC_DPRAM          0x30       /* Dual Port RAM Mapping function code  */



/******************************************************************************
**
**      Local Adaptor Node Registers
**
*******************************************************************************
**
**      Local Command Register (Read/Write, 8 Bits)
**
*******************************************************************************
**    7    |   6    |    5   |   4    |    3   |    2   |    1    |    0
** +C_STAT |+CLR_PR |+SND_PT |        |        |        |         |
******************************************************************************/

#define LOC_CMD1             (0x00)                /* Local Command Register */

#define LC1_CLR_ERROR        (1<<7)     /* w,   Clear status error bits (1 Shot) */
#define LC1_CLR_PR_INT       (1<<6)     /* w,   Clear PR (PS) Interupt (1 Shot)  */
#define LC1_SND_PT_INT       (1<<5)     /* r/w, Set PT Interupt                  */

/******************************************************************************
**
**       Local Interrupt Control Register (Read/Write, 8 Bits)
**
*******************************************************************************
**     7    |    6    |    5    |   4   |   3   |    2   |    1   |    0
** +INT_ACT | +INT_EN |+ERR_INT |   0   |   0   | +CINT2 | +CINT1 | +CINT0
******************************************************************************/

#define LOC_INT_CTRL         (0x01)      /* Local Interrupt Control Register */

#define LIC_INT_PENDING      (1<<7)     /* r  , Adaptor asserting INT on PCI bus */
#define LIC_INT_ENABLE       (1<<6)     /* r/w, Normal (PR & CINT) INT Enable */
#define LIC_ERR_INT_ENABLE   (1<<5)     /* r/w, Error Interupt Enable         */

#define LIC_PT_CINT_SEL2     (1<<2)     /* r/w, PT CINT Line Selection Bit 2  */
#define LIC_PT_CINT_SEL1     (1<<1)     /* r/w, PT CINT Line Selection Bit 1  */
#define LIC_PT_CINT_SEL0     (1<<0)     /* r/w, PT CINT Line Selection Bit 0  */


/******************************************************************************
**
**       Local Status Register (Read Only, 8 Bits)
**
*******************************************************************************
**    7    |   6    |    5   |    4    |   3   |    2   |    1   |    0
** +PARITY |+REMBUS |+PR_INT |+CARD_RDY|   0   |+TIMEOUT|+LRC_ERR|+NOCONNECT
******************************************************************************/

#define LOC_STATUS           (0x02)     /* Local Status Register  */

#define LSR_PARITY_ERR       (1<<7)     /* Interface Parity Error PCI->REM.   */
#define LSR_REMBUS_ERR       (1<<6)     /* BERR from VME on PCI->REM. xfer    */
#define LSR_PR_STATUS        (1<<5)     /* PR interrupt recieved from REMOTE  */
#define LSR_TIMEOUT_ERR      (1<<2)     /* Interface Timeout error PCI->REM   */
#define LSR_LRC_ERR          (1<<1)     /* LRC error (DMA master only)        */
#define LSR_NO_CONNECT       (1<<0)     /* REM. bus power or I/O cable is off */

#define LSR_ERROR_MASK  (LSR_PARITY_ERR|LSR_REMBUS_ERR|LSR_TIMEOUT_ERR|LSR_LRC_ERR)
#define LSR_CERROR_MASK (LSR_NO_CONNECT|LSR_ERROR_MASK)


/******************************************************************************
**
**       Local Interrupt Status Register (Read Only)
**
*******************************************************************************
**    7   |   6    |    5   |    4   |    3   |    2   |    1   |    0
** +CINT7 | +CINT6 | +CINT5 | +CINT4 | +CINT3 | +CINT2 | +CINT1 | +CINT0
******************************************************************************/

#define LOC_INT_STATUS       (0x03)     /* Local Interrupt Status Register */

#define LIS_CINT7            (1<<7)     /* Cable Interrupt 7 - CINT7         */
#define LIS_CINT6            (1<<6)     /* Cable Interrupt 6 - CINT6         */
#define LIS_CINT5            (1<<5)     /* Cable Interrupt 5 - CINT5         */
#define LIS_CINT4            (1<<4)     /* Cable Interrupt 4 - CINT4         */
#define LIS_CINT3            (1<<3)     /* Cable Interrupt 3 - CINT3         */
#define LIS_CINT2            (1<<2)     /* Cable Interrupt 2 - CINT2         */
#define LIS_CINT1            (1<<1)     /* Cable Interrupt 1 - CINT1         */

#define LIS_CINT_MASK (LIS_CINT1 | LIS_CINT2 | LIS_CINT3 | LIS_CINT4 | LIS_CINT5 | LIS_CINT6 | LIS_CINT7 )

/******************************************************************************
**
**       PCI Control Register (Read/Write)
**
*******************************************************************************
**    7   |   6    |    5   |    4   |    3   |    2   |    1   |    0
** ...... |....... |....... | ...... | ...... | +BSWW  | +RETRY | +TABORT
******************************************************************************/

#define PCI_CTRL            (0x04)	/* PCI control	                     */

/* vmehb do not use these (yet) */
#define	PCC_WSWAP_B_TRANS   (1<<2)	/* enable word swap on byte  transfer */
                                        /* when swap bit 2 is on in mapping   */
#define	PCC_RETRY	    (1<<1)      /* see man p ~87 yourself             */
#define	PCC_TABORT          (1<<0)      /* if PC blocks on interf timeout     */
			
/******************************************************************************
**
**       PCI Loopback Register (Read/Write)
**
*******************************************************************************
**    7   |   6    |    5   |    4   |    3   |    2   |    1   |    0
** ...... |....... |....... | ...... | ...... | ...... | +REMOTE| +LOCAL.
******************************************************************************/

#define PCI_LOOP           (0x05)	/* PCI loopback	                     */

/* vmehb do not use these (yet) */
#define	PCL_REMOTE          (1<<1)      /* see man p ~87 yourself             */
#define	PCL_LOCAL           (1<<0)      
			


/******************************************************************************
**
**      Remote Adaptor Registers
**
*******************************************************************************
**
**      Remote Command Register 1 (Write Only, 8 Bits)
**
*******************************************************************************
**    7    |   6    |    5    |   4    |    3   |    2   |    1   |    0  |
** +RESET  |+CLR_PT | +SND_PR |+LOCKBUS| +PGMODE| +IACK2 | +IACK1 | +IACK0|VME
**    "    |   "    |    "    |   "    |    "   |+IOPGSEL|+PRMOD1 |+PRMOD0|Q-bus
**    "    |   "    |    "    |   "    |    "   |+IOPGSEL|    0   |    0  |MBus1
******************************************************************************/

#define REM_CMD1             (0x08)             /* Remote Command Register 1 */

#define RC1_RESET_REM        (1<<7)     /* Reset remote bus - ONE SHOT       */
#define RC1_CLR_PT_INT       (1<<6)     /* PT (PM) interrupt - FROM REMOTE   */
#define RC1_SND_PR_INT       (1<<5)     /* PR (PS) interrupt - TO REMOTE     */
#define RC1_LOCK_REM_BUS     (1<<4)     /* Lock remote bus - FOR RMW ONLY    */
#define RC1_PG_SEL           (1<<3)     /* Enable page mode access           */

#define RC1_INT_ACK_A3       (1<<2)     /* IACK Read Mode Address Bit 2      */
#define RC1_INT_ACK_A2       (1<<1)     /* IACK Read Mode Address Bit 1      */
#define RC1_INT_ACK_A1       (1<<0)     /* IACK Read Mode Address Bit 0      */

#define RC1_IACK_MASK        (0x07)     /* IACK read level select mask       */


/*****************************************************************************
**
**      Remote Status Register  (Read Only, 8 Bits)
**
******************************************************************************
**    7    |    6   |    5   |    4   |    3   |   2  |   1  |   0  |
** +RRESET | IACK_1 | +PRSET | +LKNSET| +PGREG |IACK_2|+PTSET|IACK_0|VME
**    0    |    0   | +PRSET | +LKNSET| +PGMOD |   0  |+PTSET|   0  |A24,Q,MB1
*****************************************************************************/

#define REM_STATUS           (0x08)                /* Remote Status Register */

#define RSR_PR_STATUS        (1<<5)     /* PR Interrupt is set               */
#define RSR_NOT_LOCK_STATUS  (1<<4)     /* Remote bus is *NOT* locked        */
#define RSR_PG_STATUS        (1<<3)     /* Page mode access is Enabled       */
#define RSR_PT_STATUS        (1<<1)     /* PT interrupt is set               */

/* The following bits apply to A32 VMEbus products ONLY */
#define RSR_WAS_RESET        (1<<7)     /* Remote bus was reset              */
#define RSR_IACK2            (1<<2)     /* IACK Read Mode Address Bit 2      */
#define RSR_IACK1            (1<<6)     /* IACK Read Mode Address Bit 1      */
#define RSR_IACK0            (1<<0)     /* IACK Read Mode Address Bit 0      */


/******************************************************************************
**
**      Remote Command Register 2 (Read/Write, 8 Bits)
**            THIS REGISTER DOES NOT APPLY TO A24 VMEbus
**
*******************************************************************************
**      7    |     6     |     5    |     4    |   3   |   2   |   1   |   0
** +DMA_PAUS | +AMOD_SEL | +DMA_BLK | +INT_DIS | PGSZ3 | PGSZ2 | PGSZ1 | PGSZ0
******************************************************************************/

#define REM_CMD2             (0x09)             /* Remote Command Register 2 */

/* The following bits apply to A32 DMA VMEbus products only */
#define RC2_DMA_PAUSE        (1<<7)     /* DMA remote pause after 16 xfers   */
#define RC2_REM_AMOD_SEL     (1<<6)     /* Use remote address modifier  reg. */
#define RC2_DMA_BLK_SEL      (1<<5)     /* Use remote block-mode DMA operatn */
#define RC2_CINT_DISABLE     (1<<4)     /* Disable passing of rem cable intr */

/* The following bits apply to all products */
#define RC2_PG_SIZE_64K      (0x00)     /* 64K Page Size                     */
#define RC2_PG_SIZE_128K     (0x01)     /* 128K Page Size                    */
#define RC2_PG_SIZE_256K     (0x03)     /* 256K Page Size                    */
#define RC2_PG_SIZE_512K     (0x07)     /* 512K Page Size                    */
#define RC2_PG_SIZE_1MB      (0x0F)     /* 1M Page Size                      */

#define RC2_PG_SIZE_MASK     (0x0F)     /* Page Size select mask             */


/******************************************************************************
**
**      Remote Node Address Page Register (Read/Write, 16 Bits)
**
******************************************************************************/

#define REM_PAGE             (0x0A)          /* Remote Address Page Register */

#define REM_PAGE_LO          (0x0A)     /* Address page byte - A16-A23       */

/* The following define applies to A32 VMEbus products only */
#define REM_PAGE_HI          (0x0B)     /* Address page byte - A24-A31       */

#define MIN_PAGE_SHIFT       16         /* 64k is minimum size (shift value)   */
#define MAX_PAGE_SHIFT       20         /* 1MB maximum page size (shift value) */

#define QBUS_PG_MAX          (0x3F)     /* Needed for "bt_remid" to identify QBUS */


/******************************************************************************
**
**      Remote Card ID Register (Read/Write, 8 Bits)
**                              A32 Products Only
**
******************************************************************************/

#define REM_CARD_ID          (0x0C)               /* Remote Card ID Register */


/******************************************************************************
**
**      Remote Address Modifier Register (Read/Write, 8 Bits)
**                              VMEbus Products Only
**
******************************************************************************/

#define REM_AMOD             (0x0D)      /* Remote Address Modifier Register */


/******************************************************************************
**
**      IACK Read Register (Read Only)
**                             VMEbus & Q-bus Only
**
******************************************************************************/

#define REM_IACK             (0x0E)    /* IACK Read Register */

#define REM_IACK_WORD        (0x0E)    /* IACK vector-D0-D7(word)             */
#define REM_IACK_BYTE        (0x0F)    /* IACK vector-D0-D7(byte)D8-D15(word) */



/******************************************************************************
**
**      DMA Registers
**
*******************************************************************************
**
**      Local DMA Command Register (Read/Write, 8 Bits)
**
*******************************************************************************
**      7     |    6    |     5    |     4    |  3  |    2    |    1    |  0
** +LDC_START | +DP_SEL | +WRT_SEL | +D32_SEL |  0  | +INT_EN | +DMA_DN |  0
******************************************************************************/

#define LDMA_CMD             (0x10)            /* Local DMA Command Register */

#define LDC_START            (1<<7)    /* Start DMA                          */
#define LDC_DP_SEL           (1<<6)    /* DMA to Dual-Port select            */
#define LDC_WRITE_SEL        (1<<5)    /* DMA transfer direction             */
#define LDC_DMA_D32_SEL      (1<<4)    /* DMA transfer size 16 / 32 bit data */
#define LDC_DMA_INT_ENABLE   (1<<2)    /* DMA done interrupt enable          */
#define LDC_DMA_DONE         (1<<1)    /* DMA done indicator flag            */
#define LDC_DMA_ACTIVE       (1<<0)    /* DMA in progress indicator flag     */


/******************************************************************************
**
**      Local DMA Remainder Count Register (Read/Write, 8 Bits)
**
******************************************************************************/

#define LDMA_RMD_CNT         (0x11)    /* Local DMA Remainder Count Register */


/*******************************************************************************
**
**      Local DMA Packet Count Register (Read/Write, 16 Bits)
**
*******************************************************************************/

#define LDMA_PKT_CNT         (0x12)       /* Local DMA Packet Count Register  */

#define LDMA_PKT_CNT_LO      (0x12)       /* Packet Count Byte - D0-D7          */
#define LDMA_PKT_CNT_HI      (0x13)       /* Packet Count Byte - D8-D15         */

#define LDMA_MIN_DMA_PKT_SIZE 4UL         /* Minimum DMA Packet Size In Bytes   */
#define LDMA_DMA_PKT_SIZE     8UL         /* Standard DMA Packet Size Shift Val */
#define LDMA_MAX_XFER_LEN     0xFFFFFFL   /* Maximum DMA transfer Size In Bytes */


/******************************************************************************
**
**      Local DMA Address Registers (Read/Write)
**
*******************************************************************************/
#define LDMA_ADDR            (0x14)     /* Local DMA Address [indexes DMA map space] */

#define LDMA_ADDR_LO         (0x14)     /* Local DMA Address Byte - D0-D7     */
#define LDMA_ADDR_MID        (0x15)     /* Local DMA Address Byte - D8-D15    */
#define LDMA_ADDR_HI         (0x16)     /* Local DMA Address Byte - D16-D23    */



/******************************************************************************
**
**      Remote DMA Packet Length Count Register (Read/Write)
**
******************************************************************************/
#define RDMA_LEN_CNT         (0x18)            /* Remote DMA 1st packet size */


/******************************************************************************
**
**      Remote DMA Address Register (Read/Write)
**
******************************************************************************/
#define RDMA_ADDR             (0x1A)                   /* Remote DMA Address */

#define RDMA_ADDR_HI          (0x1A)   /* Remote DMA Address (A31-A16)       */
#define RDMA_ADDR_LO          (0x1C)   /* Remote DMA Address (A15-A0)        */


/******************************************************************************
**
**      Remote Slave Status Register (Read Only, 8 Bits)
**
*******************************************************************************
**    7    |   6    |    5   |    4    |   3   |    2   |    1   |    0
** +PARITY |+REMBUS |+PR_INT |+CARD_RDY|   0   |+TIMEOUT|+LRC_ERR|+NOCONNECT
******************************************************************************/

#define REM_SLAVE_STATUS     (0x1F)     /* Local Status of remote card */

#define RSS_PARITY_ERR       (1<<7)     /* Interface Parity Error Remote->PCI */
#define RSS_REMBUS_ERR       (1<<6)     /* Invalid mapping RAM access or a    */
                                        /*     data parity error occured      */
#define RSS_PR_STATUS        (1<<5)     /* PR interrupt set on the VME card   */
#define RSS_TIMEOUT_ERR      (1<<2)     /* Interface Timeout error on DMA xfer */
#define RSS_PT_STATUS        (1<<1)     /* PT interrupt set on the VME card   */
#define RSS_NO_CONNECT       (1<<0)     /* Rem. bus power / I/O cable is off  */

#define RSS_ERROR_MASK       (RSS_PARITY_ERR|RSS_REMBUS_ERR|RSS_TIMEOUT_ERR)
#define RSS_CERROR_MASK      (RSS_NO_CONNECT|RSS_ERROR_MASK)


/*--------------------------------------------------------
 * routines operating the base registers 
 * for the alpha PC sake many parameters are changed to 
 * unsigned long or to explicit u32 kernel type (alpha)
 * of bit3 PCI/VME adaptor
 *	base0	i/o port    for the csr/status registers
 *	base1	memory base for the csr/status registers
 *	base2	map registers address
 *	base3	data window address
 *	(C)	Nata, Feb 97 <natalia@nikhef.nl>
 *-------------------------------------------------------*/
/*********************************************************
 * Primitives to work with mapping registers. 
 *	base2	- base address of register window
 *	off	- MR_PCI_VME for PIO MR_DMA_PCI for DMA
 *	regno	- nr of the register
 *	return:	
 *********************************************************/
static inline u32 BIT3REG(unsigned long addr,int am,int fu,int sw,int inv) {
	return(	(((addr )& 0xfffff000  )      ) |
               	(((am   )& 0x3f        ) <<  6) |
		(((fu   )& 0x3         ) <<  4) |
		(((sw   )& 0x7         ) <<  1) | 
		(((inv  )& 0x1         )      )     );
}
#define	DMAREG(addr,sw,inv) BIT3REG(addr,0,0,((sw) & 0x3),inv)
static inline int Bit3_p_set(unsigned long base2,int off,int regno,u32 val)
{
	writel(val,base2 + off + 4 * regno);
#ifdef	BIT3_DEBUG
	if(regno < 8 || regno > 0x1ffa)
#endif
 	BIT3_TRACE(("Bit3_p_set: reg%x = %x, addr %lx \n"
			,regno,val,base2+off+4*regno)); /**/
	return 0;
}
static inline int Bit3_p_get(unsigned long base2,int off,int regno)
{
	int val;
	val = readl(base2 + off + 4 * regno);
	/* BIT3_TRACE(("Bit3_p_get: reg%x = %x, addr %lx \n"
			,regno,val,base2 + 4*regno));/* */
	return val;
}
/*
 * We do a proper searching for PIO access for mmap only, assuming
 * first "act" pages reserved for PIO read/write forever, thus for 
 * read/write we use Bit3_map_alloc and for mmap Bit3_map_find
 * The Vm_act_pages would be made to reserve read pages by the start
 * and ev later by the pio-active ioctls
 */
static inline int Bit3_map_find(unsigned long base2,int off,int len, int act)
{
	int i,j;
	if(act == 0)
		return(0);
	/* for mmap, only over the first offset			   */
	/* seek the gap with len regs set to 1	& return the begin */
	if(off !=  MR_PCI_VME)
	{
		return(-1);
	}
	/* this makes the first fit				  */
	for( i = act ,j = 0;i < (MR_PCI_VME_SIZE >> 2);i++)
	{
next_i:
		if((readl(base2 + off + 4 * (i)) & 1 ) == 0)
			continue;
		if(len == 1)
		{
			BIT3_TRACE(("pos found [%d,%d] len %d\n",i,i,len));
			return(i);
		}
		BIT3_TRACE(("begin at %d\n",i));
		for(j = 1;j < len;j++)
		{
			if((readl(base2 + off + 4 * (i + j)) & 1 ) == 0)
			{
				i +=  j;
				goto next_i;
			}
		}
		BIT3_TRACE(("pos found [%d,%d] len %d\n",i,i+j - 1,len));
		return(i);
	}
	return(-1);
}
#define	Bit3_map_alloc(a,b,c)  Bit3_map_find((a),(b),(c),(0))
static inline int Bit3_map_free(unsigned long base2,int off,int len)
{
	int i;
	/* write 1 to all the regs allocated */
	for(i = 0;i < len;i++)
		Bit3_p_set(base2,off,i,1);
	return(0);
}
#ifdef	BIT3_DEBUG
static inline void Bit3_map_dump(unsigned long base2,int off,int len)
{
	int i,val;
	/* read all the regs from off to off + len */
	for(i = 0;i < len;i++)
	{
		if((i  % 8) == 0)
			BIT3_TRACE(("\n"));
		val = readl(base2 + off + 4 * i);
		BIT3_TRACE(("%8x ",val));
	}
	BIT3_TRACE(("\n"));
	return;
}
#else
#define Bit3_map_dump(base2,off,len)
#endif
/*********************************************************
 * Primitives to work with control/status registers. 
 *	base0	- base port    of CSR window
 *	base1	- base address of CSR window
 *	return	
 *********************************************************/
static void DUMP_REGISTERS(unsigned long base0)
{
	char	regset[34];
	int	i;
	int	val[34];
	for(i = 0;i<32;i++) {regset[i] = (char)0;val[i] =0; };
	for(i = 0;i<32;i++)
	{ 
		/* to avoid faulty and not needed VME transfer	*/
		if(i == 14 || i == 15)
			continue;
		/* to omit another reserved fields		*/
		if( i == 5 || i == 6 || i == 7 )
			continue;
		if(i == 23 || i == 25 || i == 31)
			continue;
		regset[i]	= inb(base0 + i); 
		val[i]		= 0xff & regset[i];
	}
	for(i = 0;i <32;i = i + 8)
	{  
		BIT3_TRACE(("%2d: %2x %2x %2x %2x %2x %2x %2x %2x\n"
			,i
			,val[i    ] ,val[i + 1],val[i + 2],val[i + 3]
			,val[i + 4] ,val[i + 5],val[i + 6],val[i + 7]
			));
	}
}
#define	BIT3ADDR(addr)	((addr) & 0xfffff000)
#define	BIT3OFF (addr)	((addr) & 0xfff     )
#define	BIT3PACK( len)	(( (len) & 0xffffff) >> 8)
#define	BIT3REMC( len)  (((len) - (BIT3PACK(len) << 8)) & 0xff)

#ifndef	BIT3_INIT_RETRY
#	define	BIT3_INIT_RETRY	5
#endif
#define     IO_ORIENTED_CSR /**/
#ifdef IO_ORIENTED_CSR
static inline int BIT3LOC_COMMAND(int clear_status,int clear_PR,int send_PT) 
{
	int c;
	c = 0;
	if(clear_status)
		c  |=  LC1_CLR_ERROR;
	if(clear_PR)
		c  |= LC1_CLR_PR_INT;
	if(send_PT)
		c  |= LC1_SND_PT_INT;
	return(c);
}
static inline int BIT3INT_COMMAND(int ena,int err_ena,int pt_int)
{
	int c;
	c = 0;
	if(ena)
		c |= LIC_INT_ENABLE;
	if(err_ena)
		c |= LIC_ERR_INT_ENABLE;
	if(pt_int)
		c |= (pt_int & 0x3);
	return c;
}
static inline void Bit3_r_set(unsigned long base0,int regno,u32 val)
{ 
	outb(val,base0 + regno); 
 	BIT3_TRACE(("Bit3_c_set: reg%x = %x  \n" ,regno,val)); /**/
}
static inline int Bit3_r_get(unsigned long base0,int regno)
{ 
	int i; 
	i = inb(base0 + regno); 
 	BIT3_TRACE(("Bit3_c_get: reg%x = %x  \n" ,regno,i)); /**/
	return i;
}
static inline int Bit3_irq_alien(unsigned long base0)
{
	int v;
	v = inb(base0 + LOC_INT_CTRL);
 	BIT3_TRACE(("Bit3_irq_a: reg%x = %x  \n" ,LOC_INT_CTRL,v)); /**/
	if(v & LIC_INT_PENDING)
		return 0;  /* not alien */
	return 1;
}
static inline int Bit3_init(unsigned long base0)
{
	int i;
	BIT3_TRACE(("Bit3_init: I/O oriented access to CSR/STATUS via port base0 on %lx\n", bit3_base0));
	for(i = 0;i < BIT3_INIT_RETRY;i++)
	{
		inb(base0 + LOC_STATUS);
		inb(base0 + REM_STATUS);
		outb(LC1_CLR_ERROR,	base0 + LOC_CMD1);
		inb(base0 + LOC_STATUS);
		if((inb(base0 + LOC_STATUS) & LSR_NO_CONNECT) == 0)
		{
			i = 0;
			i = inb(base0 + REM_CARD_ID);
			return i;
		}
	}
	VMEHB2_TRACE(("Bit3_init: VME dev probably not powered on\n"));
	return(-1);
} /* end Bit3_init */
static inline int  BIT3DMA_COMMAND(int mod, int fu, int rw, int ena)
{
	int c;
	c = 0;
	if(mod > 2)
		c |= LDC_DMA_D32_SEL;
	if(fu == 2)
		c |= LDC_DP_SEL;
	if(rw)
		c |= LDC_WRITE_SEL;
	if(ena)
		c |= LDC_DMA_INT_ENABLE;
	BIT4_TRACE(("BIT3DMA_COMMAND: o %x\n",c));
	return(c);
}
static inline void Bit3_ldma(unsigned long base0, int regno, int addr,int len,int cmd)
{
	/* preload command  without start bit & read/only bit 		*/
	outb(cmd & 0x77,              base0 + LDMA_CMD	   );
	/* PCI DMA address  (tested o.k.) 				*/
	/* addr & 0xfff 		-  0-11 			*/
	/* regno			- 12-23				*/
	outw((addr & 0xfff) | ((regno & 0xf) << 12),base0 + LDMA_ADDR    );
	outb((regno >>  4 ) & 0xff                 ,base0 + LDMA_ADDR + 2);
	/* packeting in 0x100 						*/
	outb(BIT3REMC(len),           base0 + LDMA_RMD_CNT );
	outw(BIT3PACK(len),           base0 + LDMA_PKT_CNT );
	BIT3_TRACE(("LDMA COMP :  %x "
		,(addr & 0xfff) | ((regno & 0xf) << 12)
		));
	BIT3_TRACE((" %x  from reg %x addr %x\n"
		,(regno >>  4) & 0xff
		,regno
		,addr
		));
}
static	inline u32 Bit3_err_addr(unsigned long base0) 
{
	u32 val;
	val  = (inw(base0 + RDMA_ADDR_HI) << 16  ) & 0xffff0000;
	val += (inw(base0 + RDMA_ADDR_LO) & 0xffff);
	return(val);
}
static inline void Bit3_rdma(unsigned long base0,int vadr, int len)
{
	/* VME DMA address  */
	outw((vadr >> 16),            base0 + RDMA_ADDR_HI );
	outw((vadr & 0xffff),         base0 + RDMA_ADDR_LO );
	/* packeting in 0x100 */
	outb(BIT3REMC(len),           base0 + RDMA_LEN_CNT );
	BIT3_TRACE(("RDMA         : vaddr %x, count %x rem %x\n",vadr,len,BIT3REMC(len)));
}
static inline void Bit3_lreg(unsigned long base0,int ena,int mode, int am)
{
	int val;
	char *c = (char *)&val;
	/* LOC_INT_CTRL register	*/
	val= 0;
	val = 0xff & inb(base0 + LOC_INT_CTRL);
	if (ena)
	{
		val |= LIC_INT_ENABLE;
	}
	else
	{
		val &= ~LIC_INT_ENABLE;		
	}
	BIT3_TRACE(("LOC_INTR_CTRL:	%x\n",val));
	outb(*c,base0 + LOC_INT_CTRL);
	val = 0;
	/* val = inb(base0 + REM_CMD2) & 0xff; /**/
	val |= mode;
	outb(*c,base0 + REM_CMD2); 
	BIT3_TRACE(("REM_CMD2     :	%x\n",val));
	outb(am, base0 + REM_AMOD);
	BIT3_TRACE(("REM_AMOD     :	%x \n",am));
	return;
} /* end Bit3_lreg	*/
static	inline void	Bit3_clear_status(unsigned long base0) { 
	outb(0x00,base0 + LDMA_CMD);
	inb(base0 + LOC_STATUS);
	/* inb(base0 + REM_STATUS); /* OUT TEST_ONLY */
	outb(LC1_CLR_ERROR,	base0 + LOC_CMD1);
	outb(0xc0,base0 + LOC_CMD1);
}
static	inline	int	Bit3_set_intr(unsigned long base0, 
		int normal, int remote_error, int pt_level)
{
	int a;
	a = 0xff & inb(base0 + LOC_INT_CTRL);
	BIT4_TRACE(("LOC_INT_CTRL setting by Bit3_set_intr %x\n",a));
	if(a & LIC_INT_PENDING)
	{
	   a &= ~LIC_INT_PENDING;
	   BIT4_TRACE(("vmehb: Bit3_set_intr: pending interrupt ? LOC_INTR_COTRL %x\n",a));
	}
	/* PR & CINT enable	*/
	if(normal) 
		a |=  LIC_INT_ENABLE;
	else
		a &= ~LIC_INT_ENABLE;
	/* Error   INT enable	*/
	if(remote_error)
		a |=  LIC_ERR_INT_ENABLE;
	else
		a &= ~LIC_ERR_INT_ENABLE;
	a &= 0xfc;
	/* PT enable		*/
	if(pt_level && pt_level < 8)
		a  |= pt_level;
	BIT3_TRACE(("Bit3_set_interrupt: to %x\n",a));
	outb(a,   base0 + LOC_INT_CTRL);
	return(0);
} /* end int Bit3_set_intr */

static inline int Bit3_vme_intr(unsigned long base0, int ena)
{
	// to enable/disable backplane interrupt passing
	int a;
	a = 0xff & inb(base0 + REM_CMD2);
	if(ena)
	{ a &= ~RC2_CINT_DISABLE;VMEHB1_TRACE(("        ..remote IRQ  enabled %x\n",a));}
	else
	{ a |= RC2_CINT_DISABLE; VMEHB1_TRACE(("        ..remote IRQ disabled %x\n",a));}
	outb(a,	base0 + REM_CMD2);
}


/* no inline because of polling facilities & tests */
static	inline void Bit3_dma_stop(unsigned long base0) 
{
	char c = 0;
	int val1,val2;
	c = 0xff & inb(base0 + LDMA_CMD);
	val1 = c & 0xff;
	c &= ~LDC_DMA_INT_ENABLE;
	c &= ~LDC_START; /**/
	outb((c) ,   base0 + LDMA_CMD);
	return;
}
static	void Bit3_dma_start(unsigned long base0, int ena )
{
	int act	= 0;
	int val = 0; 	/* common counter here */
	int val1,val2,val3;
	char c = 0;
	val1= 0;
	if(ena < 0)
		act = -ena;
	else
		act = 0;
paranoia_check:
	c = 0xff & inb(base0 + LDMA_CMD);
	/* dump registers to dmesg 
	for(val1 = 0; val1 < 32; val1++) {
		if(val1 == 0xe || val1 == 0xf) continue;
		printk("vmehb: %3d - %4x\n",val1,0xff & inb(base0 + val1));
	}
	/**/
	val1 = c & 0xff;
	if(c & LDC_DMA_ACTIVE)
	{
		val= 0;
		printk("vmehb: paranoia check on DMA still active... %x\n!!!!!!",val1);
		goto paranoia_check;
	}
	if(ena)
		c |= LDC_DMA_INT_ENABLE;
	c |= LDC_START; /**/
	val1 = 0xff & c;
	BIT4_TRACE(("LDMA_CMD     :	%x ( starting DMA )\n",val1));
	outb((c) ,   base0 + LDMA_CMD);
	if(ena > 0)
	{
		return;
	}
	/* POLL mode only */
dma_active:
	printk("vmehb: poling for DMA done\n");
	c = inb(base0 + LDMA_CMD);
	val1 = c & 0xff;
	if(c & LDC_DMA_ACTIVE)
	{
		if(act < 1000)
			udelay(ena);
		if(act >= 1000)
		{
			val++;
			current->state = TASK_INTERRUPTIBLE;
			if(val > 10)
			{
				SYS_TRACE(("10 times scheduled\n"));
				val = 0;
			}
#ifdef LIN2_2
			schedule_timeout(jiffies + 1); // lovely one from AJA
#else
			current->timeout	= jiffies + 1; /**/
			schedule();
#endif
		}
		goto dma_active;
	}
	return ;
}
#else /* MEMORY_ORIENTED_CSR */
#include	"bit3_mem.h"
#endif /* MEMORY or IO_ORIENTED_CSR */
#endif /* KERNEL */
/* __BIT3_REG_H */
#endif

#ifndef VMEHB_IOCTL_H
#define VMEHB_IOCTL_H
/* add CONTRIBUTIONS or CONT_UPD here */

/*
    vmehb - VME bus driver of PCI/VME bus adaptor Model 616-618 of Bit3.
    --------------------------------------------------------------------
    Copyright (C) May 1997  Natalia Kruszynska <natalia@nikhef.nl>
    Sponsored and instigated by 
	NIKHEF - Amsterdam
	DESY   - Hamburg
    within the technical support of Hermes Collaboration in Physics.

    Thanks for contribution in alphabetical order to:
	A.J.Aranyosi	<aja@mit.edu> for a neat 2.2 port
	Thomas Bogend	<tsbogend@alpha.franken.de> DMA on alpha PC
	Andries Brouwer <aeb@cwi.nl>
	Dave Cattermole <dmc@mrc-lmb.cam.ac.uk> testing it on alpha PC
	David Chrisman  <David.Chrisman@cern.ch> extensions for Model 618
	Marcin Dalecki  <dalecki@math.uni-goettingen.de> 
	Jay Estabrook   <jay@digital.com> DMA on alpha PC
	Lisa. G.Gorn	<gorn@phys.ufl.edu> for 618/2.2 updates and tests
	David Grothe	<dave@gcom.com>
	Eric Kasten     <kasten@ncsl.msu.edu> for a neat 2.1.90+ version
                        (grab it if you can run beta Linux)

        H.J Mathes      < mathes@ik3.fzk.de> byte access and byte spaces
	Hiroyuki Okamura<okamura@phy.saitama-u.ac.jp> (interrupts)
	Henk Peek	<henkp@nikhef.nl> 
        Klaus Schossmaier<Klaus.Schossmaier@cern.ch>
	Ruud van Wijk   <ruud@nikhef.nl>

    and to  these who are not yet listed here  and who have caught
    some hidden bug and send it to me. 

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
*/
/* 
    CONTENTS:
    This file contains the ioctl structures and should be made available
    to the users of the driver ( e.g. /usr/include/local ). It is used
    by the driver itself as well.
    Copyright (C) May 1997  Natalia Kruszynska <natalia@nikhef.nl>
*/
#ifndef __KERNEL__
/****************************************************************
** Configuration info format of vme minors +  flags definitions
----------------------------------------------------------------*/
struct vme_dev {
/* VME devices configuration data */
	char 	name[10];
	int	minor;
	int	am;	/* VME address modifier			*/
	int	mod;	/* 2 or 4				*/
	int	dmamod;	/* DMA MODE flag value,see below	*/
	int	swap;   /* SWAP flags, see below		*/
	int	fu;	/* 1 - VME 2 - Dual Port 3 - VME RAM	*/
	int	pio;	/* MAX len serviced by PIO < 0x1000	*/
	unsigned long	
		maxad;	/* MAX addressing,eg ffff for a16	*/
};


/* SWAP flags , can be |' ed 			*/
#define	NO_SWAP			0
#define	BYTE_SWAP_NON_BYTE	1
#define	WORD_SWAP		2
#define	BYTE_SWAP_BYTE_D	4

/* DMA MODE flag value				*/
#define	NO_BLOCK		0
#define	RC2_DMA_BLK_SEL		(1 << 5)
#define	RC2_DMA_PAUSE  		(1 << 7)

/****************************************************************
** What is needed to connect VME bottom interrupt services from
** particular VME devices which can need their own cleanup, 
** The fields with  D  in comment  are to be left unfilled
*****************************************************************/
typedef int (*VME_HAN)(int,int); //this one is defined for __KERNEL 

#endif 

struct	irq_data {
/* VME interrupts handling, incl ev local handler 		*/
	int	level;		/* on the level    		*/
	int	vector; 	/* vector, if any  		*/
	int	sig;		/* signal to respond or 0 	*/
	int	response;	/* for ACK'ing			*/
	/* if you have to handle something,  for RORA devices	*/
        VME_HAN handler; 	/* your handler entry point	*/
};
/****************************************************************/

/* registered command & function range 		*/
#define VMEIOC		'b'
#define VMEMINFUN 	0x0
#define VMEMAXFUN 	0x3f

/* setting driver mode parameters   */
#define	VME_SET_MODE		1
#define	VME_CLR_MODE		0
#define VME_CHK_MODE		50 /* standard PIO delay in usecs */

/* setting VME_ACK and VME_NACK to fit irq needs */
#define VME_ACK			1
#define VME_NACK		0
/* 
 *  ioctls 0 and 1 allow to change the choosen parameters
 *  of the setting of vme spaces. The partial action is
 *  put on by ioctl's 5-6. Set actions are for su only.
 *  who takes the responsibility of making it o.k. 
 *  The best way is to get the structure and change as
 *  little as possible and to put permanent changes in the
 *  compile time in vmehb_conf.h
 */

#define VME_GET_SPACE		_IOR(VMEIOC,0,struct vme_dev)
#define VME_SET_SPACE		_IOW(VMEIOC,1,struct vme_dev)

/*
 *  ioctl 2 with VME_CHK_MODE puts the driver into diagnostic
 *  mode, i/e all the devices are checked under memory mapped
 *  access, delayed so that the VME BERR is diagnosed o.k.
 *          with VME_CLR_MODE puts the choice further
 */
#define	VME_CHECK_ACCESS	_IOW(VMEIOC,2,int) 

/*
 * ioctl 3 with VME_SET_MODE puts the driver into slow 
 * control mode, PIO only but no delay, mmap allowed
 *         with VME_CLR_MODE the su chooses the standard DACQ
 *	   mode with DMA, but no mmap.
 */
#define VME_SLOW_CONTROL	_IOW(VMEIOC,3,int)

/*
 * ioctl 4 with VME_SET MODE chooses IRQ as DMA service ( default)
 *         with VME_CLR_MODE chooses polling for DMA done
 */
#define	VME_DMA_CONTROL		_IOW(VMEIOC,4,int)


/*
 *  ioctl 5 takes as the parameter VME ADDRESS MODIFIER 
 * ( see specs of VME bus)
 */
#define	VME_SET_AM		_IOW(VMEIOC,5,int)

/*
 *   DMA on VME side can work in 3 modes, take care that the mode
 *   fits the ADDRESS MODIFIER of the VME device accessed
 *   	block 	  - arbitrage each 256 bytes RC2_DMA_BLK_SEL
 *	pause 	  - arbitrage each  64 bytes RC2_DMA_PAUSE
 *      non block - arbitrage each transfer  VME_CLR_MODE
 */
#define VME_SET_DMAMOD		_IOW(VMEIOC,6,int)

/*
 *	ioctl 10 and 11 are returning success on the current
 *	state of power on VME crate, error if it does not fit.
 *	su changes to the requested state.
 * 	ioctl 12 shows the status
 */

#define VME_CRATE_OFF		_IO(VMEIOC,10)
#define	VME_CRATE_ON		_IO(VMEIOC,11)
#define	VME_GET_CRATE		_IOR(VMEIOC,12,int)

/*
 *	ioctl 13,14,15    are coupling the user to the interrupts.
 *      ioctl 16 is only for suser
 *      ioctl 17 is informative only 
 */
#define VME_IRQ_ACK		_IOW(VMEIOC,13,struct irq_data)
#define VME_IRQ_REQUEST		_IOW(VMEIOC,14,struct irq_data)
#define VME_IRQ_FREE		_IOW(VMEIOC,15,struct irq_data)
#define VME_IRQ_CLEAR		_IO(VMEIOC,16)
#define VME_IRQ_LIST		_IO(VMEIOC,17)

/*
 *	ioctl 40 reset the VMEbus (H. Okamura)
 */
#define	VME_RESET		_IO(VMEIOC,40)

/*
 * 	ioctl 61 frees all the pio memory 
 */
#define	VME_CLEAR_MAPS		_IO(VMEIOC,61)

/*
 *	ioctl 62 ( the one before the last reserved) is used to 
 *	trace ev deadlocks of driver( so called "coma").  
 */
#define	VME_TRACE_ZOMBIES	_IO(VMEIOC,62)

/*
 *	ioctl 63 ( the last reserved ) is triggering the system 
 *      trace (if any)	into /var/log/syslog
 */
#define	VME_TRACE_INFO		_IO(VMEIOC,63)

/*     VMEHB_IOCTL_H */
#endif

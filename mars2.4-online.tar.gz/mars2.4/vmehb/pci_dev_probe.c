/* add CONTRIBUTIONS or CONT_UPD here */

/*
    vmehb - VME bus driver of PCI/VME bus adaptor Model 616-618 of Bit3.
    --------------------------------------------------------------------
    Copyright (C) May 1997  Natalia Kruszynska <natalia@nikhef.nl>
    Sponsored and instigated by 
	NIKHEF - Amsterdam
	DESY   - Hamburg
    within the technical support of Hermes Collaboration in Physics.

    Thanks for contribution in alphabetical order to:
	A.J.Aranyosi	<aja@mit.edu> for a neat 2.2 port
	Thomas Bogend	<tsbogend@alpha.franken.de> DMA on alpha PC
	Andries Brouwer <aeb@cwi.nl>
	Dave Cattermole <dmc@mrc-lmb.cam.ac.uk> testing it on alpha PC
	David Chrisman  <David.Chrisman@cern.ch> extensions for Model 618
	Marcin Dalecki  <dalecki@math.uni-goettingen.de> 
	Jay Estabrook   <jay@digital.com> DMA on alpha PC
	Lisa. G.Gorn	<gorn@phys.ufl.edu> for 618/2.2 updates and tests
	David Grothe	<dave@gcom.com>
	Eric Kasten     <kasten@ncsl.msu.edu> for a neat 2.1.90+ version
                        (grab it if you can run beta Linux)

        H.J Mathes      < mathes@ik3.fzk.de> byte access and byte spaces
	Hiroyuki Okamura<okamura@phy.saitama-u.ac.jp> (interrupts)
	Henk Peek	<henkp@nikhef.nl> 
        Klaus Schossmaier<Klaus.Schossmaier@cern.ch>
	Ruud van Wijk   <ruud@nikhef.nl>

    and to  these who are not yet listed here  and who have caught
    some hidden bug and send it to me. 

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
*/
/*
   CONTENTS:PCI probe, info and other functions 
   of general use for (almost) any PCI device
   Now adjusted also for 2.2
*/
            
/**************************************************************************
* Function :void pci_dev_info(pci_config_t pci_config,char *drv) 
*
* Purpose : prints the config data of the PCI device got with PCI Bios
*  	 source GNU-stolen from one of scsi drivers 
**************************************************************************/
void pci_dev_info(pci_config_t	pci_config,char * drv)
{
printk("------------- start of PCI register dump  for %s ---------\n",drv);
printk("PCI_VENDOR_ID:       0x%x\n", pci_config._vendor);
printk("PCI_DEVICE_ID:       0x%x\n", pci_config._device);
printk("PCI_COMMAND:         0x%x        %s mapped\n", pci_config._command
    	,((pci_config._command & PCI_COMMAND_IO)  ? "IO" : "mem")
	);
printk("PCI_STATUS:          0x%x\n", pci_config._status);
printk("PCI_CLASS_REVISION:  0x%x\n", pci_config._class_revision);
printk("PCI_CACHE_LINE_SIZE: 0x%x\n", pci_config._cache_line_size);
printk("PCI_LATENCY_TIMER:   0x%x\n", pci_config._latency_timer);
printk("PCI_HEADER_TYPE:     0x%x\n", pci_config._header_type);
if(pci_config._base0)
printk("PCI_BASE_ADDRESS_0:  0x%x\n", pci_config._base0);
if(pci_config._base1)
printk("PCI_BASE_ADDRESS_1:  0x%x\n", pci_config._base1);
if(pci_config._base2)
printk("PCI_BASE_ADDRESS_2:  0x%x\n", pci_config._base2);
if(pci_config._base3)
printk("PCI_BASE_ADDRESS_3:  0x%x\n", pci_config._base3);
if(pci_config._base4)
printk("PCI_BASE_ADDRESS_4:  0x%x\n", pci_config._base4);
if(pci_config._base5)
printk("PCI_BASE_ADDRESS_5:  0x%x\n", pci_config._base5);
printk("PCI_INTERRUPT_LINE:  %d\n", pci_config._int_line);
printk("PCI_INTERRUPT_PIN:   %d\n", pci_config._int_pin);
printk("PCI_MIN_GRANT:       %d\n", pci_config._min_gnt);
printk("PCI_MAX_LATENCY:     %d\n", pci_config._max_lat);
printk("------------- end of PCI register dump -------------\n\n");
}
/**************************************************************************
* Function : int pci_dev_config ( pci_config_t	*pci_config)
*
* Purpose : detects and initializes bit3 model 617 adapter  with PCI Bios
*  	 source GNU_stolen from one of scsi drivers 
**************************************************************************/
int pci_dev_config(int vendor, int device,pci_config_t	*pci_config,char *drv)
{
#ifdef	LIN2_2
/* Now some things are organized  by system itself, so define  and use it*/
	struct pci_dev	*dev = NULL;
#	define	pci_bus	        dev->bus->number
#	define  pci_device_fn	dev->devfn
	if((dev = pci_find_device(vendor,device,dev)) == NULL) {
#else
    int	pci_index	= 0;	  
    unsigned char pci_bus, pci_device_fn;
    if (pcibios_find_device(	vendor, 
			    	device, 
				pci_index, 
				&pci_bus, 
   				&pci_device_fn) != 0)
    {
#endif LIN2_2
	printk("PCI %s: config can not find the device %x %x\n"
			,drv
			,vendor
			,device
			);
       return 0;
    }
#ifdef	LIN2_2
	// configure_device(dev);
#endif	LIN2_2
	printk("PCI %s: config  the device %x %x on bus %d fn %d \n"
			,drv
			,vendor
			,device
			,pci_bus & 0xff
			,pci_device_fn & 0xff
			);
    pcibios_read_config_word(pci_bus, pci_device_fn, PCI_VENDOR_ID, &pci_config->_vendor);
    pcibios_read_config_word(pci_bus, pci_device_fn, PCI_DEVICE_ID, &pci_config->_device);
    pcibios_read_config_word(pci_bus, pci_device_fn, PCI_COMMAND, &pci_config->_command);
    pcibios_read_config_word(pci_bus, pci_device_fn, PCI_STATUS, &pci_config->_status);
    pcibios_read_config_dword(pci_bus, pci_device_fn, PCI_CLASS_REVISION, &pci_config->_class_revision);
    pcibios_read_config_byte(pci_bus, pci_device_fn, PCI_CACHE_LINE_SIZE, &pci_config->_cache_line_size);
    pcibios_read_config_byte(pci_bus, pci_device_fn, PCI_LATENCY_TIMER, &pci_config->_latency_timer);
    pcibios_read_config_byte(pci_bus, pci_device_fn, PCI_HEADER_TYPE, &pci_config->_header_type);
    pcibios_read_config_byte(pci_bus, pci_device_fn, PCI_BIST, &pci_config->_bist);
    pcibios_read_config_dword(pci_bus, pci_device_fn, PCI_BASE_ADDRESS_0, &pci_config->_base0);
    pcibios_read_config_dword(pci_bus, pci_device_fn, PCI_BASE_ADDRESS_1, &pci_config->_base1);
    pcibios_read_config_dword(pci_bus, pci_device_fn, PCI_BASE_ADDRESS_2, &pci_config->_base2);
    pcibios_read_config_dword(pci_bus, pci_device_fn, PCI_BASE_ADDRESS_3, &pci_config->_base3);
    pcibios_read_config_dword(pci_bus, pci_device_fn, PCI_BASE_ADDRESS_4, &pci_config->_base4);
    pcibios_read_config_dword(pci_bus, pci_device_fn, PCI_BASE_ADDRESS_5, &pci_config->_base5);
    pcibios_read_config_dword(pci_bus, pci_device_fn, PCI_ROM_ADDRESS, &pci_config->_baserom);
    pcibios_read_config_byte(pci_bus, pci_device_fn, PCI_INTERRUPT_LINE, &pci_config->_int_line);
#ifdef LIN2_2
	if(dev != (struct pci_dev *)NULL && pci_config->_int_line != dev->irq) {
		printk("PCI VME interrupt line %x  remapped %x\n"
			,pci_config->_int_line,dev->irq);
		pci_config->_int_line = dev->irq;
	}
#endif
    pcibios_read_config_byte(pci_bus, pci_device_fn, PCI_INTERRUPT_PIN, &pci_config->_int_pin);
    pcibios_read_config_byte(pci_bus, pci_device_fn, PCI_MIN_GNT, &pci_config->_min_gnt);
    pcibios_read_config_byte(pci_bus, pci_device_fn, PCI_MAX_LAT, &pci_config->_max_lat);
    pci_config->_pcibus = 0xFFFFFFFF;
    pci_config->_cardnum = 0xFFFFFFFF;
 
    /* check whether device is I/O mapped -- should be 
    if (!(pci_config->_command & PCI_COMMAND_IO)) 
		return 0;
	*/

    /* PCI Spec 2.1 states that it is either the driver's or the PCI card's responsibility
       to set the PCI Master Enable Bit if needed. 
       (from Mark Stockton <marks@schooner.sys.hou.compaq.com>) */
    if (!(pci_config->_command & PCI_COMMAND_MASTER)) {
       pci_config->_command |= PCI_COMMAND_MASTER;
       printk("PCI Master Bit has not been set. Setting...\n");
       pcibios_write_config_word(pci_bus, pci_device_fn, PCI_COMMAND, pci_config->_command); }
    /* test the access  in dev oriented routine*/
    return(1);
}

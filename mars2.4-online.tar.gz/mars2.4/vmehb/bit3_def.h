#ifndef	__BIT3_DEF_H
#define	__BIT3_DEF_H

/* add CONTRIBUTIONS or CONT_UPD here */

/*
    vmehb - VME bus driver of PCI/VME bus adaptor Model 616-618 of Bit3.
    --------------------------------------------------------------------
    Copyright (C) May 1997  Natalia Kruszynska <natalia@nikhef.nl>
    Sponsored and instigated by 
	NIKHEF - Amsterdam
	DESY   - Hamburg
    within the technical support of Hermes Collaboration in Physics.

    Thanks for contribution in alphabetical order to:
	A.J.Aranyosi	<aja@mit.edu> for a neat 2.2 port
	Thomas Bogend	<tsbogend@alpha.franken.de> DMA on alpha PC
	Andries Brouwer <aeb@cwi.nl>
	Dave Cattermole <dmc@mrc-lmb.cam.ac.uk> testing it on alpha PC
	David Chrisman  <David.Chrisman@cern.ch> extensions for Model 618
	Marcin Dalecki  <dalecki@math.uni-goettingen.de> 
	Jay Estabrook   <jay@digital.com> DMA on alpha PC
	Lisa. G.Gorn	<gorn@phys.ufl.edu> for 618/2.2 updates and tests
	David Grothe	<dave@gcom.com>
	Eric Kasten     <kasten@ncsl.msu.edu> for a neat 2.1.90+ version
                        (grab it if you can run beta Linux)

        H.J Mathes      < mathes@ik3.fzk.de> byte access and byte spaces
	Hiroyuki Okamura<okamura@phy.saitama-u.ac.jp> (interrupts)
	Henk Peek	<henkp@nikhef.nl> 
        Klaus Schossmaier<Klaus.Schossmaier@cern.ch>
	Ruud van Wijk   <ruud@nikhef.nl>

    and to  these who are not yet listed here  and who have caught
    some hidden bug and send it to me. 

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
*/
/*
    CONTENTS:
    The software structure of the driver is defined here
    Batch of constants & macro's 
*/
/****************************************************************
** PCI configuration of bit3 & AMCC devices
*****************************************************************/
#define PCI_VENDOR_ID_BIT3		0x108a
// Model 617
#define PCI_DEVICE_ID_BIT3_VME		0x1
// Model 616
#define PCI_DEVICE_ID_BIT3_VME_616	0x3
// for other PCI device drivers ......
#define PCI_DEVICE_ID_AMCC_KIT		0x4750


#include	"pci_info.h"	/**/

/****************************************************************
** BIT3 configuration constants	
*****************************************************************/
#ifndef BIT3_MAJOR
#define	BIT3_MAJOR		62
#endif
#define	BIT3_IRQ		5
#define BIT3_DMA_AHEAD		0	/* write to/from user	*/
					/* concurrent to DMA	*/
#define VME_READ		0	/* user space copy	*/
#define VME_WRITE		2
#define VME_DEV_READ		0x10	/* kernel space copy	*/
#define VME_DEV_WRITE		0x12

#define VERIFY_NONE	(VERIFY_READ + VERIFY_WRITE + 42)

/* for alpha PC several types changed from int to usnigned long */
/****************************************************************
** What is needed to service the request
*****************************************************************/
struct	io_ahead {
/* general control */
	int	pid;		/* caller pid for control	*/
	unsigned long	
		devp;		/* address to devp for multidev	*/
	int	acc;		/* 0 for PIO 1 for DMA		*/
	int	rw;		/* 0 read    2 write		*/
	int	vadr;		/* VME addr			*/
	int	align;		/* align the addr for VME access*/
	volatile	int	
		error;		/* ev errors on transfer	*/
/* mapping details */
	int	n_map;		/* starting map register	*/
	int	n_len;		/* len of mapping		*/
/* PIO only part */
	int	vam;		/* PIO vme address modifier	*/
	int	off;		/* offset to first page addr	*/
/* DMA part */
	volatile	unsigned long	
		addr;		/* PCI addr			*/
	int	dam;		/* DMA vme address modifier	*/
};
/* we will communicate via pointer uio_p (missing unix?)	*/
extern	struct io_ahead *uio_p;
#define	uio_pid		((int)((struct io_ahead *)uio_p)->pid)
#define	uio_devp	((unsigned long)((struct io_ahead *)uio_p)->devp)
#define	uio_acc		((int)((struct io_ahead *)uio_p)->acc)
#define	uio_rw 		((int)((struct io_ahead *)uio_p)->rw )
#define	uio_n_map	((int)((struct io_ahead *)uio_p)->n_map)
#define	uio_n_len	((int)((struct io_ahead *)uio_p)->n_len)
#define	uio_n_ctl	((int)((struct io_ahead *)uio_p)->n_ctl)
#define	uio_vadr	((int)((struct io_ahead *)uio_p)->vadr)
#define	uio_align	((int)((struct io_ahead *)uio_p)->align)
#define	uio_error	((int)((struct io_ahead *)uio_p)->error)

#define	uio_vam		((int)((struct io_ahead *)uio_p)->vam)
#define	uio_off		((int)((struct io_ahead *)uio_p)->off)

#define	uio_addr	((unsigned long)((struct io_ahead *)uio_p)->addr)
#define	uio_dam		((int)((struct io_ahead *)uio_p)->dam)

/****************************************************************
** What is needed for mmap fragments control & unmap at close fd
*****************************************************************/
struct	vme_frag	{
	int			pid;
	unsigned int		vadr;
	int			from;
	int			pages;
	struct	vme_frag	*next;
};

/****************************************************************
** What is needed to connect VME bottom interrupt services from
** particular VME devices which can need their own cleanup, 
** The fields with  D  are to be left unfilled
*****************************************************************/
typedef int (*VME_HAN)(int,int);
struct	vme_irq {
/* VME interrupts handling, incl ev local handler 		*/
	struct	task_struct	
		*task;		/* D - fill 0 for leaf driver   */
	int	level;		/* on the level    		*/
	int	vector; 	/* vector, if any  		*/
	int	sig;		/* signal to respond or 0 	*/
	int	response;	/* for ACK'ing			*/
	struct  vme_irq 
		*n;		/* D - list structuring       	*/
        char    *from;		/* requestor ident        	*/
	/* if you have to handle something,  for RORA devices	*/
        VME_HAN handler; 	/* your handler entry point	*/
};
typedef struct vme_irq  *       VIP;


/****************************************************************
** Global info of bit3 device driver
*****************************************************************/
struct bit3_dev{
#	ifdef LIN2_4			/* new <linux/wait.h>, H. Okamura */
	volatile	wait_queue_head_t
					wait_q;
#	else
	volatile	struct wait_queue	
					*wait_q;
#	endif	/* LIN2_4 */
			struct	semaphore	
					sem;
	volatile	int		wakeups; /* processes to wake	  */
	volatile	int		pio_delay;  
	volatile	int		error;	 /* ev errors on transfer */
/* config addresses vremapped (ioremapped if necessary) */
	unsigned long				base0;
	unsigned long				base2;
	unsigned long				base3;
/* we have added hard addresses for the alpha sake */
	unsigned long				hard0;
	unsigned long				hard2;
	unsigned long				hard3;
/* we need fixed DMA buffer , mostly for alphas, but we will use it totally */
	volatile unsigned long		*kernel_dma_addr;
	volatile unsigned long		kernel_dma_size;
/* flags */
	volatile	int		VME_on;
	volatile	int		card_id;
	volatile	int		dma_busy;
	volatile	int		dma_pid;
	volatile	int		irq_used;
	volatile	int		dma_done; 
	volatile	int		slow_control; 
	volatile	int		mappings;
	volatile	int		acks_pending[MAX_IRQ_LEVEL ];
/* stores , now we store the current in aheads as well, no AHEAD yet	*/
	volatile	int		free_ahead;
	volatile	struct  io_ahead	
					aheads[1 + BIT3_DMA_AHEAD];
	struct		vme_frag	*first;
	struct		vme_frag	*next;
/* we need something to handle backplane VME interrupts			*/
	volatile 	int		Vme_irq_allow; /* disable pattern */
	int				Vme_irq_cnt;
	int				Vme_irq_id;
	struct		vme_irq		*f;  /* head    vme_irq struct   */
	struct		vme_irq		*n;  /* current vme_irq struct */
};
extern struct bit3_dev *bit3_dev_p;

#ifdef LIN2_4			/* for new <linux/wait.h>, H. Okamura */
#define	bit3_wait_struct	list_entry(bit3_dev_p->wait_q.task_list.next,wait_queue_t,task_list)
#define	bit3_wait_q		(&(bit3_dev_p->wait_q))
#else
#define	bit3_wait_struct	((struct wait_queue *)(bit3_dev_p->wait_q))
#define	bit3_wait_q		((struct wait_queue **)&(bit3_dev_p->wait_q))
#endif /* LIN2_4 */
#define bit3_sem		((struct semaphore)(bit3_dev_p->sem))
#define	bit3_VME_on		(bit3_dev_p->VME_on)
#define	bit3_card_id		(bit3_dev_p->card_id)
#define	bit3_error		((u32)(bit3_dev_p->error))
#define	bit3_base0		(bit3_dev_p->base0)
#define	bit3_base2		(bit3_dev_p->base2)
#define	bit3_base3		(bit3_dev_p->base3)
/* we have added hard addresses for the alpha sake */
#define	bit3_hard0		(bit3_dev_p->hard0)
#define	bit3_hard2		(bit3_dev_p->hard2)
#define	bit3_hard3		(bit3_dev_p->hard3)
#define	bit3_wakeups		(bit3_dev_p->wakeups)
#define	bit3_dma_addr		(bit3_dev_p->kernel_dma_addr)
#define	bit3_dma_size		(bit3_dev_p->kernel_dma_size)

#define	bit3_dma_busy		(bit3_dev_p->dma_busy)
#define	bit3_dma_pid		(bit3_dev_p->dma_pid)
#define	bit3_irq_used		(bit3_dev_p->irq_used)
#define	bit3_slow_control	(bit3_dev_p->slow_control)
#define	bit3_mappings		(bit3_dev_p->mappings)
#define	bit3_pio_delay		(bit3_dev_p->pio_delay)
#define	bit3_dma_done		(bit3_dev_p->dma_done)
#define	bit3_free_ahead		(bit3_dev_p->free_ahead)
#define bit3_ahead(i)		(&bit3_dev_p->aheads[i])
#define bit3_acks_pending(i)	(bit3_dev_p->acks_pending[i])
#define bit3_first		((struct vme_frag *)(bit3_dev_p->first))
#define bit3_next		((struct vme_frag *)(bit3_dev_p->next))

/* for registering and using higher drivers IRQ's and user's IRQ's */
// this one for RORA devices, set by general handler, cleared by ioctl
// obligatory for RORA signal handlers....
#define bit3_VME_irq_allow	(bit3_dev_p->Vme_irq_allow)
#define bit3_VME_irq		(bit3_dev_p->Vme_irq_cnt)
#define bit3_VME_irq_id		(bit3_dev_p->Vme_irq_id)
#define bit3_f			((VIP)(bit3_dev_p->f))
#define bit3_n			((VIP)(bit3_dev_p->n))

/****************************************************************
** Configuration info of vme minors, also for ioctl
*****************************************************************/
struct vme_dev {
/* VME devices configuration data */
	char 	name[10];
	int	minor;
	int	am;	/* VME address modifier	 or evno	*/
	int	mod;	/* 1 (bytes, PIO only) 2 or 4, 8 event	*/
	int	dmamod;	/* BLOCK,BLOCK | PAUSE or NON_BLOCK 	*/
	int	swap;   /* MR_BYTE_SWAP|MR_WORD_SWAP|MR_WBYTE_S.*/
	int	fu;	/* 1 - VME 2 - Dual Port 3 - VME RAM 	*/
			/* 9 - BLOCK FIFO 			*/
	int	pio;	/* MAX len serviced by PIO,for event - len */
	u32	maxad;	/* MAX addressing,eg ffff for a16	*/
			/* or event frag list			*/
};
extern	struct vme_dev * vme_dev_p;

#define vme_name     (vme_dev_p->name)
#define vme_mod      (int)(vme_dev_p->mod)
#define vme_am       (int)(vme_dev_p->am)
#define vme_pio      (int)(vme_dev_p->pio)
#define vme_dmamod   (int)(vme_dev_p->dmamod)
#define vme_swap     (int)(vme_dev_p->swap)
#define vme_fun      (int)(vme_dev_p->fu)
#define vme_fu       (int)((vme_dev_p->fu) & 0xf)
#define vme_pio      (int)(vme_dev_p->pio)
#define vme_maxad    (u32)(vme_dev_p->maxad)
#define vme_event    (struct vme_frag *)(vme_dev_p->maxad)


/*	__BIT3_DEF_H*/
#endif

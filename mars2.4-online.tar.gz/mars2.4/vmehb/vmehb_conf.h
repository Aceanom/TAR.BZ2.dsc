#ifndef	__VMEHB_CONF_H 
#define	__VMEHB_CONF_H
#define VMEHB_VERSION "2.4.1"
// 2.4.1 - Modified for kernel-2.4.x (H. Okamura)
// 2.2.7 - Added changes for behalf of camces & leaf drivers
// 2.2.6 - Makefile includes smp machines. Patch 2.2.6 (multi_dma)
// 2.2.5 - test results added...
// 2.2.4 - multi_dma  for looong read/write
// 2.2.2 - Handling FIFO VME BLOCK devices  card #82 works o.k.
// 2.2.1 - Handling FIFO VME BLOCK devices according to the card nr
//         #82 - using PAUSE bit and standard DMA ( untested...)
//         any - using multi-dma approach on minors with function 9
// 2.2.0 - Compatibility with 2.2. added under compile tile flag LIN2_2
//         Some things moved from source to vmehb_conf.h
// 1.4.8 - No tabs in sys messages now, so they look everywhere the same
//	   Vm_map_area_start() added to use PIO registers in read and mmap
//	   On bytes space only PIO access, limited by the return of above funct.
// 1.4.7 - CARDS ids and other config data is now back here, as it should
//         new regs for 618 are in  bit3.reg, but yet unused
//         618 id sequence added, as 618 should work o.k.
// 1.4.6 - bit3_error put to 0 at the begin of read/write ( there was
//         outstanding error condition in new CAMAC driver ).
// 1.4.5 - added list of Vm_xxx inlines & macros + extra info in
// 	   READMEs"
// 1.4.4 - more alpha - abstracting interupt level/line relation 
//         into VM_irq_line()....
// 1.4.3 - added ALPHA PC contribution from Dave Cattermole
// 1.4.2 - added the first official 616 compatibility
// 1.4.1 - the last version distributed to Linux sites
/* add CONTRIBUTIONS or CONT_UPD here */

/*
    vmehb - VME bus driver of PCI/VME bus adaptor Model 616-618 of Bit3.
    --------------------------------------------------------------------
    Copyright (C) May 1997  Natalia Kruszynska <natalia@nikhef.nl>
    Sponsored and instigated by 
	NIKHEF - Amsterdam
	DESY   - Hamburg
    within the technical support of Hermes Collaboration in Physics.

    Thanks for contribution in alphabetical order to:
	A.J.Aranyosi	<aja@mit.edu> for a neat 2.2 port
	Thomas Bogend	<tsbogend@alpha.franken.de> DMA on alpha PC
	Andries Brouwer <aeb@cwi.nl>
	Dave Cattermole <dmc@mrc-lmb.cam.ac.uk> testing it on alpha PC
	David Chrisman  <David.Chrisman@cern.ch> extensions for Model 618
	Marcin Dalecki  <dalecki@math.uni-goettingen.de> 
	Jay Estabrook   <jay@digital.com> DMA on alpha PC
	Lisa. G.Gorn	<gorn@phys.ufl.edu> for 618/2.2 updates and tests
	David Grothe	<dave@gcom.com>
	Eric Kasten     <kasten@ncsl.msu.edu> for a neat 2.1.90+ version
                        (grab it if you can run beta Linux)

        H.J Mathes      < mathes@ik3.fzk.de> byte access and byte spaces
	Hiroyuki Okamura<okamura@phy.saitama-u.ac.jp> (interrupts)
	Henk Peek	<henkp@nikhef.nl> 
        Klaus Schossmaier<Klaus.Schossmaier@cern.ch>
	Ruud van Wijk   <ruud@nikhef.nl>

    and to  these who are not yet listed here  and who have caught
    some hidden bug and send it to me. 

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
*/
/*
    CONTENTS:
    data of different hardware  PCI->VME bus adaptors of Bit3
    driver configuration file 
    The file covers the following aspects:
    	Hardware dependency:
    		current configuration of VME
    	System dependency:
    		including proper system files
   		system independent wrappers for routines & macros
                changes into the driver policy of Linux
    	System tracing and debugging:
    This file contains VARIABLES !!!!
    We are adding extra compile flag LIN2_2 to cover for
    most of 2.2.5+ version of Eric Kasten. If the times allows I 
    will check
    if I do not overkill CONFIG_PROC_FS with this flag..
	
    Copyright (C) May 1997  Natalia Kruszynska <natalia@nikhef.nl>
*/

/*
 * The following  prefixes are consequently used in the code:
 *	vme_		- configuration data of a vme space
 *	bit3_		- device  structure members
 *	uio_		- request structure members (UNIX hickup)
 *	vmehb		- big routines of the driver 
 *      Va_		- base auxiliary routines
 *	Vm_		- semaphoring & setup inlines  
 *	Bit3_		- hardware access inline primitives
 *	set_		- different levels of tracing, defined below
 */
/* ================================================================== */
/* HARDWARE CONFIGURATIONS */
/****************************************************************
** PCI configuration of bit3  devices
*****************************************************************/
#define PCI_VENDOR_ID_BIT3		0x108a

#define PCI_DEVICE_ID_BIT3_VME		0x1   //617
#define PCI_DEVICE_ID_BIT3_VME_616	0x3
#define PCI_DEVICE_ID_BIT3_VME_618	0x10

// for other PCI device drivers ......

/****************************************************************
** VME configuration of bit3 
*****************************************************************/
// #80  - standard 616/617 -incapable of good handling of FIFO block dev
// #82  - update RPQ600874-202 able to handle FIFO with PAUSE bit on
// 	  not tested yet...
// #83  - glass fiber, model 618  behaviour to FIFO unknown
/* ================================================================== */
/* SYSTEM COMPATIBILITY */
/*
 *  System compatibility, we will see wheter Vm..from.to  are the same
 *  in both Linux lines
 *      Vm_copy..io	- for read/write
 *      Vm_copy..user   - for ioctl
 *  let's assume they are the same...
 *  For RH6.x and another 2.2 you should use also LIN2_2 
 */
#if  (!defined(LIN2_2)) && (!defined(LIN2_0))
#	include <linux/version.h>
#	if   LINUX_VERSION_CODE >= 0x020100
#		define LIN2_2
#		if   LINUX_VERSION_CODE >= 0x020400
#			define LIN2_4
#		endif
#	elif LINUX_VERSION_CODE >= 0x020000
#		define LIN2_0
#	endif
#endif
#ifdef LIN2_2
#		include	<linux/version.h>
#		include	<linux/modversions.h>
#	ifdef CONFIG_PROC_FS		
#		include	<linux/config.h>
#	endif
#	define EXPORT_SYMTAB
#endif /* LIN2_2...*/

#include	<linux/module.h>
#include	<linux/wrapper.h>
#include	<linux/sched.h>		/* for resources routine */
#include	<linux/kernel.h>
#ifdef LIN2_4				/* for kernel-2.4.x, H. Okamura */
MODULE_LICENSE("GPL");
#include	<linux/slab.h>
#else
#include	<linux/malloc.h>
#endif /* LIN2_4 */
#include	<linux/types.h>
#include	<linux/ioport.h>	/* for port operations	*/
#include	<linux/fs.h>
#include	<linux/mm.h>
#include	<linux/errno.h>
#include	<asm/io.h>		/* for port operations	*/
#ifndef LIN2_2
#	include	<linux/bios32.h>	/* for pci_bios & probe */
#endif /* !LIN2_2...*/
#include	<linux/pci.h>
#include	<asm/segment.h>  	/* for get/put into user space	*/
#include	<asm/irq.h>		 /* for interrupt	*/
#include	<linux/delay.h>		 /* for udelay(usecs)	*/
#include	<linux/wait.h>		 /* for semaphoring	*/
#include	<linux/smp.h>		 /* for semaphoring	*/

#ifdef LIN2_2
#	ifdef CONFIG_PROC_FS		
#		include	<linux/stat.h>		/* for use of proc */
#		include	<linux/proc_fs.h>
#	endif
#	define	LIN2_1_27
#endif /* LIN2_2...*/

#ifdef LIN2_0 /* in 2_0_0 and 2_0_30 is the same */

#ifdef __alpha__
/* on alpha we do not need ioremap on config addresses */
#define	Vm_remap(x,y)	(y)
#define Vm_free( x)
#define	Vm_copy_to_user(a,b,c)		memcpy_tofs(  a,bus_to_virt(b),c)
#define	Vm_copy_from_user(a,b,c)	memcpy_fromfs(bus_to_virt(a),b,c)
#define	BIT3_IRQ_USED	0x11
#define Vm_irq_line(c)	(c + 15)  	// check for alpha
#endif /* --alpha__ */

#ifdef __i386__ /**/
#define Vm_remap	vremap
#define Vm_free 	vfree
#define	Vm_copy_to_user		memcpy_tofs
#define	Vm_copy_from_user	memcpy_fromfs
#define Vm_irq_line(c)	(c)  
#define	BIT3_IRQ_USED	BIT3_IRQ // 5
#endif /*  __i386__ /**/

#define	Vm_copy_fromio		memcpy_tofs
#define	Vm_copy_toio		memcpy_fromfs
#define	Vm_get_uval(a,b)  	(a) = get_user((b))
#define	Vm_put_uval(a,b)  	put_user((a),(b))
#endif //Lin2_0
//------------------------------------------------

#ifdef LIN2_1_27
/* changes from 2.2.0 to 2.1.27					*/
#		include	<asm/uaccess.h>	/* VERIFY_READ/WRITE flags are here */

#ifdef __alpha__ /**/
#define	Vm_remap(x)	(x)
#define Vm_free( x)
#define	BIT3_IRQ_USED	0x11
#define Vm_irq_line(c)	(c + 15 )  	// check for alpha
#endif/* __alpha__ /**/

#ifdef __i386__ /**/
#define	Vm_remap		ioremap
#define	Vm_free			iounmap
#define	BIT3_IRQ_USED	BIT3_IRQ // 5
#define Vm_irq_line(c)	(c)  
#endif /* __i386__ /**/

/* see whether it works */
#ifdef LIN2_4	/* for kernel-2.4.x, H. Okamura */
#define	Vm_copy_to_user		copy_to_user
#define	Vm_copy_from_user	copy_from_user
#else
#define	Vm_copy_to_user		memcpy_fromio
#define	Vm_copy_from_user	memcpy_toio
#endif	/* LIN2_4 */
#define	Vm_copy_fromio		memcpy_fromio
#define	Vm_copy_toio		memcpy_toio
#define	Vm_get_uval(a,b) 	get_user((a),(b))
#define	Vm_put_uval(a,b) 	put_user((a),(b))
#endif  /* LIN_2_1_27 */
//------------------------------------------------
#ifdef LIN2_4
// from old <linux/wrapper.h>, H. Okamura
#ifndef inode_inc_count
#define inode_get_rdev(i) i->i_rdev
#define inode_get_count(i) i->i_count
#define inode_inc_count(i) i->i_count++
#define inode_dec_count(i) i->i_count--
#endif
#ifndef vma_get_page_prot
#define vma_set_inode(v,i) v->vm_inode = i
#define vma_get_flags(v) v->vm_flags
#define vma_get_offset(v) v->vm_offset
#define vma_get_start(v) v->vm_start
#define vma_get_end(v) v->vm_end
#define vma_get_page_prot(v) v->vm_page_prot
#endif
#endif /* LIN2_4 */

/* ==================================================================
 * Driver compile time options
 */

#define MAX_IRQ_LEVEL		8
#define	MIN_IRQ_LEVEL		0
#define MAX_DMA_SIZE		0x10000
//efine MAX_DMA_SIZE		0x80 // for test
#define SIGKILLVME		SIGKILL
#define DEF_IRQ_FROM		"VMEHB:" /* default request header */
#define USER_ANARCHY		/* suppress suser check in ioctl*/

	// DEBUGGING ....
//efine VMEHB_DEBUG		/* activate debugging routines	*/
//to send to users by suser's free
#define SYS_TRACELEN		0x0/* internal tracing length 	*/

// diag levels we can add or remove... most we let stay
// and be activated under DEBUG  - FATALS use printk !!!
#ifdef	VMEHB_DEBUG
#	define	VMEHB3_TRACE(x)	printk x //  change id #82 tests & multi-access DMA
#	define	VMEHB2_TRACE(x)	//  read/write reorg in 1.4
#	define	VMEHB1_TRACE(x)	//  irq tracing of 1.4
#	define	VMEHB_TRACE(x)	// release 1.2 tracings
#	define	BIT4_TRACE(x)   // Changes to 1.4
#	define	BIT3_TRACE(x)   // Debugging primitives
#else
#	define	VMEHB3_TRACE(x)	
#	define	VMEHB2_TRACE(x)	
#	define	VMEHB1_TRACE(x)	
#	define	VMEHB_TRACE(x)	
#	define	BIT4_TRACE(x)	
#	define	BIT3_TRACE(x)	
#endif
#ifdef	SYS_DEBUG
#	define	SYS_TRACE(x)	printk x
#else
#	define	SYS_TRACE(x)	
#endif

/* 
**  ----- begin of contents of compile time options ------------ 
** Never change this code !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
*/

#ifdef USER_ANARCHY	/* user can clear maps and change flags */
#define Vm_check_suser
#else /* cricial ioctls for suser only */
#define VM_check_suser	if(!suser()) return -EPERM
#endif
// This function divides the pio regs between pio access and mmap access
// and is here filled with the fix for 617.  Cam be any function here
// returning between 1 < 2k. Maximal pio should be less than the return 
// (value of this function * 256 bytes) - 1. Byte access above it's pio 
// returns -EINVAL. No dma on byte access....

inline int Vm_map_area_start(void) {
	// Your politics is to be here and return whatever you wish
	// The politics  for 617, pio <512
	return 2;
}
/*  ----- end of contents of compile time options -------------- */

#define	NO_SA_INTERRUPT	0

/* ==================================================================
** local include files & VME drivers support
** ------------------------------------------------------------- */

#include	"bit3_def.h"		/* soft defs & primitives */
#include	"bit3_reg.h"		/* hard defs & primitives */
#include	"vmehb_ioctl.h"		/* ioctl defs 		  */

#ifdef  __vme_space_driver__ /*  all VME drivers have to define it */
// 
// This part is included in leaf drivers 
// 
extern	unsigned long vmehb_dev_read ( int, unsigned int,char *,unsigned int);
extern	unsigned long vmehb_dev_write( int, unsigned int,char *,unsigned int);
extern	unsigned long vmehb_dev_mmap ( int, unsigned int,unsigned int);
extern	unsigned long vmehb_dev_unmap( int, unsigned int,unsigned int);
extern	int   request_vme_irq(int,int,VME_HAN ,char *);
extern	void  free_vme_irq(   int,int,VME_HAN);
#else /* !!__vme_space_driver__  i.e. vmehb itself */
// 
// This part is used by the driver, skilled by leaf drivers
// 
static	unsigned long vmehb_dev_read ( int, unsigned int,char *,unsigned int);
static	unsigned long vmehb_dev_write( int, unsigned int,char *,unsigned int);
static	unsigned long vmehb_dev_mmap( int, unsigned int,unsigned int);
static	unsigned long vmehb_dev_unmap(int, unsigned int,unsigned int);
static	int   request_vme_irq(int ,int,VME_HAN ,char *);
static	void  free_vme_irq(   int ,int,VME_HAN); 

#ifdef LIN2_2
/* ================================================================== */
#	ifndef	REGISTER_SYMTAB
#		define REGISTER_SYMTAB(x)
#	endif
	/* just for the use with HSM driver, by H.Okamura, from here */
	static ssize_t vmehb_read ();
	static ssize_t vmehb_write();
	EXPORT_SYMBOL_NOVERS(vmehb_read);
	EXPORT_SYMBOL_NOVERS(vmehb_write);
	/* to here */
	EXPORT_SYMBOL_NOVERS(vmehb_dev_read);
	EXPORT_SYMBOL_NOVERS(vmehb_dev_write);
        EXPORT_SYMBOL_NOVERS(vmehb_dev_mmap);
        EXPORT_SYMBOL_NOVERS(vmehb_dev_unmap);
	EXPORT_SYMBOL_NOVERS(request_vme_irq);
	EXPORT_SYMBOL_NOVERS(free_vme_irq);

#	ifdef CONFIG_PROC_FS
static int get_bit3m617_status(char *,char **,off_t,int,int);
static int get_csr_status(char *,char **,off_t,int,int);
#	endif
#else //!LIN2_2
/* ================================================================== */

static int  vmehb_read ();
static int  vmehb_write();
static struct symbol_table vmehb_syms = {
#include <linux/symtab_begin.h>
	X(vmehb_read),
	X(vmehb_write),
	X(vmehb_dev_read),
	X(vmehb_dev_write),
        X(vmehb_dev_mmap),
        X(vmehb_dev_unmap),
	X(request_vme_irq),
	X(free_vme_irq),
#include <linux/symtab_end.h>
};
#	ifndef	REGISTER_SYMTAB
#		define	REGISTER_SYMTAB(tab) register_symtab(tab)
#	endif
/* ================================================================== */
#endif /* LIN2_2...*/
#endif /* __vme_space_driver__ */

/* saving state of the device here */
static  pci_config_t	PCI_conf;
static	int 		bit3_major	= BIT3_MAJOR;
static	int 		bit3_irq_line	= BIT3_IRQ_USED;


/* ==================================================================
**	Device access constants & definitions
** 	bit3 device parameters access 			
** 	here we can extend for multi-device access	
---------------------------------------------------------------------	*/
static struct bit3_dev	bit3_dev;
struct	bit3_dev 	*bit3_dev_p	= (struct bit3_dev *)&bit3_dev;
struct	io_ahead 	*uio_p; 

/* ------------------------------------------------------------------ */
/* VME parameters access */
#ifdef LIN2_2
#define	vme_minor	MINOR(file->f_dentry->d_inode->i_rdev)
#else 
#define	vme_minor	MINOR(node->i_rdev)
#endif /* LIN2_2 */
/*
** VME config   - max PIO can not exceed 0x1000 ( one VME page size )
**	name 	- standard name  ( should keep within 10 chars )
**	minor	- minor number of the device
**	am	- address modifier , as defined in VME standard
**	mod	- length of data step in bytes
**	dmamod	- 
			0 - standard access ( non block)
			RC2_DMA_BLK_SEL  - VME block  standard access
			RC2_DMA_PAUSE    - VME block  FIFO  update  ( #82)
** 	swap	- 0 or a combi of 
			VME_BYTE_SWAP	 Byte swap bytes       
			VME_WORD_SWAP    Swap words
			VME_WBYTE_SWAP   Byte Swap non-bytes
			see bit3_reg.h and the iadaptor manual
**	fu	- 
			1 - VME I/O 
			3 - Dual Port I/O 
			2 - VME RAM I/O
**	pio	- up to this length PIO, more - DMA access (if nto 616) 
**	maxad	- max addr of a given space (VME ADDR or Dual Port length)
*/
struct vme_dev	vme_config[] = {
/* name    minor   am    mod    dmamod 		swap	fu      pio ,max	*/ 
{"vme16d16",   0, 0x2d,	 2,	0                ,0,	1,	255 ,0x0000ffff},
{"vme16d32",   1, 0x2d,	 4,	0                ,0,	1,	255 ,0x0000ffff},
{"vme24d16",   2, 0x39,	 2,	0                ,0,	1,	255 ,0x00ffffff},
{"vme24d32",   3, 0x3d,	 4,	0                ,0,	1,	255 ,0x00ffffff},
{"vme32d16",   4, 0x0d,	 2,	0                ,0,	1,	255 ,0xffffffff},
{"vme32d32",   5, 0x0d,	 4,	0                ,0,	1,	255 ,0xffffffff},
/* dual port access */
{"vmedpd16",   6, 0x0d,	 2,	0,	       	  0,	3,	255 ,0x07ffffff},
{"vmedpd32",   7, 0x0d,	 4,	0,		  0,	3,	255 ,0x07ffffff},
/* vme ram   access */
{"vmerad16",   8, 0x0d,	 2,	0,		  0,	2,	255 ,0x07ffffff},
{"vmerad32",   9, 0x0d,	 4,	0,		  0,	2,	255 ,0x07ffffff},
/* vme block access for MEMORIES on all cards */
{"vmm24d16",  10, 0x3b,	 2,	RC2_DMA_BLK_SEL,  0,	1,	001 ,0x00ffffff},
{"vmm24d32",  11, 0x3b,	 4,	RC2_DMA_BLK_SEL,  0,	1,	002 ,0x00ffffff},
{"vmm32d16",  12, 0x0b,	 2,	RC2_DMA_BLK_SEL,  0,	1,	001 ,0xffffffff},
{"vmm32d32",  13, 0x0b,	 4,	RC2_DMA_BLK_SEL,  0,	1,	002 ,0xffffffff},
// PATCH-2.2.1 to get the VME BLOCK FIFO devices working nicely
//
// We use the extended function code 9 as the switch for the
// driver whether to use the software patch for non-updating 
// start address or just set the hardware patch handling - in 
// vme_dmamod bit RC2_DMA_PAUSE is to be set. On cards with 
// #ID = #82 it shoud suspend the address incrementation. 
//
// On all another cards the  software patch is set. 
// System Manager can remodify if e.g. cards #83 can use the 
// bit instead of the software patch. 
//
//	Nata Kruszynska <natalia@nikhef.nl> Sep 99 NIKHEF 

{"vmf24d16",  14, 0x3b,	 2,	RC2_DMA_BLK_SEL 
                                               ,  0,	9,	001 ,0x00ffffff},
{"vmf24d32",  15, 0x3b,	 4,	RC2_DMA_BLK_SEL
                                               ,  0,	9,	001 ,0x00ffffff},
{"vmf32d16",  16, 0x0b,	 2,	RC2_DMA_BLK_SEL
                                               ,  0,	9,	001 ,0xffffffff},
{"vmf32d32",  17, 0x0b,	 4,	RC2_DMA_BLK_SEL
                                               ,  0,	9,	001 ,0xffffffff},
// END PATCH-2.2.1
/* exotic VME access single user devices	*/
{"vmfunny1",  18, 0x3d,	 4,	RC2_DMA_PAUSE    ,0,	1,	256 ,0xffffffff},
{"vmfunny2",  19, 0x3d,	 4,	RC2_DMA_PAUSE    ,0,	1,	256 ,0xffffffff},
//  extra minor for tests of CAMAC long access, not used in camces-1.1
//  the 24 registers need word swap being addressed in odd_byte 
//  but still D16 space!!  Hence the try. But it loads then #x + 2, #x
//  and the result is unstable ( it seems - no deep testing made...).
//  let's try also D32 then .....
{"vmfc2416",  20, 0x39,	 2,	0                ,2,	1,	255 ,0x00ffffff},
{"vmfc2432",  21, 0x39,	 4,	0                ,2,	1,	255 ,0x00ffffff},
// byte spaces added for and by H.J. Mathes for everybody 
// experimental D8 devices (no DMA possible) 
// pio <  256  * Vm_map_area_start()  - firs to the standard value
{"vme16d8",   22, 0x2d,        1,     0,                0,    1,512 ,0x0000ffff},
{"vme24d8",   23, 0x3d,        1,     0,                0,    1,512 ,0x00ffffff},
{"vme32d8",   24, 0x0d,        1,     0,                0,    1,512 ,0xffffffff},

#ifdef LIN2_2
/* This last one is to mark the end of the table */
{"\0",  255, 0x3d,       4,     0                ,0,    1,      256 ,0xffffffff},
#endif /* LIN2_2 */
};
struct	vme_dev	*vme_dev_p; /* = (struct vme_dev *)&vme_config[vme_minor])  /**/


/* ================================================================== 
	DMA allocation related routines: HIGH ARCHITECTURE DEPENDENCE!!!

	__get_order(size) ( should be exported by kernel) - from floppy
	Vm_dma_mem_alloc(size) 		- to get 24 bits long pointer 
					  to DMA buffer
	Vm_dma_mem_free(addr,size)	- to free DMA buffer

	This part is heavilly dependent on the architecture !!!!!!!!!!!!
	The device needs  24 bits long address  accessible  by  PCI  bus
	to perform it's DMA access. These routines allocate the requested
	address in a given architecture. We were keeping allocation by the
	DMA access ( per write ) in a hope to resolve another "feature"
	problem and to make an overlap of DMA with another actions of the
	driver. However on Alpha we have now to use the separate memory 
	window, which should not be reprogrammed too often. So we will 
	switch to 'allocate at load' for everybody.
*/

/* Pure 2^n version of get_order  from floppy driver */
static inline int __get_order(unsigned long size)
{
	int order;

	size = (size-1) >> (PAGE_SHIFT-1);
	order = -1;
	do {
		size >>= 1;
		order++;
	} while (size);
	return order;
}

#define DMA_VME_MASK 0xffffff

/*
  On Intel the following routines deliver neatly 24 bits long address
  On new architectures we recommend to use this as well.  If the
  allocated address is higher than DMA_VME_MASK - look into the MM of
  the chipset on how to get 24 bits instead. 
*/

#ifdef __i386__	/**/
#define	PCI_ACCESS_MASK 0xfffffffc
static inline unsigned long Vm_dma_mem_alloc(unsigned long size)
{
	unsigned long i;
	/* we return 1 on error, as alpha can address on 0!!! */
	/* i = (__get_dma_pages(GFP_KERNEL,__get_order(size))); /**/
#ifdef LIN2_2
	i = (__get_free_pages(GFP_KERNEL,__get_order(size))); /* modified by */
#else
	i = (__get_free_pages(GFP_KERNEL,__get_order(size),0)); /* H.Okamura */
#endif /* LIN2_2 */
	if(i == 0)
	{
		printk("vmehb: can not allocate %lx memory for DMA\n",size);
		return(1UL);  // fixed to 1 because of ALPHA
	}
	return((unsigned long)virt_to_bus((unsigned long *)i));
}
static inline void Vm_dma_mem_free(unsigned long addr, unsigned long size)
{
	// have to be safe !!!!!
	if(addr != 1UL)
	free_pages((unsigned long)bus_to_virt(addr), __get_order(size));
}
#endif /*  __i386__/**/

#ifdef __alpha__ /**/
#define	PCI_ACCESS_MASK 0xfffffffc
//############################
//# On Alpha PC it will depend on chipset , define the chipset type below:
#define __ALPHA_UNKNOWN__ /**/

#ifdef	__ALPHA_LCA__ /**/
//# Thomas Bogend proposed the following <tsbogend@alpha.franken.de>:
static inline unsigned long Vm_dma_mem_alloc(unsigned long size)
{
	unsigned long new_pages,physaddr;
	new_pages = __get_DMA_PAGES(GFP_KERNEL,__get_order(size));
	if(new_pages == 0)
		return 1; /* can return 0 and be correct !!!! */
	physaddr = virt_to_phys(new_pages);
	/* setup DMA window to fit the allocated pages  in 16 Mb range */
	*(vulp)LCA_IOC_W_BASE1 = 1UL << 33;
	*(vulp)LCA_IOC_W_MASK1 = DMA_VME_MASK;
	*(vulp)LCA_IOC_T_BASE0 = physaddr & ~DMA_VME_MASK ;
	/* return can be also 0 */
	VMEHB_TRACE(("Vm_dma_mem_alloc %lx\n",physaddr & DMA_VME_MASK));
	return   physaddr & DMA_VME_MASK ;
} 
#define Vm_dma_mem_free( a,s)
#endif /*	__ALPHA_LCA__ /**/
/*
** If we do not know chipset we can always try what DMA addess it
** delivers. The driver diagnoses of the DMA address is too high.
*/
#ifdef   __ALPHA_UNKNOWN__ /**/
static inline unsigned long Vm_dma_mem_alloc(unsigned long size)
{
	/* alpha does not take to volatile in casting   */
	/* return virt_to_bus(( volatile void *)__get_dma_pa NO alpha.... */
	return virt_to_bus(( void *)__get_dma_pages(GFP_KERNEL,__get_order(size)));
}

static inline void Vm_dma_mem_free(unsigned long addr, unsigned long size)
{
	free_pages((unsigned long)bus_to_virt(addr), __get_order(size));
}
#endif   /*__ALPHA_UNKNOWN__/**/
#endif /*  __alpha__ /**/

/* ================================================================== 
 * Semaphores:
 */
static  inline void Vm_down(struct semaphore *sem)
{
	down(sem);
} /* end Vm_down() */
static inline void Vm_up(struct semaphore *sem)
{
	up(sem);
} /* end Vm_up() */
/* 
 *   bit3_sem      semaphore for the initialization by current MUTEX
 *   bit3_wakeups  	clear flag
 *   bit3_error    		clear flag
 *   bit3_slow_control  	1 to avoid DMA, 0 for DATA mode
 *   bit3_irq_used 		flag to switch the mode of DMA service
 *	1		DMA interrupt mode
 *      0               DMA poll busy a lot....
 *	-1000-0		DMA poll with udelay of -flag between polls
 *      -1000 >		Fancy modes for tests, to try interrupts
 *   bit3_poll_delay	Check VME validity mode (PIO only)
 */
static inline void Vm_status(char *s) 
{ printk("VME driver vmehb %s: %s\n",VMEHB_VERSION,s); }
static inline void Vm_report_driver()
{
	printk("vmehb: setup report:\n");
	/* here we place info over which testing version it is */
	if(bit3_pio_delay)
		printk("        Check VME mode : PIO only , delayed %d usecs\n"
			,bit3_pio_delay);
	if(bit3_slow_control)
		printk("        Slow control mode: PIO only, mmap allowed\n");
	/* two models allowed for DMA access */
	if(bit3_irq_used > 0)
		printk("        IRQ - serialized with semaphores\n"); /* IRQ */

	if(bit3_irq_used <= 0 )
		printk("        Test version: POLL - serialized with semaphores \n"); /*POLL*/
	if(bit3_VME_on == 0)
	{
		printk("        VME crate off!!, every access will return ENODEV\n");
	}
printk("        VME_CARD_ID = #%x\n",bit3_card_id);
	if(!bit3_slow_control)
	{
		printk("        DMA on %lx - size %lx\n"
			,bit3_dma_addr, bit3_dma_size);
		printk("        DMA colides with programs & drivers \n");
		printk("            using MMAP as vmecmd standard access\n");
		printk("            (but you can use DIRECT mode of vmecmd)\n");
		if(bit3_card_id <= 0)
	printk("        VME card probably not powered on\n");
		if(bit3_card_id == 0x80)
{
printk("        for VME block FIFO devices  DMA special software patch is used now:\n");
printk("        ask your supplier of SBS-BIT3 devices to update your VME board \n");
printk("            from  product 85154558 id #80\n");
printk("            into  product 85154558 id #82\n");
printk("            update: RPQ600874-202\n");
}
                        if(bit3_card_id == 0x82)
{
printk("        for VME block devices configure and use minors :\n");
printk("             vmmxxdyy      for MEMORIES\n");
printk("             vmfxxdyy      for FIFO devices\n");
printk("        Please, report any errors on accessing FIFO block devices\n");
}
                        if(bit3_card_id == 0x83)
{
printk("        Glass Fibre Model 618 - probably the following is true\n");
printk("        for VME block devices configure and use minors :\n");
printk("            vmmxxdyy      for MEMORIES\n");
 printk("           vmfxxdyy      for FIFO devices\n");
printk("        Please, report any errors on accessing FIFO block devices\n");
}
	if(bit3_card_id != 0x80 
	&& bit3_card_id != 0x82
	&& bit3_card_id != 0x83)
{
printk("        Your VME adapter card  %x is unknown to me\n",bit3_card_id);
printk("        Please, describe your hardware\n");
}
printk("                Nata Kruszynska <natalia@nikhef.nl>\n");

	}
	return;
}
static inline int Vm_set_me_up()
{
	u32 val;
	/* Vm_set_me_up				*/
	/* preset PIO registers with 1		*/
	Bit3_map_free(bit3_base2,MR_PCI_VME,(MR_PCI_VME_SIZE) >> 2);
	/* initialize the device structure	*/
	/* bit3_sem 		= MUTEX; ... older, H. Okamura */
	sema_init(&bit3_sem, 1);	/* replaced, H. Okamura */
	bit3_wakeups 		= 0;
	bit3_error		= 0;
					/* mmap'ers adm		*/
	bit3_first		= (struct vme_frag *)0;
	bit3_next		= bit3_first;
					/* driver options for 617 */
	// we can set/reset here this bit only for 617, it have to
	// stay 1 if 616 is used. So if initial setting is for
	// slow control we have 616 and we should not change that
	if(!bit3_slow_control) {
		bit3_slow_control	= 1;	/* SLOW CONTROL */
		bit3_slow_control	= 0;	/* DMA ALLOWES	*/
	}

	bit3_irq_used		= -2000;/* POLL with schedule() after jiffie */
        bit3_irq_used		= -1;	/* POLL */
        bit3_irq_used		=  0;	/* POLL  deadly busy*/
        bit3_irq_used		=  1;	/* DMA  */

	bit3_pio_delay		= 50;	/* VME BERR CHECK MODE	*/
	bit3_pio_delay 		= 0;	/* VME BERR not fixed   */
	bit3_dma_size	        = MAX_DMA_SIZE;
	bit3_VME_irq_allow      = 0;
	if(MAX_DMA_SIZE > 0x1000000)
	{
		printk("vmehb: requested dma size beyond capacity\n");
		bit3_dma_size = 0x1000000;
	}
	if(!bit3_slow_control)
	{
		bit3_dma_addr = (unsigned long *)Vm_dma_mem_alloc(bit3_dma_size);
		if(bit3_dma_addr == (unsigned long *)1)
		{
			printk("vmehb: WARNING 617 in slow control only\n");
			bit3_slow_control = 1;
		}
	}
	/*
	** we map the registers by i/o as vme_swap can change  per minor
	*/
	Vm_report_driver();
	return(0);
} /* end Vm_set_me_up() */
static inline void Vm_list_regs() {
	// this routine sets register contents in dmesg and it is
	// invoked by ioctl 63 ( no params )
	int i;
	int val = 0;
	for(i = 0;i < 32; i ++){
		if(i == 0xe) continue;
		if(i == 0xf) continue;
		val = 0;
		val = inb(bit3_base0 + i);
		printk("vmehb: reg %2x = %8x\n",i,val);
	}
} /* end Vm_list_regs */
static inline void Vm_list_maps()
{
	struct vme_frag *list;
	list	= bit3_first;
	/*  extended info over mappings within kernel */
	while(list != (struct vme_frag *)0 )
	{
		printk("vmehb: %16x %4d   maps %8x from %4d len %d"
			,(unsigned long)list
			,list->pid
			,list->vadr
			,list->from
			,list->pages
			);
		if(list->pid == 0xffffffff)
			printk(" - for VME dev\n");
		else
			printk("\n");
		list	= list->next;
	}
	Bit3_map_dump(bit3_base2,MR_PCI_VME + 8,16);
}
static inline void Vm_clear_maps(int pid)
{
	struct	vme_frag	*old;
	struct	vme_frag	*next;
	next	= bit3_first;
	old	= bit3_first;
	if(pid == 0)
	{
		/* free all maps	*/
		printk("vmehb: clears all maps\n");
		Bit3_map_free(bit3_base2,MR_PCI_VME,(MR_PCI_VME_SIZE) >> 2); /**/
	}
	while(next != 0)
	{
		/* pid 0 clears all maps			 */
		if((pid) && next->pid != pid)
		{
			next = next->next;
			continue;
		}
		if(pid) 
		{
			/* free this map	*/
			printk("vmehb: %16x %4d unmaps %8x from %4d len %d\n"
				,(unsigned long)next
				,next->pid
				,next->vadr
				,next->from
				,next->pages
				);
			Bit3_map_free(bit3_base2
				,MR_PCI_VME + ((next->from) << 2)
				,next->pages
				); /**/
		}
		if(next == bit3_first)
		{
			/* the first	*/
			BIT3_TRACE(("At the head from %d \n",next->from));
			kfree (bit3_first);	/*	*/
			bit3_first	= next->next;
			next		= next->next;
		}
		else
		{
			/* another	*/
			BIT3_TRACE(("Another     from %d\n",next->from));
			old->next 	= next->next;
			kfree( next);		/*	*/
			next 		= next->next;
			old 		= next->next;
		}
	}
}

/*
 * SYSTEM TRACING: reported when the power goes off VME crate
 * and by the ioctl VME_TRACE_INFO ( no params , any device )
 * Here you can see how to add your own level. Try it once...
 *   Till now the two sets of functions were used, the first
 *   with three flags, another only with values
 *	set_A	- tracing of driver occasional coma problem
 *	set_B   - tracing of get_dma_pages *0, which 
 *                 appeared once
 * The current set_C is 32 bits (alpha - take care!!) and  ready 
 */
#ifdef SYS_TRACELEN
static	int 	trace[SYS_TRACELEN];
static	int	traceno 	= 0;
/* TRACING B - of dma buffer memory leak	*/
/* TRACING C - not used yet              */
#define	set_B(val)	
static  inline  set_C(val)	{
	trace[traceno++] = (unsigned int)val;
	if(traceno > SYS_TRACELEN - 1)
		traceno = 0;
};
static void print_trace()
{
	int i;
	// this section was to test vmehb_dev_read and it works fine
	// unsigned long csr;
	// csr = 0xbadc;
	// printk("Address  %lx\n",(unsigned long)&csr);
	// i = vmehb_dev_read(2,(unsigned int)0x80e802,(char *)&csr,2);
	// printk("CSR %x i %d \n",csr,i);
	if(SYS_TRACELEN)
		printk("Current trace : %x\n",traceno);
	for(i = 0;i < SYS_TRACELEN;i+= 8)
	{
		printk("%3x: %8x %8x %8x %8x|%8x %8x %8x %8x\n"
			,i
			,trace[i]
			,trace[i + 1]
			,trace[i + 2]
			,trace[i + 3]
			,trace[i + 4]
			,trace[i + 5]
			,trace[i + 6]
			,trace[i + 7]
			);
	}
}
#else  /* trace undefined */
#define	set_B(val)	
#define	set_C(val)	
#define	print_trace()
#endif

/*
	Vm_xxx list  of  inlines & macros
	-----------------------------------------------------------
//#define	Vm_remap
//#define Vm_free
//#define	Vm_copy_to_user
//#define	Vm_copy_from_user
//#define Vm_irq_line
//#define	Vm_copy_fromio
//#define	Vm_copy_toio
//#define	Vm_get_uval
//#define	Vm_put_uval
//#define Vm_check_suser
//static inline unsigned long Vm_dma_mem_alloc(unsigned long size)
//static inline void Vm_dma_mem_free(unsigned long addr, unsigned long size)
//static inline void Vm_status(char *s) 
//static inline void Vm_report_driver()
//static inline int Vm_set_me_up()
//static inline void Vm_list_maps()
//static inline void Vm_clear_maps(int pid)
*/

#endif 	/* __VMEHB_CONF_H /**/

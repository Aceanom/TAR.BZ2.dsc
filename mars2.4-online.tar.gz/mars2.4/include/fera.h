#ifndef FERA_H
#define FERA_H

#define FERA_HEADER(b)  (b & 0x8000)
#define FERA_VSN(b)     (b & 0x00ff)
#define FERA_TYPE(b)    ((b>>6) & 3)
#define FERA_VDC0(b)    ((b & 0x7800) ? (b>>11) & 0x0f : 16)
#define FERA_VDC1(b)    ((b & 0x0700) ? (b>> 8) & 0x07 :  8)

/* It is assumed that first data of each event is from 4300B with VSN=0 */
#define EVENT_HEADER(b) (FERA_HEADER(b) && !(b & 0x07ff))

#define SADR_4300B(a)   (a>>11)
#define DATA_4300B(a)   (a & 0x07ff)
#define SADR_413A(a)    (a>>13)
#define DATA_413A(a)    (a & 0x1fff)
#define SADR_33x1(a)    (a>>12)
#define DATA_33x1(a)    (a & 0x0fff)
#define SADR_3377(a)    (a>>10)
#define DATA_3377(a)    (a & 0x03ff)

/*
 * There are at least 3 types of FERA compatible modules.  
 * It is assumed that 2-bit identifier is embedded in MSB of VSN.  
 *
 * Category 1 (TYPE=0, i.e. VSN=0..63)
 *
 *   4300B  -- 16 Channel Fast Encoding Readout ADC (FERA)
 *   AD413A -- Quad 8k ADC (ORTEC)
 *   AD114  -- 16k ADC (ORTEC)
 *
 *              F E D C B A 9 8 7 6 5 4 3 2 1 0
 *     HEADER:  1 <-VDC-> 0 0 0 <-----VSN----->
 *
 *              F E D C B A 9 8 7 6 5 4 3 2 1 0
 *     DATA:    0 <-SA--> <-------DATA-------->  (4300B)
 *      or
 *     DATA:    0<SA> <---------DATA---------->  (AD413A)
 *      or
 *     DATA:    0 0 <----------DATA----------->  (AD114)
 *
 * Category 2 (TYPE=1, i.e. VSN=64..127)
 *
 *   3341   -- 8 Input Charge ADC
 *   3351   -- 8 Input Peak Sensing ADC
 *   3371   -- 8 Input TDC
 *
 *              F E D C B A 9 8 7 6 5 4 3 2 1 0
 *     HEADER:  1 0 0 0 <-VDC-> <-----VSN----->
 *
 *              F E D C B A 9 8 7 6 5 4 3 2 1 0
 *     PATTERN: 0 0 0 0 0 0 0 0 <-----PW------>
 *
 *              F E D C B A 9 8 7 6 5 4 3 2 1 0
 *     DATA:    0 <SA-> <--------DATA--------->
 *
 *     N.B. Never use OVF-bit so that MSB of data is always 0.
 *          Since the header is followed by pattern-word, 
 *          total data length is VDC + 2.  
 *
 * Category 3 (TYPE=2, i.e. VSN=128..191)
 *
 *   3377   -- 32 Channel TDC
 *         (single word format & leading edge only)
 *
 *              F E D C B A 9 8 7 6 5 4 3 2 1 0
 *     HEADER:  1 0 <ESN> 0 <R> <-----VSN----->
 *
 *              F E D C B A 9 8 7 6 5 4 3 2 1 0
 *     DATA:    0 <--SA---> <------DATA------->
 *
 *     N.B. VDC (Valid Data Count) is NOT included in HEADER.
 *
 */

#endif /* FERA_H */

#ifndef HSM_CONF_H
#define HSM_CONF_H

/*====== Edit the following values according to your system ======*/

/* Number of HSM/FERAbus to be used */
#define HSM_NUM   1

/* HSMs are serially numbered beginning with 0, i.e. 0, 1, 2,..., 
 * which are written in block header ID.  
 * HSM_IRQ and HSM_MEM_BASE must be a list with length of at least HSM_NUM,
 * though extra elements are simply ignored.  */

/* VMEbus IRQ level, which must be 1 thru 7 with increasing priority.  
 * Make sure that correnpoinding T-INT jumbers of 617|618 are set.  */
#define HSM_IRQ       { 6, 5, 4, 3 }

/* Base memory address of each HSM according to jumber setting.  
 * Corresponding jumbers:  J05     J06     J07     J08     J09    */
#define HSM_MEM_BASE  { ((1<<24)|(0<<25)|(0<<26)|(0<<27)|(0<<28)),\
                        ((0<<24)|(1<<25)|(0<<26)|(0<<27)|(0<<28)),\
                        ((1<<24)|(1<<25)|(0<<26)|(0<<27)|(0<<28)),\
                        ((0<<24)|(0<<25)|(1<<26)|(0<<27)|(0<<28)) }

/* Following are common parameters for all HSMs */

/* Memory size, either 1MB (0x100000) or 512kB (0x80000) */
#define HSM_MEM_SIZE 0x100000

/*
 * Overflow limit: size of remaining part of block before interrupt occurs. 
 *   Make sure (overflow limit) >> (scaler data size) + (max. event length)
 *   and must be n times 512 where n <= 7 (3584) . */
#define HSM_MOVR_LIM 1024


/*====== Followings must not be modified ? (if not power user...) ======*/

/* Block size in 16-bit mode */
#define HSM_BLK_SIZE (65536/sizeof(short))

/* Block numbers in buffer -- last block is reserved against overrun */
#define HSM_BLK_NUM  ((HSM_MEM_SIZE/sizeof(short)\
		      /HSM_BLK_SIZE)-1)

/* Header configuration */
#define HSM_HDR_LEN  4

/* Block ID */
#define HSM_BLK_ID(b)   (b)[0]
/*   Start comment block */
#define HSM_BID_STA     0x0001
/*   Stop  comment block */
#define HSM_BID_STO     0xffff
/*   Good raw data with HSM identifier of ID */
#define HSM_BID_RAW(ID) (ID<<8)
/*   Bad data (serious error e.g. FERA bus overrun, DMA error, etc.) */
#define HSM_BID_BAD     0xff00
/*   Ill data (inconsistent scaler with raw data, 
          due to collision of scaler PIO & raw data DMA, now meaningless) */
#define HSM_BID_ILL     0xfe00

/* Block serial number in a run */
#define HSM_BLK_SN(b)   (b)[1]

/* End of available data */
#define HSM_BLK_LEN(b)  (b)[2]

/* Pointer to scaler address (in 16-bit array), but redundant ? */
#define HSM_SCL_ADR(b)  (b)[3]

/* Test if valid data block */
#define HSM_BID_VALID(bid)  ((bid & ~HSM_BID_RAW(7)) == 0)

/*
 * HSM_BLK_ID  is used in src/{recorder.c,ampler,analyser/analyzer.c}
 * HSM_BLK_LEN is used in src/analyzer/analyzer.c
 * SCL_BLK_OFS is used instead of HSM_SCL_ADR, making it redundant.  
 *
 *       Presumably an event counter in block header is more helpful, 
 *       but there is no way, in general, to obtain event counter 
 *       without using an extra scaler.  
 *       Instead, scaler at end of block will do the same job...
 */

/*
 * If header configuration is modified, 
 * source codes of "hsm8176/hsm.c" 
 *
 *      in static void hsm_buf_xfer()
 * 
 * must be also modified.
 */

#endif /* HSM_CONF_H */

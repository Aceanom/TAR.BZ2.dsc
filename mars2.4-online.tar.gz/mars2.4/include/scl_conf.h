#ifndef SCL_CONF_H
#define SCL_CONF_H

#ifndef HSM_CONF_H
#include "hsm_conf.h"
#endif

//#define LRS1151
#define VTS801
//#define VTS801_2

#define SCL_DEV_A16D16   0
#define SCL_DEV_A16D32   1
#define SCL_DEV_A24D16   2
#define SCL_DEV_A24D32   3
#define SCL_DEV_A32D16   4
#define SCL_DEV_A32D32   5

#ifdef LRS1151
/* for LeCroy 1151, 1-module */
#define SCL_NUM_DATA    16
/* set MEM_BASE according to 4-digit rotaty switch (lower 2-digit = 0) */
#define SCL_MEM_BASE    0x040000
#define SCL_MEM_SIZE    0x100
#define SCL_OFS_DATA    (0x80>>2)
#define SCL_DEV_MINOR   SCL_DEV_A24D32
#define SCL_VARS        *scl_mem
#define SCL_VAR_MMAP    \
scl_mem = (unsigned int *)\
	vmehb_dev_mmap(SCL_DEV_MINOR, SCL_MEM_BASE, SCL_MEM_SIZE);
#define SCL_VAR_UNMAP   \
	vmehb_dev_unmap(SCL_DEV_MINOR, SCL_MEM_BASE, SCL_MEM_SIZE);
#define SCL_RESET       scl_mem[0] = 0;
#define SCL_READ_CH(v)  scl_mem[v+SCL_OFS_DATA]
#endif /* LRS1151 */

#ifdef VTS801
/* for TechnoLand VTS801, 1-module */
#define SCL_NUM_DATA    64
/* set MEM_BASE according to 24-bit dip switch (lower 2-digit = 0) */
#define SCL_MEM_BASE    0x80000000
#define SCL_MEM_SIZE    0x100
#define SCL_DEV_MINOR   SCL_DEV_A32D32
#define SCL_VARS        *scl_mem
#define SCL_VAR_MMAP    \
scl_mem = (unsigned int *)\
	vmehb_dev_mmap(SCL_DEV_MINOR, SCL_MEM_BASE, SCL_MEM_SIZE);
#define SCL_VAR_UNMAP   \
	vmehb_dev_unmap(SCL_DEV_MINOR, SCL_MEM_BASE, SCL_MEM_SIZE);
#define SCL_RESET       scl_mem[0] = 0;
#define SCL_READ_CH(v)  scl_mem[v]
#endif /* VTS801 */

#ifdef VTS801_2
/* for TechnoLand VTS801, 2 modules */
#define SCL_NUM_DATA    (64*2)
/* set MEM_BASE according to 24-bit dip switch (lower 2-digit = 0) */
#define SCL_MEM_BASE1   0x80000000
#define SCL_MEM_BASE2   0x80010000
#define SCL_MEM_SIZE    0x100
#define SCL_DEV_MINOR   SCL_DEV_A32D32
#define SCL_VARS        *scl_mem1, *scl_mem2
#define SCL_VAR_MMAP    \
scl_mem1 = (unsigned int *)\
	vmehb_dev_mmap(SCL_DEV_MINOR, SCL_MEM_BASE1, SCL_MEM_SIZE);\
scl_mem2 = (unsigned int *)\
	vmehb_dev_mmap(SCL_DEV_MINOR, SCL_MEM_BASE2, SCL_MEM_SIZE);
#define SCL_VAR_UNMAP   \
	vmehb_dev_unmap(SCL_DEV_MINOR, SCL_MEM_BASE1, SCL_MEM_SIZE);\
	vmehb_dev_unmap(SCL_DEV_MINOR, SCL_MEM_BASE2, SCL_MEM_SIZE);
#define SCL_RESET       scl_mem1[0] = 0;\
			scl_mem2[0] = 0;
#define SCL_READ_CH(v)  (v < (SCL_NUM_DATA/2) ? scl_mem1[v] : scl_mem2[v-64])
#endif /* VTS801_2 */

/* address pointer to scaler data in a 16-bit block data */
#define SCL_BLK_OFS     (HSM_BLK_SIZE-2*SCL_NUM_DATA)

#endif /* SCL_CONF_H */

#ifndef ANALYZER_H
#define ANALYZER_H

void hstini_(char *, int *, int);

int  event1_(int *, int *);

void hstend_(unsigned int *);

void hststa_(char *, char *, int, int);

void hststo_(unsigned int *);

int  stablk_(unsigned int *);

int  endblk_(unsigned int *);

int  usrast_();

#endif /* ANALYZER_H */

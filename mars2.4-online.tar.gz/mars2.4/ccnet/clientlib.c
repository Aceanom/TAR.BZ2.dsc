/*
 * clientlib.c : Network CAMAC library for PCI / pipeline CAMAC controller
 * Copyright 2003 (C) 2003 Yoshiji Yasu <Yoshiji.YASU@kek.jp>.
 *
 * version: 0.1  25-JUN-2003, born
 *          0.2  11-AUG-2003, beta release
 *          0.3  03-OCT-2003, add cam_getint routine
 *          0.4  07-NOV-2003, add NODELAY socket option
 *          0.5  07-JAN-2004, bug fix for cam_disable_trig, cam_disable_lam
 *                            cam_wait_lam and cam_wait_trig
 *          0.51 08-JAN-2004, bug fix for cam_enable_lam
 *          0.6  12-JAN-2004, add REUSEADDR socket opt
 *          0.61 13-JAN-2004, bug fix for dump_reg
 *                            by H.Okamura <okamura@rcnp.osaka-u.ac.jp>
 *               05-Aug-2008, (un)link => (un)link0, avoid conflict w/ unistd.h
 *                            separated header(s), and fixed minor bugs. 
 */


#include <stdio.h>
#include <sys/types.h>
#include <stdlib.h>
#include <unistd.h>
#include <netdb.h>
#include <string.h>

#include <sys/socket.h>       /*  socket definitions        */
#include <netinet/in.h>
#include <arpa/inet.h>        /*  inet (3) funtions         */
#include <netinet/tcp.h>

#include "ccnet.h"
#include "clientlib.h"
#include "message.h"

/*  Global constants  */

static int       conn_s;                /*  connection socket         */
static struct    sockaddr_in servaddr;  /*  socket address structure  */
static struct    hostent *host;
static int link_status = 0;
#ifdef NODELAY_OPTION
static int option = 1;
#endif
static int sndbuf[(HEADER_SIZE+sizeof(struct pccreg))/sizeof(int)]; 
static int rcvbuf[(HEADER_SIZE+sizeof(struct pccreg))/sizeof(int)];
static int cmdbuf[MAX_LENGTH];

static char HOSTNAME[][256]={HOSTNAMES};

int unlink0() {
  close(conn_s);
  link_status = 0;
  return 0;
}

int link0(int crate) {

    conn_s = socket( AF_INET, SOCK_STREAM, 0 );
#ifdef NODELAY_OPTION
    if( setsockopt(conn_s, SOL_TCP, TCP_NODELAY, &option, sizeof(option))
        < 0 ) {
      printf("CCNET client: Error setsocket(TCP_NODELAY)\n");
      exit(1);
    }
#endif
#ifdef SO_REUSEADDR_OPTION
    if( setsockopt(conn_s, SOL_SOCKET, SO_REUSEADDR, &option, sizeof(option))
        < 0 ) {
      printf("CCNET client: Error setsocket(SO_REUSEADDR)\n");
      exit(1);
    }
#endif
    servaddr.sin_port        = htons(PORT);
    host = (struct hostent *)gethostbyname( (const char *)HOSTNAME[crate] );
    if( !host )
      {
	printf( "CCNET client: Error resolving hostname" );
	exit( 1 );
      }
    bcopy( (char *)host->h_addr, (char *)&servaddr.sin_addr, host->h_length );
    servaddr.sin_family      = host->h_addrtype;
    if ( connect(conn_s, (struct sockaddr *)&servaddr, sizeof(servaddr) ) < 0 ) {
	printf("CCNET client: Error calling connect()\n");
	exit(1);
    }
    link_status = 1;
    
    return 0;
}

int cam_open(int crate) {
  int status;

  if ( link_status )
    return -1;
  status = link0(crate);
  if( status ) 
    return status;

  sndbuf[0] = htonl(HEADER_SIZE);
  sndbuf[1] = htonl(CC_OPEN);
  status = writeMessage( conn_s, (char *)sndbuf, HEADER_SIZE );
  if( status ) 
    return status;
#ifdef DEBUG
  printf("cam_open: writeMessage is done\n");
  printf("write : Header[0] = %d : Header[1] = %d\n", 
               ntohl(sndbuf[0]), ntohl(sndbuf[1]));
#endif
  status = readMessage( conn_s, (char *)rcvbuf, HEADER_SIZE );
  return status;
}

int cam_close( int fd ) {
  int status;

  if( !link_status )
    status = -1;
  sndbuf[0] = htonl(HEADER_SIZE);
  sndbuf[1] = htonl(CC_CLOSE);
  status = writeMessage( conn_s, (char *)sndbuf, HEADER_SIZE );
  if( status ) 
    return status;
  status = readMessage( conn_s, (char *)rcvbuf, HEADER_SIZE );
  if( status ) 
    return status;

  unlink0();
  return 0;
}

int cam_dump_pccreg(int fd, struct pccreg *pccreg) {
  int status, i;

  sndbuf[0] = htonl(HEADER_SIZE);
  sndbuf[1] = htonl(CC_DUMP);
  status = writeMessage( conn_s, (char *)sndbuf, HEADER_SIZE );
  if( status ) 
    return status;
  status = readMessage( conn_s, (char *)rcvbuf,
			(HEADER_SIZE+sizeof(struct pccreg)) );
  if( status ) 
    return status;
  for(i = 0; i < sizeof(struct pccreg)/4; i++)
    rcvbuf[i+2] = ntohl(rcvbuf[i+2]);
  memcpy(pccreg, &rcvbuf[2], sizeof(struct pccreg));
  return 0;
}

int cam_reset( int fd ) {
  int status;

  sndbuf[0] = htonl(HEADER_SIZE);
  sndbuf[1] = htonl(CC_RESET);
  status = writeMessage( conn_s, (char *)sndbuf, HEADER_SIZE );
  if( status ) 
    return status;
  status = readMessage( conn_s, (char *)rcvbuf, HEADER_SIZE );
  return status;
}

int cam_clear_fifo( int fd ) {
  int status;

  sndbuf[0] = htonl(HEADER_SIZE);
  sndbuf[1] = htonl(CC_CLRFIFO);
  status = writeMessage( conn_s, (char *)sndbuf, HEADER_SIZE );
  if( status ) 
    return status;
  status = readMessage( conn_s, (char *)rcvbuf, HEADER_SIZE );
  return status;
}

int cam_enable_lam( int fd, int enable_pattern ) {
  int status;

  sndbuf[0] = htonl(HEADER_SIZE+sizeof(int));
  sndbuf[1] = htonl(CC_ENABLE_LAM);
  sndbuf[2] = htonl(enable_pattern);
  status = writeMessage( conn_s, (char *)sndbuf, HEADER_SIZE+sizeof(int) );
  if( status ) 
    return status;
  status = readMessage( conn_s, (char *)rcvbuf, HEADER_SIZE );
  return status;
}

int cam_wait_lam( int fd, int* lam_pattern, int timeout ) {
  int status;

  sndbuf[0] = htonl(HEADER_SIZE+sizeof(int));
  sndbuf[1] = htonl(CC_LAM);
  sndbuf[2] = htonl(timeout);
  status = writeMessage( conn_s, (char *)sndbuf, (HEADER_SIZE+sizeof(int)) );
  if( status ) 
    return status;
  status = readMessage( conn_s, (char *)rcvbuf, (HEADER_SIZE+sizeof(int) ) );
  if( status ) 
    return status;
  *lam_pattern =  ntohl(rcvbuf[2]);
  return status;
}

int cam_disable_lam( int fd ) {
  int status;

  sndbuf[0] = htonl(HEADER_SIZE);
  sndbuf[1] = htonl(CC_DISABLE_LAM);
  status = writeMessage( conn_s, (char *)sndbuf, HEADER_SIZE );
  if( status ) 
    return status;
  status = readMessage( conn_s, (char *)rcvbuf, HEADER_SIZE );
  return status;
}

int cam_enable_trig( int fd ) {
  int status;

  sndbuf[0] = htonl(HEADER_SIZE);
  sndbuf[1] = htonl(CC_ENABLE_TRIG);
  status = writeMessage( conn_s, (char *)sndbuf, HEADER_SIZE );
  if( status ) 
    return status;
  status = readMessage( conn_s, (char *)rcvbuf, HEADER_SIZE );
  return status;
}

int cam_wait_trig( int fd, int* event_count, int timeout ) {
  int status;

  sndbuf[0] = htonl(HEADER_SIZE+sizeof(int));
  sndbuf[1] = htonl(CC_TRIG);
  sndbuf[2] = htonl(timeout);
  status = writeMessage( conn_s, (char *)sndbuf, (HEADER_SIZE+sizeof(int)) );
  if( status ) 
    return status;
  status = readMessage( conn_s, (char *)rcvbuf, (HEADER_SIZE+sizeof(int) ) );
  if( status ) 
    return status;
  *event_count =  ntohl(rcvbuf[2]);
  return status;
}

int cam_disable_trig( int fd ) {
  int status;

  sndbuf[0] = htonl(HEADER_SIZE);
  sndbuf[1] = htonl(CC_DISABLE_TRIG);
  status = writeMessage( conn_s, (char *)sndbuf, HEADER_SIZE );
  if( status ) 
    return status;
  status = readMessage( conn_s, (char *)rcvbuf, HEADER_SIZE );
  return status;
}

int cam_get( int fd, int* data, int* rply ) {
  int status;

  sndbuf[0] = htonl(HEADER_SIZE);
  sndbuf[1] = htonl(CC_GET);
  status = writeMessage( conn_s, (char *)sndbuf, HEADER_SIZE );
  if( status ) 
    return status;
  status = readMessage( conn_s, (char *)rcvbuf,
			 (HEADER_SIZE+sizeof(int)*2) );
#ifdef DEBUG
  printf("cam_get:data=%x and rply=%x\n", ntohl(rcvbuf[2]), ntohl(rcvbuf[3]));
#endif
  if( status ) 
    return status;
  *data =  ntohl(rcvbuf[2]);
  *rply =  ntohl(rcvbuf[3]);
  return status;
}

int cam_getint( int fd, int* data, int* rply ) {
  int status;

  sndbuf[0] = htonl(HEADER_SIZE);
  sndbuf[1] = htonl(CC_GETINT);
  status = writeMessage( conn_s, (char *)sndbuf, HEADER_SIZE );
  if( status ) 
    return status;
  status = readMessage( conn_s, (char *)rcvbuf,
			 (HEADER_SIZE+sizeof(int)*2) );
#ifdef DEBUG
  printf("cam_getint:data=%x and rply=%x\n", ntohl(rcvbuf[2]), ntohl(rcvbuf[3]));
#endif
  if( status ) 
    return status;
  *data =  ntohl(rcvbuf[2]);
  *rply =  ntohl(rcvbuf[3]);
  return status;
}

int cam_put(int fd, int data, int cmd ) {
  int status, i;

  sndbuf[0] = HEADER_SIZE+sizeof(int)*2;
  sndbuf[1] = CC_PUT;
  sndbuf[2] = data;
  sndbuf[3] = cmd;
  for(i=0; i < 4; i++)
    sndbuf[i] = htonl(sndbuf[i]);
#ifdef DEBUG
  printf("cam_put:data=%x and cmd=%x\n", data, cmd);
#endif
  status = writeMessage( conn_s, (char *)sndbuf, HEADER_SIZE+sizeof(int)*2 );
  if( status ) 
    return status;
  status = readMessage( conn_s, (char *)rcvbuf,
			HEADER_SIZE );
  if( status ) 
    return status;
  return status;
}

int exec_frame( int* cmdbuf_orig, int* rplybuf ) {
  int status;
  int i, count;

  count = 8+cmdbuf_orig[1]*8;
  // send header 
#ifdef DEBUG
  printf("exec_frame:send header:total length=%d\n", count);
#endif
  sndbuf[0] = htonl(HEADER_SIZE+count);
  status = writeMessage( conn_s, (char *)sndbuf, HEADER_SIZE );
  if( status ) 
    return status;
  for(i=0; i<count/4; i++)
    cmdbuf[i] = htonl(cmdbuf_orig[i]);
  // send cmdbuf
#ifdef DEBUG
  printf("exec_frame:send cmdbuf:cmdbuf[0]=%d,cmdbuf[1]=%d\n", cmdbuf[0], cmdbuf[1]);
#endif
  status = writeMessage( conn_s, (char *)cmdbuf, count );
  if( status ) 
    return status;

  // receive header
#ifdef DEBUG
  printf("exec_frame:receive head\n");
#endif
  status = readMessage( conn_s, (char *)rcvbuf,
			HEADER_SIZE );
  if( status ) 
    return status;

  // receive header of rplybuf
#ifdef DEBUG
  printf("exec_frame:receive head of rplybuf\n");
#endif
  status = readMessage( conn_s, (char *)rplybuf,
			HEADER_SIZE );
  if( status ) 
    return status;

  rplybuf[0] = ntohl(rplybuf[0]);
  count = rplybuf[1] = ntohl(rplybuf[1]);
  // receive body of rplybuf
#ifdef DEBUG
  printf("exec_frame:receive body of rplybuf\n");
#endif
  status = readMessage( conn_s, (char *)(rplybuf+2),
			count*8 );
  if( status ) 
    return status;
  for(i=0; i< count*2; i++)
    rplybuf[i+2] = ntohl(rplybuf[i+2]);
  return status;
}

int cam_exec_pio( int fd, int* cmdbuf, int* rplybuf ) {

  sndbuf[1] = htonl(CC_EXEC_PIO);
  return exec_frame( cmdbuf, rplybuf );
}

int cam_exec_dma( int fd, int* cmdbuf, int* rplybuf ) {

  sndbuf[1] = htonl(CC_EXEC_DMA);
  return exec_frame( cmdbuf, rplybuf );
}

int cam_exec_dma_seq( int fd, int* cmdbuf, int* rplybuf ) {

  sndbuf[1] = htonl(CC_EXEC_SEQ);
  return exec_frame( cmdbuf, rplybuf );
}

int cam_exec( int fd, int* cmdbuf, int* rplybuf ) {

  sndbuf[1] = htonl(CC_EXEC);
  return exec_frame( cmdbuf, rplybuf );
}

// ---------------------------------------------
// hardware independent codes
// ---------------------------------------------

int cam_naf( n, a, f )
     int n, a, f; {
  return  ((((n<<8) + a) << 8) + f);
}

void dump_pccreg(struct pccreg *pccreg) {

  printf("Tx Control      = %x\n", pccreg->TxControl);
  printf("Tx Status       = %x\n", pccreg->TxStatus);
  printf("Tx Address      = %x\n", pccreg->TxAddress);
  printf("Tx Preset Count = %x\n", pccreg->TxPresetCount);
  printf("Tx Actual Count = %x\n", pccreg->TxActualCount);
  printf("Tx Fifo Count   = %x\n", pccreg->TxFifoCount);
  printf("Rx Control      = %x\n", pccreg->RxControl);
  printf("Rx Status       = %x\n", pccreg->RxStatus);
  printf("Rx Address      = %x\n", pccreg->RxAddress);
  printf("Rx Preset Count = %x\n", pccreg->RxPresetCount);
  printf("Rx Actual Count = %x\n", pccreg->RxActualCount);
  printf("Rx Fifo Count   = %x\n", pccreg->RxFifoCount);
  printf("System          = %x\n", pccreg->System);
  printf("Int Control     = %x\n", pccreg->IntControl);
  printf("Int Status      = %x\n", pccreg->IntStatus);
  printf("Int Fifo Count  = %x\n", pccreg->IntFifoCount);
}

int gen_cam_command(int *data1, int *data2, int n, int a, int f, int data, int flag ) {
  int cmd = 0;

  if( n >= 0 && (n <=23 || n==25) && a >= 0 && a <=15 && f >=0 && f <=31 ) {
    cmd = cam_naf(n, a, f);
    switch (flag) {
    case 0: // normal
      cmd |= 0x80000000;
      break;
    case 1: // start bit
      cmd |= 0xC0000000;
      break;
    case 2: // end bit
      cmd |= 0xA0000000;
      break;
    default:
      cmd |= 0xE0000000;
    }
    *data1 = data & 0xFFFFFF;
    *data2 = cmd;
  } else
    return -1;
  return 0;
}

int gen_daq_command(int *data1, int *data2, int func, int flag ) {
  int cmd;

  cmd = func;
  switch (flag) {
  case 0: // normal
    cmd |= 0x90000000;
    break;
  case 1: // start bit
    cmd |= 0xD0000000;
    break;
  case 2: // end bit
    cmd |= 0xB0000000;
    break;
  default:
    cmd |= 0xF0000000;
  }
  *data1 = 0;
  *data2 = cmd;
  return 0;
}

int cam_gen_init( int length, int* buf ) {
  int i;
  if( length <= 0 || length > MAX_LENGTH )
    return -1;
  buf[0] = length;
  buf[1] = 0;
  for(i=2;i<length*2+2;i++)
    buf[i] = 0;
  return 0;
}

int cam_gen_cc( int *buf, int n, int a, int f, int data ) {
  int status;
  int header;

  if( buf[0] == buf[1] )
    return -2;
  if( buf[1] < 0 )
    return -3;
  switch (buf[1]) {
  case 0:
    status = gen_cam_command(&buf[buf[1]*2+2],&buf[buf[1]*2+3],n,a,f,data,3);
    break;
  case 1:
    header = (buf[buf[1]*2+1]>>24)&0xFF;
    buf[buf[1]*2+1] &= ~0xF0000000;
    if(header == 0xE0)
      buf[buf[1]*2+1] |= 0xC0000000;
    else
      buf[buf[1]*2+1] |= 0xD0000000;
    status = gen_cam_command(&buf[buf[1]*2+2],&buf[buf[1]*2+3],n,a,f,data,2);
    if( status == -1 )
      return status;
    break;
  default:
    header = (buf[buf[1]*2+1]>>24)&0xFF;
    buf[buf[1]*2+1] &= ~0xF0000000;
    if(header == 0xA0)
      buf[buf[1]*2+1] |= 0x80000000;
    else
      buf[buf[1]*2+1] |= 0x90000000;
    status = gen_cam_command(&buf[buf[1]*2+2],&buf[buf[1]*2+3],n,a,f,data,2);
    if( status == -1 )
      return status;
  }
  buf[1]++;
  return status;
}

int cam_gen_daq( int* buf, int cmd, int data ) {
  int status;
  int header;

  if( buf[0] == buf[1] )
    return -2;
  if( buf[1] < 0 )
    return -3;
  switch (buf[1]) {
  case 0:
    status = gen_daq_command(&buf[buf[1]*2+2],&buf[buf[1]*2+3],cmd,3);
    break;
  case 1:
    header = (buf[buf[1]*2+1]>>24)&0xFF;
    buf[buf[1]*2+1] &= ~0xF0000000;
    if(header == 0xE0)
      buf[buf[1]*2+1] |= 0xC0000000;
    else
      buf[buf[1]*2+1] |= 0xD0000000;
    status = gen_daq_command(&buf[buf[1]*2+2],&buf[buf[1]*2+3],cmd,2);
    if( status == -1 )
      return status;
    break;
  default:
    header = (buf[buf[1]*2+1]>>24)&0xFF;
    buf[buf[1]*2+1] &= ~0xF0000000;
    if(header == 0xA0)
      buf[buf[1]*2+1] |= 0x80000000;
    else
      buf[buf[1]*2+1] |= 0x90000000;
    status = gen_daq_command(&buf[buf[1]*2+2],&buf[buf[1]*2+3],cmd,2);
    if( status == -1 )
      return status;
  }
  buf[1]++;
  return status;
}

void cam_decode_cc_frame( int data1, int data2, int* n, int* a, int* f, int* data, int* status) {

  *data = data1 & 0xFFFFFF;
  *status = (data1>>24) & 0xFF;
  *f    = data2 & 0x1F;
  *a    = (data2>>8) & 0xF;
  *n    = (data2>>16) & 0x1F;
}

int cam_extract_cc_data( int* rplybuf, int len, int* actuallen, int* data ) {
  int i, num;

  num = rplybuf[1]; // get number of reply frames
  if( num > len )
    return -2; // lots of data are included in rplybuf
  for( i = 0; i < num; i++ )
    data[i] = rplybuf[2*i+2] & 0xFFFFFF;
  *actuallen = num;
  return 0;
}

int cam_extract_cc_status( int* rplybuf, int len, int* actuallen, int* status ) {
  int i, num;

  num = rplybuf[1]; // get number of reply frames
  if( num > len )
    return -2; // lots of data are included in rplybuf
  for( i = 0; i < num; i++ )
    status[i] = (rplybuf[2*i+2]>>24) & 0xFF;
  *actuallen = num;
  return 0;
}

int cam_extract_cc_qx( int status, int* q, int* x ) {
  *q = status & 1;
  *x = (status>>1) & 1;
  return 0;
}

int cam_extract_daq_data( int* rplybuf, int len, int* actuallen, int* data ) {
  int i, num;

  num = rplybuf[1]; // get number of reply frames
  if( num > len )
    return -2; // lots of data are included in rplybuf
  for( i = 0; i < num; i++ )
    data[i] = rplybuf[2*i+2];
  *actuallen = num;
  return 0;
}

int cam_single_cc( int fd, int n, int a, int f, int *data, int *q, int *x ) {
  int qx;
  int data1, data2;
  int cmd, rply;
  int status;

  status = gen_cam_command( &data1, &cmd, n, a, f, *data, 3);
  if( status )
    return -1;

  status = cam_put( fd, data1, cmd );
  if( status )
    return -1;
  status = cam_get( fd, &data2, &rply );
  if( status )
    return -1;
  if( (f>=0) && (f<=7) )
    *data = 0xFFFFFF&data2;
  qx = 0x3&(data2>>24);
  if( qx & 1 )
    *q = 1;
  else
    *q = 0;
  if( qx & 2 )
    *x = 1;
  else
    *x = 0;
  return 0;
}

int cam_single_daq( int fd, int func, int *data, int *daq_status ) {
  int data1, data2;
  int cmd, rply;
  int status;

  status = gen_daq_command( &data1, &cmd, func, 3 );
  if( status )
    return -1;
  status = cam_put( fd, data1, cmd );
  if( status )
    return -1;
  status = cam_get( fd, &data2, &rply );
  if( status )
    return -1;
  *data = data2;
  *daq_status = 0xFF & rply;
  return 0;
}

#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <unistd.h>
#include <stdlib.h>
#include <stdio.h>
#include "clientlib.h"

int main(int argc, char *argv[])
{
  int   fd=0, c, n, a, f, data, q, x, status;
  if (argc < 5) {printf("Usage: %s c n a f [data]\n", argv[0]); return 4;}
  if ((c = atoi(argv[1])) < 0 || c >=  MAX_CRATE ||
      (n = atoi(argv[2])) < 1 || n > 25 || /* N=25 for CC/NET */
      (a = atoi(argv[3])) < 0 || a > 15 ||
      (f = atoi(argv[4])) < 0 || f > 31) return 4;
  if (argc > 5) data = atoi(argv[5]);
  if ((fd = cam_open(c)) == -1) return 4;
  status = cam_single_cc(fd, n, a, f, &data, &q, &x);
  cam_close(fd);
  if (status) return 4;
  if ((f & 0x18) == 0x00) printf("%d\n", data);
  return ~(x<<1|q)&3;
}

/*
 *  Some special functions for CC/NET
 *
 *  N=25  A=0  F=17  : Z
 *        A=0  F=16  : C
 *        A=0  F=26  : Inhibit ON
 *        A=0  F=24  : Inhibit OFF
 *        A=1  F=26  : Interrupt ON
 *        A=1  F=24  : Interrupt OFF
 */

/*
 * ccnet.h : Network CAMAC library for PCI / pipeline CAMAC controller
 * Copyright 2003 (C) 2003 Yoshiji Yasu <Yoshiji.YASU@kek.jp>.
 *
 * version: 0.1  25-JUN-2003, born
 *          0.2  11-AUG-2003, beta release
 *          0.3  03-OCT-2003, add cam_getint routine
 *          0.4  07-NOV-2003, add NODELAY socket option
 */

//#define DEBUG
#define NODELAY_OPTION
#define SO_REUSEADDR_OPTION

#define CC_OPEN  1
#define CC_CLOSE 2
#define CC_DUMP  3
#define CC_RESET 4
#define CC_CLRFIFO 5
#define CC_ENABLE_LAM 10
#define CC_LAM  11
#define CC_DISABLE_LAM 12
#define CC_ENABLE_TRIG 13
#define CC_TRIG 14
#define CC_DISABLE_TRIG 15
#define CC_GET 101
#define CC_PUT 102
#define CC_GETINT 103
#define CC_EXEC_PIO 104
#define CC_EXEC_DMA 105
#define CC_EXEC_SEQ 106
#define CC_EXEC     107

#define HEADER_SIZE       (sizeof(int)*2)
#define PORT (2003)
//#define HOSTNAME          "ccnet01.rcnp.osaka-u.ac.jp"

/*
 * send and receive buffer format
 *
 * On server 
 * rcvbuf : Header(2) + cmdbuf
 * sndbuf : Header(2) + rplybuf
 *
 * On client
 * sndbuf : Header(2) + ( cmdbuf or data )
 * rcvbuf : Header(2) + ( rplybuf or data )
 *
 * Header :
 *          Header[0] = total length in bytes including itself
 *          Header[1] = command
 *
 * cmdbuf and rcvbuf :
 *          cmdbuf[0] = rplybuf[0] = number of frame can be stored
 *          cmdbuf[1] = rplybuf[1] = number of frame stored
 *          cmdbuf[2..] = rplybuf[2..] = frames
 * data : depends on the command
 *
 */

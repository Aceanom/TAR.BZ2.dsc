/*
 * "libtclcam.so"
 *
 *  Tcl library for Toyo CC/NET
 *
 *  creates a tcl command : camac
 *
 *  its subcommands and return values:
 *
 *    crate   c
 *    read    n a f v  ; Q X  (v must be variable name)
 *    write   n a f d  ; Q X
 *    naf     n a f    ; Q X
 *    lam              ; LAM pattern string (index 0 => n 1)
 *    Z
 *    initialize
 *    C
 *    clear
 *    I       i        ; i = 0 or 1
 *    inhibit i
 *   
 */

#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <unistd.h>
#include <stdlib.h>
#include <string.h>
#include <stdio.h>
#include <tcl.h>
#include "clientlib.h"

#define FDini 123
static int     fd = FDini;
static int     crate = 0, n, a, f, data, q, x;
static char    result[32];
static char    QX[2][2][4]={{"", "X"}, {"Q", "Q X"}};

#define checkargc(narg,msg) \
if(argc!=narg){Tcl_SetResult(interp,msg,TCL_STATIC);return TCL_ERROR;}
#define CAM_RETURN(ret) {cam_close(fd); fd = FDini; return ret;}
#define checknaf(f1,f2) \
if ((n = atoi(argv[2])) <= 0 || n > 24 ||\
    (a = atoi(argv[3])) <  0 || a > 15 ||\
    (f = atoi(argv[4])) < f1 || f > f2) {\
   Tcl_SetResult(interp,"Error: invalid (n,a,f)",TCL_STATIC);\
   CAM_RETURN(TCL_ERROR);}
#define CAM_SINGLE_CC(N,A,F) \
   if (cam_single_cc(fd, N, A, F, &data, &q, &x)) {\
      Tcl_SetResult(interp, "Error: camac access failure", TCL_STATIC);\
      CAM_RETURN(TCL_ERROR);}

int tclcamCmd _ANSI_ARGS_(( ClientData clientData, 
			    Tcl_Interp *interp, 
			    int argc, char *argv[] )) 
{
  if (*argv[1] == 'c' && !strcmp(argv[1], "crate")) {
    checkargc(3,"Error: crate number must be given.");
    if ((crate = atoi(argv[2])) < 0 || crate >= MAX_CRATE) {
      Tcl_SetResult(interp, "Error: invalid crate#", TCL_STATIC);
      return TCL_ERROR;
    } else
      return TCL_OK;
  }

  if ((fd == FDini) && (fd = cam_open(crate)) == -1) {
      Tcl_SetResult(interp, "Error: camac open error", TCL_STATIC);
      return TCL_ERROR;
  }

  if (*argv[1] == 'r' && !strcmp(argv[1], "read")) {
    checkargc(6,"Error: n a f var must be given.");
    checknaf(0,7);
    CAM_SINGLE_CC(n,a,f);
    sprintf(result, "%d", data);
    if (Tcl_SetVar(interp, argv[5], (char *)result, TCL_LEAVE_ERR_MSG)
	== NULL) CAM_RETURN(TCL_ERROR);
    Tcl_SetResult(interp, QX[q][x], TCL_STATIC);
    CAM_RETURN(TCL_OK);
  }

  if (*argv[1] == 'w' && !strcmp(argv[1], "write")) {
    checkargc(6,"Error: n a f data must be given.");
    checknaf(16,23);
    data = atol(argv[5]);
    CAM_SINGLE_CC(n,a,f);
    Tcl_SetResult(interp, QX[q][x], TCL_STATIC);
    CAM_RETURN(TCL_OK);
  }

  if (*argv[1] == 'n' && !strcmp(argv[1], "naf")) {
    checkargc(5,"Error: n a f must be given.");
    checknaf(0,31);
    CAM_SINGLE_CC(n,a,f);
    Tcl_SetResult(interp, QX[q][x], TCL_STATIC);
    CAM_RETURN(TCL_OK);
  }

  if (*argv[1] == 'l' && !strcmp(argv[1], "lam")) {
    int lam, i;
    checkargc(2,"Error: extra argument.");
    if (cam_wait_lam(fd, &lam, 0)<0) {
      Tcl_SetResult(interp, "Error: LAM wait TIMEOUT", TCL_STATIC);
      CAM_RETURN(TCL_ERROR);}
    for (i = 0; i < 24; i++,lam>>=1)
      if (lam & 1) result[i] = '1'; else result[i] = '0';
    result[24] = 0;
    Tcl_SetResult(interp, (char *)result, TCL_STATIC);
    CAM_RETURN(TCL_OK);
  }

  if ((*argv[1] == 'Z' && !strcmp(argv[1], "Z"))||
      (*argv[1] == 'i' && !strcmp(argv[1], "initialize"))) {
    checkargc(2,"Error: extra argument.");
    CAM_SINGLE_CC(25,0,17) else CAM_RETURN(TCL_OK);
  }

  if ((*argv[1] == 'C' && !strcmp(argv[1], "C"))||
      (*argv[1] == 'c' && !strcmp(argv[1], "clear"))) {
    checkargc(2,"Error: extra argument.");
    CAM_SINGLE_CC(25,0,16) else CAM_RETURN(TCL_OK);
  }

  if ((*argv[1] == 'I' && !strcmp(argv[1], "I"))||
      (*argv[1] == 'i' && !strcmp(argv[1], "inhibit"))) {
    checkargc(3,"Error: 1 (=ON) or 0 (=OFF) must be given");
    if (atoi(argv[2])) {CAM_SINGLE_CC(25,0,26);} else {CAM_SINGLE_CC(25,0,24);}
    CAM_RETURN(TCL_OK);
  }

  Tcl_SetResult(interp, "Error: subcommand missing", TCL_STATIC);
  CAM_RETURN(TCL_ERROR);
}


void tclcamExit _ANSI_ARGS_((ClientData clientData)) {if (!fd) cam_close(fd);}

int Tclcam_Init ( Tcl_Interp *interp )
{
  char max_crate[2];
  Tcl_CreateCommand(interp, "camac", (Tcl_CmdProc *)tclcamCmd,
                    (ClientData) NULL, (Tcl_CmdDeleteProc *)NULL );
  sprintf(max_crate, "%1d", MAX_CRATE-1);
  Tcl_SetVar(interp, "MAX_CRATE", max_crate, TCL_GLOBAL_ONLY);
  Tcl_CreateExitHandler((Tcl_ExitProc *)tclcamExit, (ClientData) NULL );
  return TCL_OK;
}

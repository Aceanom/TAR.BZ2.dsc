#ifndef   MESSAGE_H
#define   MESSAGE_H

int  readMessage(int fd, char *ptr, int nbytes);

int writeMessage(int fd, char *ptr, int nbytes);

#endif /* MESSAGE_H */


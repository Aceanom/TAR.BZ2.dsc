#include <unistd.h>

void sleep_(int *sec) {sleep(*sec);}

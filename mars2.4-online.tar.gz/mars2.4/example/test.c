#include <stdio.h>
#include "analyzer.h"

void hstini_(char *name, int *scaler_nu, int len_name)
{
}

int  event1_(int buffer[], int *evtlen)
{
  /*
  int i;
  printf("evtlen=%d\n", *evtlen);
  for (i = 0; i < *evtlen; i++) printf(" %4.4x", buffer[i]);
  puts("");
  */
  return 0;
}

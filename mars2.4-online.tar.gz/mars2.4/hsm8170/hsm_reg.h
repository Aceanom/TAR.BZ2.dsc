#ifndef HSM_REG_H
#define HSM_REG_H

#ifndef HSM_CONF_H
#include "hsm_conf.h"
#endif

#define HSM_REG_BASE(base) (base+0x00100000)
#define HSM_BUF_BASE(base) (base)

/* Interrupt Requester -- intreq */
/* -- (W) Clear Pending Interrupt -- */
#define HSM_INT_CLRP (1<<11)
/* -- (W) IRQ level -- */
#define HSM_INT_IRQL(irq) (irq<<8)
/* -- (R) Interrupt Source (encoded in priority order) -- */
#define HSM_INT_MASK 3
#define HSM_INT_FOVR 3
#define HSM_INT_MFUL 2
#define HSM_INT_MOVR 1
#define HSM_INT_STOP 0

/* Control Register -- cntreg */
/* -- (W) Overflow Limits -- */
#define HSM_CNT_OLIM (HSM_MOVR_LIM<<4)
/* -- (W) Enable/Disable Acquisiton -- */
#define HSM_CNT_DAQ  (1<<12)
/* -- (W) Enable/Disable Interrupt -- */
#define HSM_CNT_STOP (1<<11)
#define HSM_CNT_MFUL (1<<10)
#define HSM_CNT_MOVR (1<< 9)
#define HSM_CNT_FOVR (1<< 8)
/* -- (R) FERA Port Status -- */
#define HSM_FPS_IDLE (1<< 7)
#define HSM_FPS_NEMP (1<< 6)
#define HSM_FPS_16BT (1<< 5)
#define HSM_FPS_AQON (1<< 4)
/* -- (R) Interrupt Source -- */
#define HSM_ISR_STOP (1<< 3)
#define HSM_ISR_MFUL (1<< 2)
#define HSM_ISR_MOVR (1<< 1)
#define HSM_ISR_FOVR (1    )

struct hsm_regstr {
  unsigned int intreq;
  unsigned int cntreg;
  unsigned int adrptr;
  unsigned int wrdcnt;
};

#endif /* HSM_REG_H */

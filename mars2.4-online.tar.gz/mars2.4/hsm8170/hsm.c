/*                                                          */
/*         ... ... ... <<< hsm.c >>> ... ... ...            */
/*                                                          */
/*                A subsidiary device driver                */
/*      for VME/HSM-FERA data acquisition system 'mars'     */
/*     just providing ioctl of HSM and interrupt handler.   */
/*     It depends on vmehb-2.2.x by Natalia  Kruszynska     */
/*            with patching some important issues           */
/*          and runs under Linux 2.0 & 2.2 kernels          */
/*                                                          */

#include <linux/kernel.h>
#include <linux/sched.h>
#include <linux/errno.h>
#include <linux/fs.h>
#include <linux/delay.h>
#include <linux/module.h>

#include <linux/version.h>
#if   LINUX_VERSION_CODE >= 0x020100
#  include <linux/kmod.h>
#  include <asm/uaccess.h>
#  define LINUX_2_2
#  define relse_t         int
/* avoid using inline func. in <linux/sched.h> as to be compiled with -O0 ! */
#  define signal_pending(current)  (current->sigpending != 0)
#  if LINUX_VERSION_CODE >= 0x020300
#    define LINUX_2_4
     MODULE_LICENSE("GPL");
#  else
#    define DECLARE_WAIT_QUEUE_HEAD(name) struct wait_queue *name=NULL
#  endif
#elif LINUX_VERSION_CODE >= 0x020000
#  include <linux/kerneld.h>
#  include <asm/segment.h>
#  define LINUX_2_0
#  define relse_t         void
#  define copy_from_user  memcpy_fromfs
#  define copy_to_user    memcpy_tofs
#  define signal_pending(current)  (current->signal & ~current->blocked)
#  define schedule_timeout(t)   \
	{current->timeout = jiffies + t; schedule(); current->timeout = 0;}
#else
#  error "This kernel is too old: not supported by this file"
#endif

#include "hsm_conf.h"
#include "hsm_reg.h"
static int    hsm_irq[] = HSM_IRQ;
static unsigned int       hsm_mem_base[] = HSM_MEM_BASE;
static struct hsm_regstr *hsm_reg[HSM_NUM];
static unsigned short    *hsm_buf[HSM_NUM];
static int    hsm_blk_wp[HSM_NUM] = {};
static int    hsm_blk_rp[HSM_NUM] = {};
static int    hsm_curr_id = 0;
static DECLARE_WAIT_QUEUE_HEAD(hsm_wait_q);
static int    hsm_wakeups = 0;
static int    hsm_daq_on  = 0;
static int    hsm_finish  = 0;
#define HSM_REG_MINOR   5  /* vme32d32 */
#define HSM_BUF_MINOR   4  /* vme32d16 */

#include "scl_conf.h"
static unsigned int       SCL_VARS;
static unsigned int       scl_buf[HSM_NUM][HSM_BLK_NUM][SCL_NUM_DATA];
static int    scl_pending = 0;

#include "hsm_ioctl.h"

static char   hsm_dev_id[] = HARDWARE;

/* headers exported from vmehb */
// #define __vme_space_driver__
// #include "vmehb_conf.h"
typedef int (*VME_HAN)(int,int);
extern  int           request_vme_irq(int, int, VME_HAN, char *);
extern  void          free_vme_irq   (int, int, VME_HAN);
extern  unsigned long vmehb_dev_mmap (int, unsigned int, unsigned int);
extern  unsigned long vmehb_dev_unmap(int, unsigned int, unsigned int);
/* Followings are exported by patching to vmehb... What a shame ! */
#if   defined(LINUX_2_2)
extern  ssize_t       vmehb_read ();
extern  ssize_t       vmehb_write();
#elif defined(LINUX_2_0)
extern  int           vmehb_read ();
extern  int           vmehb_write();
#endif

static int     hsm_open   (struct inode *inode, struct file *file) {
  MOD_INC_USE_COUNT;
  return 0; 
}

static relse_t hsm_release(struct inode *inode, struct file *file) {
  MOD_DEC_USE_COUNT;
#if   defined(LINUX_2_2)
  return 0;
#endif
}

static void    hsm_buf_xfer (int id) {
  unsigned int   *p, i, 
    reg = hsm_reg[id]->cntreg, 
    adr = hsm_reg[id]->adrptr % HSM_BLK_SIZE,
    wp  = hsm_blk_wp[id] % HSM_BLK_NUM;
  unsigned short *b;
  /* Disable Data Acquisition */
  hsm_reg[id]->cntreg = reg & ~HSM_CNT_DAQ;
  /* Copy scaler data */
  p = scl_buf[id][wp];
  for (i = 0; i < SCL_NUM_DATA; i++) *(p++) = SCL_READ_CH(i);
  /* Reset scaler */
  SCL_RESET;
  /* Write block header */
  b = &hsm_buf[id][wp * HSM_BLK_SIZE];
  if ((reg & (HSM_ISR_MFUL | HSM_ISR_FOVR)) || (adr > SCL_BLK_OFS ))
  HSM_BLK_ID(b)  = HSM_BID_BAD;     /* FERA bus overrun, bad data */
  else if (scl_pending)             /* ... This is now meaningless */
  HSM_BLK_ID(b)  = HSM_BID_ILL;     /* Inconsistent scaler & data */
  else
  HSM_BLK_ID(b)  = HSM_BID_RAW(id); /* Valid data */
  HSM_BLK_SN(b)  = hsm_blk_wp[id];  /* Block serial number */
  HSM_BLK_LEN(b) = adr;             /* End of available data */
  HSM_SCL_ADR(b) = SCL_BLK_OFS;     /* Pointer to scaler address */
  /* Set Word Counter & Address Pointer, which clears overflow.  
     Follow this order of operation, otherwise overflow is set again ! */
  hsm_reg[id]->wrdcnt = HSM_BLK_SIZE - HSM_HDR_LEN;
  hsm_reg[id]->adrptr = (++hsm_blk_wp[id] % HSM_BLK_NUM)
                         * HSM_BLK_SIZE + HSM_HDR_LEN;
  /* Enable Data Acquisition, if DAQ on && buffer is available */
  if (hsm_daq_on && (hsm_blk_rp[id] + HSM_BLK_NUM > hsm_blk_wp[id]))
    /* (hsm_blk_rp > hsm_blk_wp - HSM_BLK_NUM) does *NOT* work, why ? */
    hsm_reg[id]->cntreg = reg | HSM_CNT_DAQ;
  /* Force to clear pending-interrupt to cope with BUGGY behavior of HSM */
  hsm_reg[id]->intreq |= HSM_INT_CLRP;
  udelay(2);
  hsm_reg[id]->intreq &=~HSM_INT_CLRP;
  /* Wake up waiting process */
  if (hsm_wakeups) wake_up_interruptible(&hsm_wait_q);
  return;
}

static int     hsm_intr   (int irq, int iackrc) {
  /* Since an acknowledge cycle is issued before calling this handler, 
     the interrupt source of HSM, which is ROAK (Release On AcKnowledgement)
     module, must have been cleared and the variable 'iackrc' should contain 
     the STATUS/ID vector of HSM, which can be tested as well as irq... */
  /* In addition, since cable interrupts, including ones from VME bus, are 
     inhibited during DMA transfer, it should *never* be the case that 
     DMA transfer is in progress when this handler is called...  */
  int  id, i;
  for (id = 0; id < HSM_NUM; id++) {
    if (irq != hsm_irq[id]) continue;
    /* Wait for FERA-bus idle, though ~30 usec must have passed since OVFL */
    for (i = 0; i < 10; i++)
      {if (hsm_reg[id]->cntreg & HSM_FPS_IDLE) break; udelay(10);}
    hsm_buf_xfer(id);
    return 1;
  }
  return 0;
}

static int     hsm_ioctl  (struct inode *inode, struct file *file,
				unsigned int cmd, unsigned long arg) {
  int      id = hsm_curr_id;
  unsigned long  flags;
  switch (cmd) {
  case	HSM_DAQ_INIT:		/* initialize whole system */
    for (id = 0; id < HSM_NUM; id++) {
      hsm_reg[id] = (struct hsm_regstr *)
	vmehb_dev_mmap(HSM_REG_MINOR, HSM_REG_BASE(hsm_mem_base[id]),
		       sizeof(struct hsm_regstr));
      hsm_buf[id] = (unsigned short *)
	vmehb_dev_mmap(HSM_BUF_MINOR, HSM_BUF_BASE(hsm_mem_base[id]),
		       HSM_MEM_SIZE);
      if (!(hsm_reg[id]->cntreg & HSM_FPS_16BT))
	printk(DEVICE ":   HSM #%d is 32-bit mode.\n", id);
      hsm_reg[id]->intreq  = 0;
      hsm_reg[id]->cntreg  = 0;
      hsm_blk_wp[id] = hsm_blk_rp[id] = 0;	/* for confirmation */
    }
    SCL_VAR_MMAP;
    hsm_finish = 0;
    return 0;
  case	HSM_DAQ_FINISH:		/* finish whole system */
    for (id = 0; id < HSM_NUM; id++)
      hsm_reg[id]->cntreg &=~HSM_CNT_DAQ;	/* for confirmation */
    hsm_finish = -1;			/* inform "recorder" to finish */
    if (hsm_wakeups) wake_up_interruptible(&hsm_wait_q);
    schedule_timeout(HZ/10); /* wait 100 msec for possibly activated DMA done*/
    for (id = 0; id < HSM_NUM; id++) {
      vmehb_dev_unmap(HSM_REG_MINOR, HSM_REG_BASE(hsm_mem_base[id]),
		      sizeof(struct hsm_regstr));
      vmehb_dev_unmap(HSM_BUF_MINOR, HSM_BUF_BASE(hsm_mem_base[id]),
		      HSM_MEM_SIZE);
    }
    SCL_VAR_UNMAP;
    return 0;
  case	HSM_DAQ_START:		/* start data acquisition */
    save_flags(flags);
    cli();
    for (id = 0; id < HSM_NUM; id++) {
      hsm_blk_rp[id] = hsm_blk_wp[id] = 0;
      hsm_reg[id]->adrptr  = HSM_BLK_SIZE * (hsm_blk_wp[id] % HSM_BLK_NUM)
                           + HSM_HDR_LEN;
      hsm_reg[id]->wrdcnt  = HSM_BLK_SIZE - HSM_HDR_LEN;
      hsm_reg[id]->intreq  = HSM_INT_IRQL(hsm_irq[id]);
      hsm_reg[id]->cntreg &=~HSM_CNT_STOP;	/* just to make sure */
      hsm_reg[id]->cntreg |= HSM_CNT_OLIM | HSM_CNT_MOVR;
      hsm_reg[id]->cntreg |= HSM_CNT_DAQ;
    }
    SCL_RESET; /* reset scaler */
    hsm_daq_on = 1;
    restore_flags(flags);
    return 0;
  case	HSM_DAQ_STOP:		/* stop data acquisition */
    hsm_daq_on = 0;
  case	HSM_DAQ_XFER: {		/* force buffer transfer */
    int  ans = 0;
    save_flags(flags);
    cli();
    for (id = 0; id < HSM_NUM; id++) {
      if ((hsm_reg[id]->adrptr % HSM_BLK_SIZE) != HSM_HDR_LEN)
	{ hsm_buf_xfer(id); ans++; }
      if (!hsm_daq_on) {
	hsm_reg[id]->cntreg &= ~HSM_CNT_DAQ;
	hsm_reg[id]->intreq  = 0;
      }
    }
    restore_flags(flags);
    return ans;		/* notify if buffer is waiting to be xfered */
  }
  case	HSM_DAQ_WAITBUF:	/* wait for data ready & return blk pointer */
    waitbuf0:
    for (id = 0; id < HSM_NUM; id++) {
      if (hsm_blk_wp[id] > hsm_blk_rp[id]) {
	/* return correspoinding address of VME memory */
	unsigned int p = hsm_mem_base[id] +
	  (hsm_blk_rp[id] % HSM_BLK_NUM) * HSM_BLK_SIZE * sizeof(short);
	copy_to_user((char *)arg, (char *)&p, sizeof(int));
	hsm_curr_id = id;
	return hsm_finish; }
    }
    hsm_wakeups++;
    interruptible_sleep_on(&hsm_wait_q);
    if (hsm_wakeups) hsm_wakeups--;
    if (signal_pending(current)) return -ERESTARTNOINTR; /* wakeup by signal*/
    if ((hsm_curr_id < 0) || (hsm_finish < 0)) return hsm_finish;
    goto waitbuf0;
  case	HSM_DAQ_GETSCL:		/* get scaler data, assuming subsequent call */
    copy_to_user((char *)arg,
		 (char *)scl_buf[id][hsm_blk_rp[id] % HSM_BLK_NUM],
		 sizeof(int) * SCL_NUM_DATA);
    return 0;
  case	HSM_DAQ_WASREAD:	/* notify/acknowledge xfer & record done. */
    save_flags(flags);
    cli();
    if (hsm_daq_on && (hsm_blk_wp[id] - HSM_BLK_NUM >= hsm_blk_rp[id]))
      hsm_reg[id]->cntreg |= HSM_CNT_DAQ;	/* enable DAQ if necessary */
    restore_flags(flags);
    if (id >= 0) hsm_blk_rp[id]++; hsm_curr_id = 0;
    return 0;
  case	HSM_DAQ_WRCMT:		/* issued from commander to notify recorder */
    hsm_curr_id = -1;	/* id = -1 indicates comment block */
    save_flags(flags);
    cli();
    /* wake up waiting process */
    if (hsm_wakeups) wake_up_interruptible(&hsm_wait_q);
    restore_flags(flags);
    return 0;
  case HSM_DAQ_USERST:
    printk(DEVICE ": MOD_IN_USE = %d\n", MOD_IN_USE);
    while (MOD_IN_USE) MOD_DEC_USE_COUNT;
    MOD_INC_USE_COUNT;
  }
  return -1;
}

static struct file_operations hsm_fops = {
# if   defined(LINUX_2_4)
  THIS_MODULE /* module owner */,
# endif
  NULL	/* hsm_lseek -- just let the kernel to take care of the pointer */,
  vmehb_read,
  vmehb_write,
  NULL	/* hsm_readdir     */,
  NULL	/* hsm_poll/select */,
  hsm_ioctl,
  NULL	/* hsm_mmap        */,
  hsm_open,
# if   defined(LINUX_2_2)
  NULL	/* hsm_flush       */,
# endif
  hsm_release
};	/* if not defined, replace to NULL. */

int init_module(void) {
  int  i;
  printk(DEVICE ": %s controller for DAQ system 'mars'.\n", HARDWARE);
  printk(DEVICE ":   This is a subsidiary driver running under vmehb-2.2.x\n");
  request_module("vmehb");
  if (register_chrdev(HSM_NO, DEVICE, &hsm_fops)) {
    printk(DEVICE ": error -- cannot register to major device %d !\n", HSM_NO);
    return -ENODEV;
  }
  for (i = 0; i < HSM_NUM; i++) {
    printk(DEVICE ":   HSM #%1d  IRQ=%1d  MEM_BASE=0x%8.8x\n",
	   i, hsm_irq[i], hsm_mem_base[i]);
    /* just leave intr. vector to be zero, letting no-check. */
    request_vme_irq(hsm_irq[i], 0, hsm_intr, hsm_dev_id); /* always 0 returns*/
  }
  printk(DEVICE ":   Driver has been successfully installed.\n");
  return 0;
}
void cleanup_module(void) {
  int  i;
  for (i = 0; i < HSM_NUM; i++) free_vme_irq(hsm_irq[i], 0, hsm_intr);
  unregister_chrdev(HSM_NO, DEVICE);
  printk(DEVICE ": %s controller for DAQ system 'mars'.\n", HARDWARE);
  printk(DEVICE ":   Driver has been removed.\n");
}

#ifndef HSM_IOCTL_H
#define HSM_IOCTL_H

/* see 'linux/Documentation/ioctl-number.txt' 
   for available MAGIC nubmer */
#define HSM_IOC             'h'

#define HSM_DAQ_INIT        _IO  (HSM_IOC, 31      )
#define HSM_DAQ_FINISH      _IO  (HSM_IOC, 33      )
#define HSM_DAQ_START       _IO  (HSM_IOC, 35      )
#define HSM_DAQ_STOP        _IOW (HSM_IOC, 37, long)
#define HSM_DAQ_XFER        _IOW (HSM_IOC, 39, long)
#define HSM_DAQ_WAITBUF     _IOR (HSM_IOC, 41, int )
#define HSM_DAQ_GETSCL      _IOR (HSM_IOC, 43, long)
#define HSM_DAQ_WASREAD     _IO  (HSM_IOC, 45      )
#define HSM_DAQ_WRCMT       _IOW (HSM_IOC, 47, int )
#define HSM_DAQ_USERST      _IO  (HSM_IOC, 71      )

#endif /* HSM_IOCTL_H */

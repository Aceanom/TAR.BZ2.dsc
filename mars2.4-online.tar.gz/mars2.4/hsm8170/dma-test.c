#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <unistd.h>
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <sys/time.h>
#include "hsm_conf.h"

int main(int argc, char *argv[])
{
  int      fd, id, i, j;
  unsigned int   hsm_mem_base[] = HSM_MEM_BASE;
  unsigned short buf1[HSM_BLK_SIZE], buf2[HSM_BLK_SIZE];
  int      hsm_irq[] = HSM_IRQ;
  struct timeval t1,t2;
  double   dt;

  if ((fd = open(DEVICE, O_RDWR)) == -1)
    {puts("! VME/HSM device open error."); exit(2);}

  srand(1048577);

  for (id = 0; id < HSM_NUM; id++) {

    printf("\n=== DMA test of HSM #%d  [mem_base = 0x%8.8X, IRQ = %d] ===\n\n",
	   id, hsm_mem_base[id], hsm_irq[id]);

    for (j = 0; j < 4; j++) {

      for (i = 0; i < HSM_BLK_SIZE; i++) buf1[i] = rand() & 0xFFFF;

      lseek(fd, (off_t)hsm_mem_base[id], SEEK_SET);
      gettimeofday(&t1, NULL);
      printf("written%6d bytes", write(fd, buf1, HSM_BLK_SIZE*sizeof(short)));
      gettimeofday(&t2, NULL);
      dt = (t2.tv_sec -t1.tv_sec )*1000.0 + (t2.tv_usec-t1.tv_usec)/1000.0;
      printf(" (%6.3f msec =>%6.2f MB/sec)\n",
	     dt, HSM_BLK_SIZE*sizeof(short)/dt/1048.576);
      for (i = 0; i < 32; i++) printf(" %4.4X", buf1[i]); puts("");

      lseek(fd, (off_t)hsm_mem_base[id], SEEK_SET);
      gettimeofday(&t1, NULL);
      printf("read   %6d bytes", read (fd, buf2, HSM_BLK_SIZE*sizeof(short)));
      gettimeofday(&t2, NULL);
      dt = (t2.tv_sec -t1.tv_sec )*1000.0 + (t2.tv_usec-t1.tv_usec)/1000.0;
      printf(" (%6.3f msec =>%6.2f MB/sec)\n",
	     dt, HSM_BLK_SIZE*sizeof(short)/dt/1048.576);
      for (i = 0; i < 32; i++) printf(" %4.4X", buf2[i]); puts("");

      for (i = 0; i < HSM_BLK_SIZE; i += 32) {
	if (memcmp(&(buf1[i]), &(buf2[i]), 32*sizeof(short))) {
	  int k;
	  printf("error in buf[0x%4.4x]:\n", i);
	  for (k = 0; k < 32; k++) printf(" %4.4X", buf2[i++]); puts("\n");
	  goto next;
	}
      }
      puts("memcmp=0: data have been written & read w/o error.\n");

    next:
    }
  }

  close(fd);
  exit(0);
}

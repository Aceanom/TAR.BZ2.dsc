#include <fcntl.h>
#include <unistd.h>
#include <sys/ioctl.h>
#include "hsm_ioctl.h"

int main()
{
  int fd = open("dev/hsm", O_RDWR);
  ioctl(fd, HSM_DAQ_USERST, 0);
  close(fd);
  exit(0);
}

#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <sys/mman.h>
#include "k2917_reg.h"

#define MAX_RETRY   5
#define RETRY_WAIT  5L

int main(int argc, char *argv[])
{
  int      fd, C, N, A, F, data=0, i;
  unsigned short *mem, CSR;

  if (argc < 5) {printf("Usage: %s c n a f [data]\n", argv[0]); return 4;}
  if ((C = atoi(argv[1])) < 0 || C >  7 ||
      (N = atoi(argv[2])) < 1 ||(N > 24 && N != 30)||
      (A = atoi(argv[3])) < 0 || A > 15 ||
      (F = atoi(argv[4])) < 0 || F > 31) return 4;
  if (argc > 5) data = atoi(argv[5]);

  if ((fd = open("/dev/vme16d16", O_RDWR)) == -1) {perror("fd"); return 4;}
  if ((int)(mem = (unsigned short *)
            mmap(0, K2917_SIZE, PROT_READ | PROT_WRITE,
                 MAP_SHARED, fd, (off_t)K2917_BASE)) == -1)
    {perror("map"); return 4;}

  mem[K2917_CSR] &= ~K2917_CSR_GO;
  mem[K2917_CMA]  = 0;
  mem[K2917_CMR]  = (C<<8) + K2917_CMR_WS24 + K2917_CMR_QSTP;
  mem[K2917_CMR]  = (N<<9) + (A<<5) + F;
  mem[K2917_CMR]  = K2917_CMR_HALT;
  mem[K2917_CMA]  = 0;
  CSR = mem[K2917_CSR];
  switch (F & 0x18) {
  case 0x00: /* Read */
    CSR &= ~K2917_CSR_DIR; /* set Direction CAMAC => VME */
    mem[K2917_CSR]  = CSR | K2917_CSR_GO;
    for (i = 0; i < MAX_RETRY; i++) {
      CSR = mem[K2917_CSR];
      if (CSR & K2917_CSR_RDY) break;
      if (CSR & K2917_CSR_ERR) goto Error;
      usleep(RETRY_WAIT);
    } if (i == MAX_RETRY) goto Error;
    data = mem[K2917_DHR] & 0x00ff;
    data = mem[K2917_DLR] + (data<<16);
    mem[K2917_CSR] &= ~K2917_CSR_GO; /* <= This is required ! */
    for (i = 0; i < MAX_RETRY; i++) {
      if (mem[K2917_CSR] & K2917_CSR_DONE) break;
      usleep(RETRY_WAIT);
    } if (i == MAX_RETRY) goto Error;
    printf("%d\n", data);
    break;
  case 0x10: /* Write */
    CSR |=  K2917_CSR_DIR; /* set Direction VME => CAMAC */
    mem[K2917_CSR]  = CSR | K2917_CSR_GO;
    for (i = 0; i < MAX_RETRY; i++) {
      if (mem[K2917_CSR] & K2917_CSR_RDY) break;
      usleep(RETRY_WAIT);
    } if (i == MAX_RETRY) goto Error;
    mem[K2917_DHR]  = (unsigned short)(data >> 16);
    mem[K2917_DLR]  = (unsigned short)(data & 0x0ffff);
    mem[K2917_CSR] &= ~K2917_CSR_GO; /* <= This is required ! */
    for (i = 0; i < MAX_RETRY; i++) {
      CSR = mem[K2917_CSR];
      if (CSR & K2917_CSR_DONE) break;
      if (CSR & K2917_CSR_ERR) goto Error;
      usleep(RETRY_WAIT);
    } if (i == MAX_RETRY) goto Error;
    break;
  default:   /* Others */
    mem[K2917_CSR]  = CSR | K2917_CSR_GO;
    mem[K2917_CSR] &= ~K2917_CSR_GO;
    for (i = 0; i < MAX_RETRY; i++) {
      CSR = mem[K2917_CSR];
      if (CSR & K2917_CSR_DONE) break;
      if (CSR & K2917_CSR_ERR ) goto Error;
      usleep(RETRY_WAIT);
    } if (i == MAX_RETRY) goto Error;
    break;
  }

  munmap(0, K2917_SIZE);
  close(fd);
  data = 0;
  if (CSR & K2917_CSR_NOX) data += 1;
  if (CSR & K2917_CSR_NOQ) data += 2;
  return data;

 Error:
  munmap(0, K2917_SIZE);
  close(fd);
  fprintf(stderr, "CSR=0x%4.4X, i=%d (MAX_RETRY=%d)\n", CSR, i, MAX_RETRY);
  return 4;
}

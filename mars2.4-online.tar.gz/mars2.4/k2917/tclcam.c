/*
 * "libtclcam.so"
 *
 *  Tcl library for Kinetic 2917-3922
 *
 *  creates a tcl command : camac
 *
 *  its subcommands and return values:
 *
 *    crate   c        ; 0=online, -1=offline
 *    read    n a f v  ; Q X  (v must be variable name)
 *    write   n a f d  ; Q X
 *    naf     n a f    ; Q X
 *    lam              ; LAM pattern string (index 0 => n 1)
 *    Z
 *    initialize
 *    C
 *    clear
 *    I       i        ; i = 0 or 1
 *    inhibit i
 *
 *  N.B. compile with -O0 to access mmapped registers properly.  
 */

#include <fcntl.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <sys/mman.h>
#include <unistd.h>
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <tcl.h>
#include "k2917_reg.h"
#include "k3922_reg.h"

static int   fd=0, crate;
static char  result[32];
static char  QX[4][4]={"", "Q", "X", "Q X"};
static unsigned short *mem, CSR;
#define MAX_RETRY   5
#define RETRY_WAIT  5L

#define checkargc(narg,msg) \
if(argc!=narg){Tcl_SetResult(interp,msg,TCL_STATIC);return TCL_ERROR;}
#define checknaf(f1,f2) \
if ((N = atoi(argv[2])) <= 0 || N > 24 ||\
    (A = atoi(argv[3])) <  0 || A > 15 ||\
    (F = atoi(argv[4])) < f1 || F > f2) {\
   Tcl_SetResult(interp,"Error: invalid (n,a,f)",TCL_STATIC);\
   return TCL_ERROR;}
#define SetCommandList(N,A,F) \
     mem[K2917_CSR] &= ~K2917_CSR_GO;\
     mem[K2917_CMA]  = 0;\
     mem[K2917_CMR]  = (crate<<8) + K2917_CMR_WS24 + K2917_CMR_QSTP;\
     mem[K2917_CMR]  = (N<<9) + (A<<5) + F;\
     mem[K2917_CMR]  = K2917_CMR_HALT;\
     mem[K2917_CMA]  = 0
#define ReadOp(data) \
     mem[K2917_CSR] = (mem[K2917_CSR] & ~K2917_CSR_DIR) | K2917_CSR_GO;\
     for (i = 0; i < MAX_RETRY; i++) {\
       CSR = mem[K2917_CSR];\
       if (CSR & K2917_CSR_RDY) break;\
       if (CSR & K2917_CSR_ERR) goto Error;\
       usleep(RETRY_WAIT);\
     } if (i == MAX_RETRY) goto Error;\
     data = mem[K2917_DHR] & 0x00ff;\
     data = mem[K2917_DLR] + (data<<16);\
     mem[K2917_CSR] &= ~K2917_CSR_GO;\
     for (i = 0; i < MAX_RETRY; i++) {\
       CSR = mem[K2917_CSR];\
       if (CSR & K2917_CSR_DONE) break;\
       usleep(RETRY_WAIT);\
     } if (i == MAX_RETRY) goto Error
#define WriteOp(data) \
     mem[K2917_CSR] |= (K2917_CSR_DIR | K2917_CSR_GO);\
     for (i = 0; i < MAX_RETRY; i++) {\
       if (mem[K2917_CSR] & K2917_CSR_RDY) break;\
       usleep(RETRY_WAIT);\
     } if (i == MAX_RETRY) goto Error;\
     mem[K2917_DHR]  = (unsigned short)(data >> 16);\
     mem[K2917_DLR]  = (unsigned short)(data & 0x0ffff);\
     mem[K2917_CSR] &= ~K2917_CSR_GO;\
     for (i = 0; i < MAX_RETRY; i++) {\
       CSR = mem[K2917_CSR];\
       if (CSR & K2917_CSR_DONE) break;\
       if (CSR & K2917_CSR_ERR) goto Error;\
       usleep(RETRY_WAIT);\
     } if (i == MAX_RETRY) goto Error
#define CntlOp \
     mem[K2917_CSR] |=  K2917_CSR_GO;\
     mem[K2917_CSR] &= ~K2917_CSR_GO;\
     for (i = 0; i < MAX_RETRY; i++) {\
       CSR = mem[K2917_CSR];\
       if (CSR & K2917_CSR_DONE) break;\
       if (CSR & K2917_CSR_ERR ) goto Error;\
       usleep(RETRY_WAIT);\
     } if (i == MAX_RETRY) goto Error
#define chkQX ((((CSR&K2917_CSR_NOX)==0)<<1)+((CSR&K2917_CSR_NOQ)==0))

int tclcamCmd _ANSI_ARGS_(( ClientData clientData, 
			   Tcl_Interp *interp, 
			   int argc, char *argv[] )) 
{
  int   N, A, F, data, i;
  if (!fd) {
    if ((fd = open("/dev/vme16d16", O_RDWR)) == -1)
      {Tcl_SetResult(interp, "Error: VME open error", TCL_STATIC);
       return TCL_ERROR;}
    if ((int)(mem = (unsigned short *)
	      mmap(0, K2917_SIZE, PROT_READ | PROT_WRITE,
		   MAP_SHARED, fd, (off_t)K2917_BASE)) == -1)
      {Tcl_SetResult(interp, "Error: VME mmap error", TCL_STATIC);
       return TCL_ERROR;}
  }

  if (*argv[1] == 'c' && !strcmp(argv[1], "crate")) {
    checkargc(3,"Error: crate number must be given.");
    if ((crate = atoi(argv[2])) < 0 || crate > 7) {
      Tcl_SetResult(interp, "Error: invalid crate#", TCL_STATIC);
      return TCL_ERROR;}
    SetCommandList(K3922_N,K3922_STAT_A,K3922_READ_F); ReadOp(data);
    if (data & K3922_STAT_OFL) {
      Tcl_SetResult(interp, "Error: crate off-line.", TCL_STATIC);
      return TCL_ERROR;
    } return TCL_OK;
  }

  if (*argv[1] == 'r' && !strcmp(argv[1], "read")) {
    checkargc(6,"Error: n a f var must be given.");
    checknaf(0,7);
    SetCommandList(N,A,F); ReadOp(data);
    sprintf(result, "%d", data);
    if (Tcl_SetVar(interp, argv[5], (char *)result, TCL_LEAVE_ERR_MSG)
	== NULL) return TCL_ERROR;
    Tcl_SetResult(interp, (char *)QX[chkQX], TCL_STATIC);
    return TCL_OK;
  }

  if (*argv[1] == 'w' && !strcmp(argv[1], "write")) {
    checkargc(6,"Error: n a f data must be given.");
    checknaf(16,23);
    data = atoi(argv[5]);
    SetCommandList(N,A,F); WriteOp(data);
    Tcl_SetResult(interp, (char *)QX[chkQX], TCL_STATIC);
    return TCL_OK;
  }

  if (*argv[1] == 'n' && !strcmp(argv[1], "naf")) {
    checkargc(5,"Error: n a f must be given.");
    checknaf(0,31);
    SetCommandList(N,A,F); CntlOp;
    Tcl_SetResult(interp, (char *)QX[chkQX], TCL_STATIC);
    return TCL_OK;
  }

  if (*argv[1] == 'l' && !strcmp(argv[1], "lam")) {
    checkargc(2,"Error: extra argument.");
    SetCommandList(K3922_N,K3922_LAMP_A,K3922_READ_F); ReadOp(data);
    for (i = 0; i < 24; i++,data>>=1)
      if (data & 1) result[i] = '1'; else result[i] = '0';
    result[24] = 0;
    Tcl_SetResult(interp, (char *)result, TCL_STATIC);
    return TCL_OK;
  }

  if ((*argv[1] == 'Z' && !strcmp(argv[1], "Z"))||
      (*argv[1] == 'i' && !strcmp(argv[1], "initialize"))) {
    checkargc(2,"Error: extra argument.");
    SetCommandList(K3922_N,K3922_STAT_A,K3922_READ_F); ReadOp(data);
    data = (data & K3922_STAT_I) + K3922_STAT_Z;
    SetCommandList(K3922_N,K3922_STAT_A,K3922_WRIT_F); WriteOp(data);
    return TCL_OK;
  }

  if ((*argv[1] == 'C' && !strcmp(argv[1], "C"))||
      (*argv[1] == 'c' && !strcmp(argv[1], "clear"))) {
    checkargc(2,"Error: extra argument.");
    SetCommandList(K3922_N,K3922_STAT_A,K3922_READ_F); ReadOp(data);
    data = (data & K3922_STAT_I) + K3922_STAT_C;
    SetCommandList(K3922_N,K3922_STAT_A,K3922_WRIT_F); WriteOp(data);
    return TCL_OK;
  }

  if ((*argv[1] == 'I' && !strcmp(argv[1], "I"))||
      (*argv[1] == 'i' && !strcmp(argv[1], "inhibit"))) {
    checkargc(3,"Error: 1 (=ON) or 0 (=OFF) must be given");
    if (atoi(argv[2])) data = K3922_STAT_I; else data = 0;
    SetCommandList(K3922_N,K3922_STAT_A,K3922_WRIT_F); WriteOp(data);
    return TCL_OK;
  }

  Tcl_SetResult(interp, "Error: subcommand missing", TCL_STATIC);
  return TCL_ERROR;

 Error:
  Tcl_SetResult(interp, "Error: CAMAC operation error", TCL_STATIC);
  return TCL_ERROR;
}

int Tclcam_Init ( Tcl_Interp *interp )
{
  Tcl_CreateCommand(interp, "camac", (Tcl_CmdProc *)tclcamCmd,
                    (ClientData) NULL, (Tcl_CmdDeleteProc *)NULL );
  Tcl_SetVar(interp, "MAX_CRATE", "7", TCL_GLOBAL_ONLY);
  return TCL_OK;
}

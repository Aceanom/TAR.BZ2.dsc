/*
    recorder -- DAQ raw-data recorder
*/

#include <sys/types.h>
#include <sys/ipc.h>
#include <sys/shm.h>
#include <sys/sem.h>
#include <fcntl.h>
#include <stdlib.h>
#include <unistd.h>
#include <stdio.h>
#include <string.h>

#include "crashm.h"

static int     shmid;
static CRASHM *shmp;
static int     semid;
static struct
       sembuf  semops[1];

static int     fd;

#define MAX_EVL 2048
int main()
{
  unsigned short event[MAX_EVL];
  if ((shmid = shmget(SHMKEY, sizeof(CRASHM), IPC_CREAT|0600)) == -1)
    {puts("# Cannot create shared memory"); exit(2);}
  if ((semid = semget(SEMKEY, 1             , IPC_CREAT|0600)) == -1)
    {puts("# Cannot create semaphore"); exit(2);}
  shmp = (CRASHM *)shmat(shmid, 0, 0);
  fd = open(DEVICE, O_RDONLY);
  while (read(fd, &event, sizeof(short)) >= 0) {
    if (event[0] == 0xffff) {
      /* EOF encountered */
      if (shmp->rawdat) {close(shmp->rawdat); shmp->rawdat = 0;}
    } else {
      /* ordinary raw data */
      event[0] = sizeof(short) +
	read(fd, &(event[1]),
	     ((event[0]<2*MAX_EVL)?event[0]:2*MAX_EVL)-sizeof(short));
      if (shmp->path[0]) { /* file is assigned but not opened */
	unsigned short len;
	shmp->rawdat = open(shmp->path, O_WRONLY|O_CREAT, 0644);
	shmp->path[0] = 0;
	len = strlen(shmp->comment) + 3;
	write(shmp->rawdat, &len, sizeof(short));
	write(shmp->rawdat, shmp->comment, len-2);
      }
      if (shmp->rawdat) write(shmp->rawdat, &event, (int)event[0]);
      shmp->rwcnt++;
      if ((shmp->wp - shmp->rp + (event[0]>>1)) < MAX_BUF) {
	int i;                           /* copy data for on-line analyzer */
	for (i = 0; i < (event[0]>>1); i++)
	  shmp->buff[(shmp->wp++)%MAX_BUF] = event[i];
	if (semctl(semid, 0, GETNCNT, 0)) {        /* notify data is ready */
	  semops[0].sem_num =  0;
	  semops[0].sem_op  =  1;
	  semops[0].sem_flg =  IPC_NOWAIT;
	  semop(semid, semops, 1);
	}
      }
    }
  }
  close(fd);
  shmdt((char *)shmp);
  shmctl(shmid, IPC_RMID, 0);
  semctl(semid, 0, IPC_RMID, 0);
  exit(0);
}

#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <unistd.h>
#include <stdlib.h>
#include <sys/ioctl.h>
#include <stdio.h>
#include "dc.h"
#include "dc_aux.h"

int main(int argc, char *argv[])
{
  int     fd, crate;
  DCCycle dcc;
  if (argc < 5) {printf("Usage: %s c n a f [data]\n", argv[0]); exit(4);}
  if ((crate = atoi(argv[1])) < 0 || crate >=  MAX_CRATE ||
      (dcc.n = atoi(argv[2])) < 1 || dcc.n > 24 ||
      (dcc.a = atoi(argv[3])) < 0 || dcc.a > 15 ||
      (dcc.f = atoi(argv[4])) < 0 || dcc.f > 31) exit(4);
  if (argc > 5) dcc.data = atoi(argv[5]);
  if ((fd = open("/dev/dc", O_RDWR)) == -1) exit(4);
  if (ioctl(fd, DC_INITIAL, crate)) {close(fd); exit(4);}
  ioctl(fd, DC_CYCLE, &dcc);
  close(fd);
  if ((dcc.f & 0x18) == 0x00) printf("%ld\n", dcc.data);
  exit(dcc.stat);
}

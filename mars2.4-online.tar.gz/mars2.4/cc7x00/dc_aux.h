/*                                                          */
/*          ... ... ... <<< dc_aux.h >>> ... ... ...        */
/*                                                          */
/*                  Secondary Header file of                */
/*                                                          */
/*                      A device driver                     */
/*          for Toyo CC/7x00 CAMAC crate controller         */
/*                on Linux 2.0 & 2.2 kernels                */
/*                                                          */
/*             containing auxiliary definitions             */
/*      to cope with difference among cc/7x00 families.     */

#ifndef DC_AUX_H
#define DC_AUX_H

#ifndef DC_H
#include "dc.h"
#endif /* DC_H */

#if   defined(CC7000)
#  define MAX_CRATE  4
#elif defined(CC7700ISA)||defined(CC7700PCI)
#  define MAX_CRATE  8
#endif

#ifdef __KERNEL__

/*
 *
 *  Global parameters/variables
 *
 */
#if   defined(CC7000)
#  define IO_REGION  8
#  define DC_CSR     PNO+6
#  define DC_IN_CSR  inw(DC_CSR)
#  define DC_OUT_CSR(x) outw(x,DC_CSR)
#  define DC_B_LINT  0x8000
#  define DC_B_LSUM  0x4000
#  define DC_B_ONL   0x2000
#  define DC_B_DONE  0x1000
#  define DC_B_EI    0x0800
#  define DC_B_I     0x0400
#  define DC_B_Z     0x0200
#  define DC_B_C     0x0100
#  define DC_B_NOX   0x0200
#  define DC_B_NOQ   0x0100
#elif defined(CC7700ISA)
#  define IO_REGION  12
#  define DC_CSR     PNO+0
#  define DC_IN_CSR  inw(DC_CSR)
#  define DC_OUT_CSR(x) outw(x,DC_CSR)
#  define DC_B_LINT  0x0080
#  define DC_B_LSUM  0x0040
#  define DC_B_ONL   0x0020
#  define DC_B_DONE  0x0010
#  define DC_B_EI    0x0008
#  define DC_B_I     0x0004
#  define DC_B_Z     0x0002
#  define DC_B_C     0x0001
#  define DC_B_NOX   0x0002
#  define DC_B_NOQ   0x0001
#elif defined(CC7700PCI)
#  undef  IRQ
#  undef  PNO
   static char           IRQ;
   static unsigned short PNO;
#  define IO_REGION  16
#  define DC_CSR     PNO+0
#  define DC_IN_CSR  inl(DC_CSR)
#  define DC_OUT_CSR(x) outl(x,DC_CSR)
#  define DC_B_LINT  0x00000080
#  define DC_B_LSUM  0x00000040
#  define DC_B_ONL   0x00000020
#  define DC_B_DONE  0x00000010
#  define DC_B_EI    0x00000008
#  define DC_B_I     0x00000004
#  define DC_B_Z     0x00000002
#  define DC_B_C     0x00000001
#  define DC_B_NOX   0x00000002
#  define DC_B_NOQ   0x00000001
#endif
#  define DC_B_MASK (DC_B_LINT|DC_B_EI|DC_B_I)

/*
 *
 *  Macro's to be used in ioctl and inline functions
 *
 */

/* test CAMAC operation done */
#  define DC_AUX_DONE ((DC_IN_CSR&DC_B_DONE)!=0)

/* read LAM pattern */
#if   defined(CC7000)
#  define DC_AUX_LAMP(lampat) {\
	* (unsigned short *)(&lampat)    =inw(PNO+4);\
	*((unsigned short *)(&lampat)+1) =inw(PNO+6)&0x00ff;}
#elif defined(CC7700ISA)
#  define DC_AUX_LAMP(lampat) {\
	* (unsigned short *)(&lampat)    =inw(PNO+2);\
	*((unsigned short *)(&lampat)+1) =inw(PNO+4)&0x00ff;}
#elif defined(CC7700PCI)
#  define DC_AUX_LAMP(lampat)  (long)lampat=inl(PNO+4)&0x00ffffff
#endif

/* set CRATE address */
#if   defined(CC7000)
#  define DC_AUX_CRATE(arg)  outb(arg   ,PNO+1)
#elif defined(CC7700ISA)
#  define DC_AUX_CRATE(arg)  outw(arg   ,PNO+2)
#elif defined(CC7700PCI)
   static long dc_aux_crate;
#  define DC_AUX_CRATE(arg)  outl((dc_aux_crate=arg<<16),PNO+4)
#endif

/* check if online */
#  define DC_AUX_ONL   ((DC_IN_CSR&DC_B_ONL)!=0)

/* enable interrupt */
#  define DC_AUX_ENAI  DC_OUT_CSR((DC_IN_CSR&DC_B_MASK)| DC_B_EI)

/* disable interrupt */
#  define DC_AUX_DISI  DC_OUT_CSR((DC_IN_CSR&DC_B_MASK)&~DC_B_EI)

/* Z (initialize) to CAMAC bus */
#  define DC_AUX_Z     DC_OUT_CSR((DC_IN_CSR&DC_B_MASK)|DC_B_Z)

/* C (clear) to CAMAC bus */
#  define DC_AUX_C     DC_OUT_CSR((DC_IN_CSR&DC_B_MASK)|DC_B_C)

/* I (inhibit) to CAMAC bus */
#  define DC_AUX_I(arg)  {\
	if(arg!=0) DC_OUT_CSR((DC_IN_CSR&DC_B_MASK)| DC_B_I);\
	else       DC_OUT_CSR((DC_IN_CSR&DC_B_MASK)&~DC_B_I);}

/* LINT (internal LAM) */
#  define DC_AUX_LINT(arg)  {\
	if(arg!=0) DC_OUT_CSR((DC_IN_CSR&DC_B_MASK)| DC_B_LINT);\
	else       DC_OUT_CSR((DC_IN_CSR&DC_B_MASK)&~DC_B_LINT);}

/* set NAF (char arg) */
#if   defined(CC7000)
#  define DC_AUX_NAF(n,a,f)   {\
	outw((short)n|((unsigned short)a<<8),PNO+4);\
	outw((DC_IN_CSR&DC_B_MASK)|(unsigned short)f,PNO+6);}
#elif defined(CC7700ISA)
#  define DC_AUX_NAF(n,a,f)   \
	outw(((unsigned short)(n-1)<<9)|((short)a<<5)|(short)f,PNO+4)
#elif defined(CC7700PCI)
#  define DC_AUX_NAF(n,a,f)   \
	outl(dc_aux_crate|((long)(n-1)<<9)|((long)a<<5)|(long)f,PNO+4)
#endif

/* set NAF (int arg) */
#if   defined(CC7000)
#  define DC_AUX_NAF2(n,a,f)   {\
	outw((unsigned short)(n|(a<<8)),PNO+4);\
	outw((DC_IN_CSR&DC_B_MASK)|(unsigned short)f,PNO+6);}
#elif defined(CC7700ISA)
#  define DC_AUX_NAF2(n,a,f)   \
	outw(((unsigned short)((n-1)<<9)|(a<<5)|f),PNO+4)
#elif defined(CC7700PCI)
#  define DC_AUX_NAF2(n,a,f)   \
	outl(dc_aux_crate|(long)(((n-1)<<9)|(a<<5)|f),PNO+4)
#endif

/* 24-bit write (val arg) */
#if   defined(CC7000)
#  define DC_AUX_WRITE(x)  {\
	outw(*((unsigned short *)(&x)  ),PNO+0);\
	outw(*((unsigned short *)(&x)+1),PNO+2);}
#elif defined(CC7700ISA)
#  define DC_AUX_WRITE(x)  {\
	outw(*((unsigned short *)(&x)  ),PNO+6);\
	outw(*((unsigned short *)(&x)+1),PNO+8);}
#elif defined(CC7700PCI)
#  define DC_AUX_WRITE(x)  outl(x,PNO+8)
#endif

/* 24-bit read (val arg) */
#if   defined(CC7000)
#  define DC_AUX_READ(x)  {\
	*((unsigned short *)(&x)  )=inw(PNO+0);\
	*((unsigned short *)(&x)+1)=inw(PNO+2)&0x00ff;}
#elif defined(CC7700ISA)
#  define DC_AUX_READ(x)  {\
	*((unsigned short *)(&x)  )=inw(PNO+6);\
	*((unsigned short *)(&x)+1)=inw(PNO+8)&0x00ff;}
#elif defined(CC7700PCI)
#  define DC_AUX_READ(x)  x=inl(PNO+8)&0x00ffffff
#endif

/* 24-bit write (pointer arg) */
#if   defined(CC7000)
#  define DC_AUX_WRITE24(x)  {\
	outw(*((unsigned short *)(x)  ),PNO+0);\
	outw(*((unsigned short *)(x)+1),PNO+2);}
#elif defined(CC7700ISA)
#  define DC_AUX_WRITE24(x)  {\
	outw(*((unsigned short *)(x)  ),PNO+6);\
	outw(*((unsigned short *)(x)+1),PNO+8);}
#elif defined(CC7700PCI)
#  define DC_AUX_WRITE24(x)  outl(*x,PNO+8)
#endif

/* 24-bit read (pointer arg) */
#if   defined(CC7000)
#  define DC_AUX_READ24(x)  {\
	*((unsigned short *)(x)  )=inw(PNO+0);\
	*((unsigned short *)(x)+1)=inw(PNO+2)&0x00ff;}
#elif defined(CC7700ISA)
#  define DC_AUX_READ24(x)  {\
	*((unsigned short *)(x)  )=inw(PNO+6);\
	*((unsigned short *)(x)+1)=inw(PNO+8)&0x00ff;}
#elif defined(CC7700PCI)
#  define DC_AUX_READ24(x)  *x=inl(PNO+8)&0x00ffffff
#endif

/* 16-bit write (pointer arg) */
#if   defined(CC7000)
#  define DC_AUX_WRITE16(x)  \
	outw(*((unsigned short *)(x)  ),PNO+0)
#elif defined(CC7700ISA)
#  define DC_AUX_WRITE16(x)  \
	outw(*((unsigned short *)(x)  ),PNO+6)
#elif defined(CC7700PCI)
#  define DC_AUX_WRITE16(x)  \
	outw(*((unsigned short *)(x)  ),PNO+8)
#endif

/* 16-bit read (pointer arg) */
#if   defined(CC7000)
#  define DC_AUX_READ16(x)  \
	*((unsigned short *)(x)  )=inw(PNO+0)
#elif defined(CC7700ISA)
#  define DC_AUX_READ16(x)  \
	*((unsigned short *)(x)  )=inw(PNO+6)
#elif defined(CC7700PCI)
#  define DC_AUX_READ16(x)  \
	*((unsigned short *)(x)  )=inw(PNO+8)
#endif

/* GO (execute CAMAC cycle) */
#if   defined(CC7000)
#  define DC_AUX_GO    outb(0,PNO+7)
#elif defined(CC7700ISA)
#  define DC_AUX_GO    outw(0,PNO+10)
#elif defined(CC7700PCI)
#  define DC_AUX_GO    outl(0,PNO+12)
#endif

/* NO-Q */
#  define DC_AUX_NOQ(x)   ((x&DC_B_NOQ)!=0)

/* NO-X */
#  define DC_AUX_NOX(x)   ((x&DC_B_NOX)!=0)

/* status (NO-X, NO-Q) */
#if   defined(CC7000)
#  define DC_AUX_STAT(x)  ((x&(DC_B_NOX|DC_B_NOQ))>>8)
#elif defined(CC7700ISA)||defined(CC7700PCI)
#  define DC_AUX_STAT(x)  ( x&(DC_B_NOX|DC_B_NOQ)    )
#endif

/*
 *
 *  A common function to wait for CAMAC operation done
 *
 */

int inline dc_cycle_wait( int stimes ) {
  register int i;
  for(i=0;i<stimes;i++) if(DC_AUX_DONE) return 0;
  return -1;
}

/*
 *
 *  in-line functions to be used in interrupt-handler
 *
 */

int inline camacCinitialize () {
# if   defined(CC7000)
  outb(0,PNO+1);
# elif defined(CC7700ISA)
  outw(0,PNO+2);
# elif defined(CC7700PCI)
  outl((dc_aux_crate=0),PNO+4);
# endif
  DC_OUT_CSR(0);
  if(DC_AUX_ONL) return 0; else return -1;
}

int inline camacCz () {
  DC_AUX_Z;
  return dc_cycle_wait(255);
}

int inline camacCc () {
  DC_AUX_C;
  return dc_cycle_wait(255);
}

int inline camacCi (int onoff ) {
  DC_AUX_I(onoff);
  return 0;
}

long inline camacClamp (){
  long lampat;
  DC_AUX_LAMP(lampat);
  return(lampat);
}

int inline camacClam (){
  int i, lampat;
  DC_AUX_LAMP(lampat);
  for(i=0;i<24;i++) if((lampat/(1<<i))%2) goto lamhit;
 lamhit: if(i<24) i++; else i=0;
  return(i);
}

/* long word data NAF operation */
int inline camacCcycle(int N, int A, int F, long *data, int *stat) {
  register int i; int status;
  DC_AUX_NAF2(N,A,F);
  if((F&0x18)==0x10) DC_AUX_WRITE24(data);
  DC_AUX_GO;
  for(i=0;i<256;i++)
    if(((status=DC_IN_CSR)&DC_B_DONE)!=0) goto done_sense;
  return -1;
 done_sense:
  *stat=DC_AUX_STAT(status);
  if((F&0x18)==0x00) DC_AUX_READ24(data);
  return 0;
}

#define camacCcycle24(n,a,f,d,s) camacCcycle(n,a,f,d,s)

/* short word data NAF operation */
int inline camacCcycle2(int N, int A, int F, short *data, int *stat) {
  register int i; int status;
  DC_AUX_NAF2(N,A,F);
  if((F&0x18)==0x10) DC_AUX_WRITE16(data);
  DC_AUX_GO;
  for(i=0;i<256;i++)
    if(((status=DC_IN_CSR)&DC_B_DONE)!=0) goto done_sense;
  return -1;
done_sense:
  *stat=DC_AUX_STAT(status);
  if((F&0x18)==0x00) DC_AUX_READ16(data);
  return 0;
}

#define camacCcycle16(n,a,f,d,s) camacCcycle2(n,a,f,d,s)

/* block read of long word data with Q-stop */
int inline camacCblkrd(int N, int A, int F, long *data, int size) {
  register int i; int j, status;
  DC_AUX_NAF2(N,A,F);
  for(j=0;j<size;j++) {
    DC_AUX_GO;
    for(i=0;i<256;i++)
      if(((status=DC_IN_CSR)&DC_B_DONE)!=0) goto done_sense;
    return -1;
  done_sense:
    if(DC_AUX_NOQ(status)) return j; else DC_AUX_READ24(&(data[j]));
  }
  return j;
}

#define camacCblkrd24(n,a,f,d,s) camacCblkrd(n,a,f,d,s)

/* block read of short word data with Q-stop */
int inline camacCblkrd2(int N, int A, int F, short *data, int size) {
  register int i; int j, status;
  DC_AUX_NAF2(N,A,F);
  for(j=0;j<size;j++) {
    DC_AUX_GO;
    for(i=0;i<256;i++)
      if(((status=DC_IN_CSR)&DC_B_DONE)!=0) goto done_sense;
    return -1;
  done_sense:
    if(DC_AUX_NOQ(status)) return j; else DC_AUX_READ16(&(data[j]));
  }
  return j;
}

#define camacCblkrd16(n,a,f,d,s) camacCblkrd2(n,a,f,d,s)

/* Ad hoc trap for buggy CC/7000 AT-IF ...
 --- it seems interrupt is generated before data and LAM become available. */
#if   defined(CC7000)
#  define DC_AUX_TSTL   if(camacClamp()==0) return
#elif defined(CC7700ISA)||defined(CC7700PCI)
#  define DC_AUX_TSTL
#endif

/*
 *
 * PCI configuration function used for CC/7700 PCI
 *
 */
#if defined(CC7700PCI)
#define DC_VENDOR_ID 1
#define DC_DEVICE_ID 0xcc77
#include <linux/pci.h>
#if   defined(LINUX_2_2)
   static int dc_pci_config() {
     struct pci_dev *pdev=NULL; int pno;
     if(!pci_present())
       {printk(DEVICE ": PCI bios does not exist.\n"); return -1;}
     if((pdev=pci_find_device(DC_VENDOR_ID,DC_DEVICE_ID,pdev))==NULL)
       {printk(DEVICE ": PCI board for %s not found.\n",HARDWARE); return -1;}
     pci_read_config_byte (pdev,PCI_INTERRUPT_LINE,&IRQ);
     pci_read_config_dword(pdev,PCI_BASE_ADDRESS_0,&pno);
     PNO=(pno&=0xfffc);
     pci_write_config_dword(pdev,PCI_BASE_ADDRESS_0,pno);
     return 0;
   }
#elif defined(LINUX_2_0)
#  include <linux/bios32.h>
   static int dc_pci_config() {
     unsigned char bus, fnc; int pno;
     if(!pcibios_present())
       {printk(DEVICE ": PCI bios does not exist.\n"); return -1;}
     if(pcibios_find_device(DC_VENDOR_ID,DC_DEVICE_ID,0,&bus,&fnc))
       {printk(DEVICE ": PCI board for %s not found.\n",HARDWARE);
       return -1;}
     pcibios_read_config_byte (bus,fnc,PCI_INTERRUPT_LINE,&IRQ);
     pcibios_read_config_dword(bus,fnc,PCI_BASE_ADDRESS_0,&pno);
     PNO=(pno&=0xfffc);
     pcibios_write_config_dword(bus,fnc,PCI_BASE_ADDRESS_0,pno);
     return 0;
   }
#endif /* LINUX_2_X */
#endif /* CC7700PCI */


#endif /* __KERNEL__ */

#endif /* DC_AUX_H */

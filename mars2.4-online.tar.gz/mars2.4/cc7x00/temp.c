#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <unistd.h>
#include <stdlib.h>
#include <sys/ioctl.h>
#include <stdio.h>
#include "dc.h"

int main(int argc, char *argv[])
{
  int     fd, i, n;
  long    intr,lost;
  char    s[20];
  unsigned short buf[256];
  fd = open("/dev/dc", O_RDWR);
  printf("ioctl(INTCLR)=%d\n",ioctl(fd, DC_INTCLR, 0));
  printf("ioctl(INTON )=%d\n",ioctl(fd, DC_INTON , 0));
  fgets(s,20,stdin);
  printf("ioctl(INTOFF)=%d\n",ioctl(fd, DC_INTOFF, 0));
  printf("ioctl(INTCNT)=%d\n",ioctl(fd, DC_INTCNT, &intr));
  printf("int=%ld\n",intr);
  printf("ioctl(INTLOS)=%d\n",ioctl(fd, DC_INTCNT, &lost));
  printf("los=%ld\n",lost);
  printf("read=%d\n",(n=read(fd,buf,256*sizeof(short))));
  for (i=0;i<(n/sizeof(short));i++) printf(" %4.4X",buf[i]); puts("");
  close(fd);
  exit(0);
}

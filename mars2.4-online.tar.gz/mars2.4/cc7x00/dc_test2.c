/*                                                          */
/*         ... ... ... <<< dc_test.c >>> ... ... ...        */
/*                                                          */
/*              A sample interrupt handler of               */
/*                                                          */
/*                      A device driver                     */
/*          for Toyo CC/7x00 CAMAC crate controller         */
/*                on Linux 2.0 & 2.2 kernels                */
/*                                                          */

/* station number of modules */
#define ADC1      5
#define OUTREG    4
/* information of LAM source */
#define LAM_N     ADC1
#define LAM_A     0
/* some parameters */
#define MAX_EVLEN 1024

#ifdef OUTREG
static unsigned short  dc_outreg=0x0000;
#endif

/*
 *
 *  Auxiliary function called at enabling interrupt
 *
 */
static void dc_int_on() {
  int stat;
# if (defined(LAM_N) && defined(LAM_A))
  camacCcycle2(LAM_N,LAM_A,26,NULL,&stat);
# endif
# if defined(OUTREG)
  dc_outreg |= 0xff00; /* set   higher 8-bit */
  camacCcycle2(OUTREG,0,16,&dc_outreg,&stat);
# endif
}

/*
 *
 *  Auxiliary function called at disabling interrupt
 *
 */
static void dc_int_off() {
  int stat;
# if defined(OUTREG)
  dc_outreg &= 0x00ff; /* clear higher 8-bit */
  camacCcycle2(OUTREG,0,16,&dc_outreg,&stat);
# endif
# if (defined(LAM_N) && defined(LAM_A))
  camacCcycle2(LAM_N,LAM_A,24,NULL,&stat);
# endif
}

/*
 *
 *  Main function of interrupt handler
 *
 */
static void  dc_int(int irq, void *dev_id, struct pt_regs *regs) {
  int wp0,stat,i;
  if(dev_id!=dc_dev_id) return; /* interrupt from other devices sharing IRQ */
# ifdef CC7000
  if(camacClamp()==0) goto abort;
  //for(i=0;i<256;i++) if(camacClamp()) break; /* buggy CC7000 AT-IF ! */
# endif
  dc_int_count++;
  if ((dc_wp-dc_rp) > EV_MAX-MAX_EVLEN) {
    /* buffer is full */
    dc_int_lost++;
  } else {
    /* Data AcQuisition --- users should modify the following */
    wp0=dc_wp++;                  /* save current pointer for event-length */
#   if defined(OUTREG)
    dc_outreg |= 0x00ff; /*  set  lower 8-bit */
    camacCcycle2(OUTREG,0,16,&dc_outreg ,&stat);
#   endif
    //#   define SINGLE_ACTION
    //#   define BLOCK_READ12
#   define BLOCK_READ2
#   if   defined(BLOCK_READ2)
    camacCblkrd2(ADC1,0,0,&dc_evbuff[(dc_wp++)%EV_MAX], 2);
#   elif defined(BLOCK_READ12)
    camacCblkrd2(ADC1,0,0,&dc_evbuff[(dc_wp++)%EV_MAX],12);
#   elif defined(SINGLE_ACTION)
    for (i=0;i<12;i++)
      camacCcycle2(ADC1,i,0,&dc_evbuff[(dc_wp++)%EV_MAX],&stat);
#   endif
    /*
    for (i=0;i<33;i++) {
      camacCcycle2(TDC1,0,0,&dc_evbuff[dc_wp%EV_MAX],&stat);
      if (stat & 1 || dc_evbuff[dc_wp%EV_MAX] == 0) break; dc_wp++;}
    for (i=0;i<33;i++) {
      camacCcycle2(TDC2,0,0,&dc_evbuff[(dc_wp)%EV_MAX],&stat);
      if (stat & 1 || dc_evbuff[dc_wp%EV_MAX] == 0) break; dc_wp++;}
    */
    dc_evbuff[(dc_wp++)%EV_MAX]=DELIM;               /* store delimiter    */
    dc_evbuff[wp0%EV_MAX]=(short)((dc_wp-wp0)<<1);   /* store event length */
  }
  camacCcycle2(ADC1,0,9,0,&stat);                    /* clear module */
  /*
  camacCcycle2(TDC1,1,26,0,&stat);
  camacCcycle2(TDC2,1,26,0,&stat);
  */
  //# if defined(OUTREG)
  //  dc_outreg |= 0x00ff; /*  set  lower 8-bit */
  //  camacCcycle2(OUTREG,0,16,&dc_outreg ,&stat);
  //  dc_outreg &= 0xff00; /* clear lower 8-bit */
  //  camacCcycle2(OUTREG,0,16,&dc_outreg ,&stat);
  //# endif
# if defined(OUTREG)
  dc_outreg &= 0xff00; /* clear lower 8-bit */
  camacCcycle2(OUTREG,0,16,&dc_outreg ,&stat);
# endif
 abort:
  if ((dc_wp!=dc_rp) && (wakeups!=0)) wake_up(&wait_que);
}

#ifndef K2915_REG_H
#define K2915_REG_H

/* IOCTL */
#define CCIOC_WAIT_LAM            1
#define CCIOC_RESET               2
#define CCIOC_SET_CRATE           5
#define CCIOC_ENABLE_LAM          6
#define CCIOC_DISABLE_LAM         7
#define CCIOC_REG_DUMP            8
#define CCIOC_SINGLE              9
#define CCIOC_SETUP_DMA          10
#define CCIOC_CMD_STAT           11
#define CCIOC_PPOLL              12
#define CCIOC_ENABLE_INT         13
#define CCIOC_DISABLE_INT        14
#define CCIOC_WAKE_LAM           15

/* Transfer Mode */
#define WSIZE16          0x00002000  /* Word Size 16bit */
#define WSIZE24          0x00000000  /* Word Size 24bit */
#define SINGLE           0x00000000  /* Single Transfer Mode */
#define QSTOP            0x00000002  /* Q-Stop Block Transfer Mode */
#define QIGNORE          0x00000004  /* Q-Ignore Block Transfer Mode */
#define QREPEAT          0x00000006  /* Q-Repeat Block Transfer Mode */
#define QSCAN            0x00000008  /* Q-Scan Block Transfer Mode */
#define PPOLL            0x0000000A  /* Parallel Poll Mode */

#define NAFGEN(n,a,f)   ( 0x3fff & (n<<9 | a <<5 | f) )

#define NOQ              0x00010000
#define NOX              0x00020000

struct naf_data {
  short mode;
  short naf;
  unsigned int data;
  unsigned int xq;
};

#endif /* K2915_REG_H */

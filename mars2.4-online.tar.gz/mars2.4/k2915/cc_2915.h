#ifndef CC_2915_H
#define CC_2915_H

/*
 * Filename  : cc_2915.h for PCI/K2915
 * Version   : 2.01
 * Date      : 11-Jun-1997
 * Modified  : 01-Aug-1997
 * Author    : M.Haseno, Y.Tanaka
 * Modified  : Y.Nagasaka
 *             Nagasaki Institute of Applied Science (NIAS)
 * Date      : 3-Mar-1998
 * Modified  : C.Timmer, Jefferson Lab
 * Data      : 8-Sep-1998
 * Modified  : H.Okamura, Saitama University
 */

#define PCI_VENDOR_ID_KINETIC      0x11f4  /* PCI Vendor ID */
#define PCI_DEVICE_ID_KINETIC_2915 0x2915  /* PCI Device ID */

#define PBOR_SIZE                16  /* Size of the PBOR(Byte) */
#define IOR_SIZE                 64  /* Size of the IOR(Byte) */

#define CSR         ( 0x00 )  /* Control/Status Register (CSR & MCR) */
#define CNAF        ( 0x04 )  /* CAMAC Crate/Command Register */
#define TCR         ( 0x08 )  /* Transfer Count Register */
#define SRR         ( 0x0C )  /* Service Request Register (K2927-CCR)*/

#define FIFO        ( 0x20 )  /* Data FIFO Register */
#define MWA         ( 0x24 )  /* Master Write Address Register */
#define MWTC        ( 0x28 )  /* Master Write Transfer Count Register */
#define MRA         ( 0x2C )  /* Master Read Address Register */
#define MRTC        ( 0x30 )  /* Master Read Transfer Count Register */
#define ICS         ( 0x38 )  /* Interrupt Control/Status Register */ 
#define BMCS        ( 0x3C )  /* Bus Master Control/Status Register */

/* IOCTL */
#define CCIOC_WAIT_LAM            1
#define CCIOC_RESET               2
#define CCIOC_SET_CRATE           5
#define CCIOC_ENABLE_LAM          6
#define CCIOC_DISABLE_LAM         7
#define CCIOC_REG_DUMP            8
#define CCIOC_SINGLE              9
#define CCIOC_SETUP_DMA          10
#define CCIOC_CMD_STAT           11
#define CCIOC_PPOLL              12
#define CCIOC_ENABLE_INT         13
#define CCIOC_DISABLE_INT        14
#define CCIOC_WAKE_LAM           15

/* Control/Status Register (CSR) */
#define RST_INFC         0x10000000
#define NOQ              0x00010000
#define NOX              0x00020000
#define XQ_MASK          0x00030000
#define CSR_MASK         0x0000354E

#define CLR_DNI          0x00000010
#define CLR_PCII         0x00000020
#define DONE_IENA        0x00000040
#define DONE             0x00000080
#define RFS_IENA         0x00000100
#define RFS              0x00000200
#define PCI_IENA         0x00000400
#define PCI_IRQ          0x00000800

#define GO               0x00000001
#define ERR              0x80000000  /* Error */
#define WSIZE16          0x00002000  /* Word Size 16bit */
#define WSIZE24          0x00000000  /* Word Size 24bit */     
#define WORD_MASK        0x0000154E  /* Word Size Mask */
#define RFS_MASK         0x0000304E  /* RFS and PCI IENA Mask */
#define NAF_TIMEOUT      0x00080000  /* NAF transfer timeout */
#define PBUS_TIMEOUT     0x00040000  /* Parallel bus timeout */

#define SINGLE           0x00000000  /* Single Transfer Mode */
#define QSTOP            0x00000002  /* Q-Stop Block Transfer Mode */
#define QIGNORE          0x00000004  /* Q-Ignore Block Transfer Mode */
#define QREPEAT          0x00000006  /* Q-Repeat Block Transfer Mode */
#define QSCAN            0x00000008  /* Q-Scan Block Transfer Mode */
#define PPOLL            0x0000000A  /* Parallel Poll Mode */
#define TRANSFER_MASK    0x0000000E  /* Transfer Mode Mask*/
#define ABT_DIS          0x00001000  /* Abort Disable */

/* CAMAC Crate/Command Register (CNAF) */
#define CRATE_MASK       0x000F0000  /* CrateNumber Mask for CNAF */
#define NAFGEN(n,a,f) ( 0x3fff & (n<<9 | a <<5 | f) )
/* CNAF related constants */
#define CC_NAFRK_F08     0x00000008  /* F = 8 */
#define CC_NAFRK_F16     0x00000010  /* F = 16 */
#define CC_MAX_CRATE              8

/* Bus Master Control/Status Register (BMCS) */
#define FIFO_RESET       0x06000000  /* Reset Data FIFO Register */
#define ADDON_RESET      0x01000000  /* Addon Reset Register */
#define IN_FIFO_EMPTY    0x00000020  /* Inbound  FIFO Empty */
#define IN_FIFO_FULL     0x00000008  /* Inbound  FIFO Empty */
#define OUT_FIFO_EMPTY   0x00000004  /* Outbound FIFO Full */
#define OUT_FIFO_FULL    0x00000001  /* Outbound FIFO Full */
#define IN_FIFO_P4       0x00000010  /* Inbound  FIFO +4 */
#define OUT_FIFO_P4      0x00000002  /* Outbound FIFO +4 */
#define WTT_ENA          0x00000400  /* DMA Write Transfer Enable */
#define RDT_ENA          0x00004000  /* DMA Read Transfer Enable */

/* Latency Timer Register(LTR) */
#define LTR_SET          0xF8

/* Driver LOOP Timer Parameters */
#define MAX_FIFO_TRY             50 /* Max try times FIFO ready */
#define MAX_DONE_TRY            100 /* Max try times DONE ready */

#define DMA_TIMEOUT             500 /* units = jiffies = 10 msec */

#endif /* CC_2915_H */

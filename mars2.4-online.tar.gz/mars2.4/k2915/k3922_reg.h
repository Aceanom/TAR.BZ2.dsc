#ifndef K3922_REG_H
#define K3922_REG_H

#define K3922_N        30
#define K3922_STAT_A    0
#define K3922_LAMP_A   12
#define K3922_LAMM_A   13
#define K3922_READ_F    1
#define K3922_WRIT_F   17

#define K3922_STAT_Z   (1<< 0)
#define K3922_STAT_C   (1<< 1)
#define K3922_STAT_I   (1<< 2)
#define K3922_STAT_SRQ (1<< 8)
#define K3922_STAT_L24 (1<< 9)
#define K3922_STAT_OFL (1<<13)

#endif /* K3922_REG_H */

/*
 * "libtclcam.so"
 *
 *  Tcl library for Kinetic 2915-3922
 *
 *  creates a tcl command : camac
 *
 *  its subcommands and return values:
 *
 *    crate   c        ; 0=online, -1=offline
 *    read    n a f v  ; Q X  (v must be variable name)
 *    write   n a f d  ; Q X
 *    naf     n a f    ; Q X
 *    lam              ; LAM pattern string (index 0 => n 1)
 *    Z
 *    initialize
 *    C
 *    clear
 *    I       i        ; i = 0 or 1
 *    inhibit i
 *
 */

#include <fcntl.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <sys/ioctl.h>
#include <unistd.h>
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <tcl.h>
#include "k2915_reg.h"
#include "k3922_reg.h"

static int    fd=0;
static char   result[32];
static char   QX[4][4]={"", "X", "Q", "Q X"};
static struct naf_data cc;
static int    crate;

#define checkargc(narg,msg) \
if(argc!=narg){Tcl_SetResult(interp,msg,TCL_STATIC);return TCL_ERROR;}
#define checknaf(f1,f2) \
if ((N = atoi(argv[2])) <= 0 || N > 24 ||\
    (A = atoi(argv[3])) <  0 || A > 15 ||\
    (F = atoi(argv[4])) < f1 || F > f2) {\
   Tcl_SetResult(interp,"Error: invalid (n,a,f)",TCL_STATIC);\
   return TCL_ERROR;}
#define chkQX ((((cc.xq&NOQ)==0)<<1)+((cc.xq&NOX)==0))

int tclcamCmd _ANSI_ARGS_(( ClientData clientData, 
			   Tcl_Interp *interp, 
			   int argc, char *argv[] ))
{
  int   N, A, F;
  if (!fd) {
    if ((fd = open("/dev/cc0", O_RDWR)) == -1)
      {Tcl_SetResult(interp, "Error: device open error", TCL_STATIC);
       return TCL_ERROR;}
  }

  if (*argv[1] == 'c' && !strcmp(argv[1], "crate")) {
    checkargc(3,"Error: crate number must be given.");
    if ((crate = atoi(argv[2])) < 0 || crate > 7) {
      Tcl_SetResult(interp, "Error: invalid crate#", TCL_STATIC);
      return TCL_ERROR;}
    ioctl(fd, CCIOC_SET_CRATE, crate);
    cc.mode = SINGLE | WSIZE24;
    cc.naf  = NAFGEN(K3922_N,K3922_STAT_A,K3922_READ_F);
    ioctl(fd, CCIOC_SINGLE, &cc);
    if (cc.data & K3922_STAT_OFL) {
      Tcl_SetResult(interp, "Error: crate off-line.", TCL_STATIC);
      return TCL_ERROR;
    } return TCL_OK;
  }

  if (*argv[1] == 'r' && !strcmp(argv[1], "read")) {
    checkargc(6,"Error: n a f var must be given.");
    checknaf(0,7);
    ioctl(fd, CCIOC_SET_CRATE, crate);
    cc.mode = SINGLE | WSIZE24;
    cc.naf  = NAFGEN(N,A,F);
    ioctl(fd, CCIOC_SINGLE, &cc);
    sprintf(result, "%d", cc.data);
    if (Tcl_SetVar(interp, argv[5], (char *)result, TCL_LEAVE_ERR_MSG)
	== NULL) return TCL_ERROR;
    Tcl_SetResult(interp, (char *)QX[chkQX], TCL_STATIC);
    return TCL_OK;
  }

  if (*argv[1] == 'w' && !strcmp(argv[1], "write")) {
    checkargc(6,"Error: n a f data must be given.");
    checknaf(16,23);
    ioctl(fd, CCIOC_SET_CRATE, crate);
    cc.mode = SINGLE | WSIZE24;
    cc.naf  = NAFGEN(N,A,F);
    cc.data = atoi(argv[5]);
    ioctl(fd, CCIOC_SINGLE, &cc);
    Tcl_SetResult(interp, (char *)QX[chkQX], TCL_STATIC);
    return TCL_OK;
  }

  if (*argv[1] == 'n' && !strcmp(argv[1], "naf")) {
    checkargc(5,"Error: n a f must be given.");
    checknaf(0,31);
    ioctl(fd, CCIOC_SET_CRATE, crate);
    cc.mode = SINGLE | WSIZE24;
    cc.naf  = NAFGEN(N,A,F);
    ioctl(fd, CCIOC_SINGLE, &cc);
    Tcl_SetResult(interp, (char *)QX[chkQX], TCL_STATIC);
    return TCL_OK;
  }

  if (*argv[1] == 'l' && !strcmp(argv[1], "lam")) {
    int i;
    checkargc(2,"Error: extra argument.");
    ioctl(fd, CCIOC_SET_CRATE, crate);
    cc.mode = SINGLE | WSIZE24;
    cc.naf  = NAFGEN(K3922_N,K3922_LAMP_A,K3922_READ_F);
    ioctl(fd, CCIOC_SINGLE, &cc);
    for (i = 0; i < 24; i++,(cc.data>>=1))
      if (cc.data & 1) result[i] = '1'; else result[i] = '0';
    result[24] = 0;
    Tcl_SetResult(interp, (char *)result, TCL_STATIC);
    return TCL_OK;
  }

  if ((*argv[1] == 'Z' && !strcmp(argv[1], "Z"))||
      (*argv[1] == 'i' && !strcmp(argv[1], "initialize"))) {
    checkargc(2,"Error: extra argument.");
    ioctl(fd, CCIOC_SET_CRATE, crate);
    cc.mode = SINGLE | WSIZE24;
    cc.naf  = NAFGEN(K3922_N,K3922_STAT_A,K3922_READ_F);
    ioctl(fd, CCIOC_SINGLE, &cc);
    cc.data = (cc.data & K3922_STAT_I) + K3922_STAT_Z;
    cc.naf  = NAFGEN(K3922_N,K3922_STAT_A,K3922_WRIT_F);
    ioctl(fd, CCIOC_SINGLE, &cc);
    return TCL_OK;
  }

  if ((*argv[1] == 'C' && !strcmp(argv[1], "C"))||
      (*argv[1] == 'c' && !strcmp(argv[1], "clear"))) {
    checkargc(2,"Error: extra argument.");
    ioctl(fd, CCIOC_SET_CRATE, crate);
    cc.mode = SINGLE | WSIZE24;
    cc.naf  = NAFGEN(K3922_N,K3922_STAT_A,K3922_READ_F);
    ioctl(fd, CCIOC_SINGLE, &cc);
    cc.data = (cc.data & K3922_STAT_I) + K3922_STAT_C;
    cc.naf  = NAFGEN(K3922_N,K3922_STAT_A,K3922_WRIT_F);
    ioctl(fd, CCIOC_SINGLE, &cc);
    return TCL_OK;
  }

  if ((*argv[1] == 'I' && !strcmp(argv[1], "I"))||
      (*argv[1] == 'i' && !strcmp(argv[1], "inhibit"))) {
    checkargc(3,"Error: 1 (=ON) or 0 (=OFF) must be given");
    ioctl(fd, CCIOC_SET_CRATE, crate);
    cc.mode = SINGLE | WSIZE24;
    cc.naf  = NAFGEN(K3922_N,K3922_STAT_A,K3922_WRIT_F);
    if (atoi(argv[2])) cc.data = K3922_STAT_I; else cc.data = 0;
    ioctl(fd, CCIOC_SINGLE, &cc);
    return TCL_OK;
  }

  Tcl_SetResult(interp, "Error: subcommand missing", TCL_STATIC);
  return TCL_ERROR;
}

int Tclcam_Init ( Tcl_Interp *interp )
{
  Tcl_CreateCommand(interp, "camac", (Tcl_CmdProc *)tclcamCmd,
                    (ClientData) NULL, (Tcl_CmdDeleteProc *)NULL );
  Tcl_SetVar(interp, "MAX_CRATE", "7", TCL_GLOBAL_ONLY);
  return TCL_OK;
}

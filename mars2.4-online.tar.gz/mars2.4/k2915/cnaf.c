#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <sys/ioctl.h>
#include "k2915_reg.h"

int main(int argc, char *argv[])
{
  int      fd, C, N, A, F, i;
  struct naf_data cc;

  if (argc < 5) {printf("Usage: %s c n a f [data]\n", argv[0]); return 4;}
  if ((C = atoi(argv[1])) < 0 || C >  7 ||
      (N = atoi(argv[2])) < 1 ||(N > 24 && N != 30)|| /* N=30 for C3922 */
      (A = atoi(argv[3])) < 0 || A > 15 ||
      (F = atoi(argv[4])) < 0 || F > 31) return 4;
  if (argc > 5) cc.data = atoi(argv[5]);
  if ((fd = open("/dev/cc0", O_RDWR)) == -1) {perror("fd"); return 4;}
  ioctl(fd, CCIOC_SET_CRATE, C);
  cc.mode = SINGLE | WSIZE24;
  cc.naf  = NAFGEN(N,A,F);
  ioctl(fd, CCIOC_SINGLE, &cc);
  close(fd);
  if ((F & 0x18) == 0) printf("%d\n", cc.data);
  i = 0;
  if (cc.xq & NOX) i += 1;
  if (cc.xq & NOQ) i += 2;
  return i;
}

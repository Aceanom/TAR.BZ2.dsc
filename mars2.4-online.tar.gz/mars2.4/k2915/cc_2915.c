/* cc_2915.c: KineticSystems Corporation 2915 PCI Card Driver */
/*
 *  filename: cc_2915.c
 *  version : 2.01
 *  date    : 11-Jun-1997
 *  modified: 11-Aug-1997
 *            11-Oct-1997  DMA bug fixed by Y.Tanaka
 *             5-Nov-1997  fixed Set Crate number problem by Y.Tanaka 
 *                         DMA mode QREPEAT
 *             7-Nov-1997  fixed DMA transfer size in byte by Y.Tanaka
 *             3-Mar-1998  features added, problems fixed by C.Timmer :
 *			   1) fixed wrong x & q return values
 *			   2) return x,q, AND error data for camac_single
 *			   3) fixed addressing a non-existing crate causing
 *			      error on next command to existing crate
 *			   4) DMA transfer extended to all modes (untested)
 *			   5) parallel poll capability added
 *			   6) access to status of last command added
 *			   7) dump of registers added
 *			   8) can share IRQ if necessary
 *			   9) separate the control of lam enable/disable
 *			      from pci lam interrupt enable/disable
 *			  10) set pci latency timer to recommended value
 *			  11) only look for one KS2915 card.
 *             8-Sep-1998  fixed many brain-dead coding by H.Okamura:
 *			   1) DMA buffer (cc_buf) is allocated by kmalloc 
 *			      & its size is made smaller accordingly.  
 *			   2) DMA done is processed by interrupt instead of 
 *			      polling of CSR.  
 *			   3) size of buffer transfered to cc_read/write is 
 *			      now in unit of byte instead of 16/24-bit word, 
 *			      also return value is transfered size in byte.  
 *			   4) meaning of arg for CCIOC_SETUP_DMA is changed 
 *			      so as to be consistent with CCIOC_SINGLE.  
 *			   5) {request,free}_irq in cc_{open,release} moved 
 *			      to {init,cleanup}_module to allow non-exclusive
 *			      device open from non-unique processes.  
 *			   6) cli()/save/restore_flags inserted in camac_single
 *			      to be exclusive operation.  
 *			   7) operations on C3922 are eliminated.  
 *			   8) higher 8 bits are masked for 24-bit operation.  
 *			   9) correct retval for ioctl.  
 *                        10) remove RFS_IENA setting in CCIOC_WAIT_LAM
 *                        11) remove branch related code
 *                        12) add CCIOC_WAKE_LAM
 *             3-Jan-2001  ported to kernel-2.2.x by H.Okamura:
 *             4-Aug-2008  ported to kernel-2.4.x by H.Okamura:
 *
 *  author  : M.Haseno, Y.Tanaka
 *  modified: Y.Nagasaka
 *            Nagasaki Institute of Applied Science (NIAS)
 *  modified: C.Timmer
 *            Thomas Jefferson National Accelerator Facility
 *  modified: H.Okamura
 *            Department of Physics, Saitama University ('98-'02)
 *            Cyclotron and Radioisotope Center, Tohoku University ('03-'05)
 *            Research Center for Nuclear Physics, Osaka University ('06-)
 *
 */
#include <linux/config.h>

#ifdef MODULE
#include <linux/module.h>
#else
#define MOD_INC_USE_COUNT
#define MOD_DEC_USE_COUNT
#endif

#include <linux/major.h>
#include <linux/ioport.h>
#include <linux/pci.h>
#include <asm/io.h>

#include <linux/version.h>
#if   LINUX_VERSION_CODE >= 0x020100
#  include <asm/uaccess.h>
#  define LINUX_2_2
#  define relse_t         int
#  define uint_t          unsigned int
#  define CC_MINOR        MINOR(file->f_dentry->d_inode->i_rdev)
#  if LINUX_VERSION_CODE >= 0x020300
#    define LINUX_2_4
     MODULE_LICENSE("GPL");
#  else
#    include <linux/malloc.h>
#  endif
#elif LINUX_VERSION_CODE >= 0x020000
#  include <linux/malloc.h>
#  include <linux/bios32.h>
#  include <asm/segment.h>
#  define LINUX_2_0
#  define relse_t         void
#  define CC_MINOR        MINOR(inode->i_rdev)
#  define copy_from_user  memcpy_fromfs
#  define copy_to_user    memcpy_tofs
#  define signal_pending(current)  (current->signal & ~current->blocked)
#else
#  error "This kernel is too old: not supported by this file"
#endif

#include "cc_2915.h"
#include "k3922_reg.h"

#define BUFFER_SIZE (32*1024-24)    /* DMA Buffer Size 32KBytes */
#ifdef DEBUG
  #define DEBUG2915 1
#else
  /* #define DEBUG2915 1 */
#endif

static char *cc_buf; /* buffer for DMA */
static char device[]="ks2915";

struct cc_struct {
  int base1;
  int base2;
  unsigned int irq;
  short cur_crate;
  int wait_LAM;
  int wait_DMA;
# ifdef LINUX_2_4
  wait_queue_head_t  wait_LAM_q;
  wait_queue_head_t  wait_DMA_q;
# else
  struct waut_queue *wait_LAM_q;
  struct waut_queue *wait_DMA_q;
# endif
};

static 
# ifdef LINUX_2_4
struct cc_struct cc_table[1];
# else
struct cc_struct cc_table[] =
{
  {0, 0, 0, 0, 0, 0, NULL, NULL}
};
# endif

struct  camac {
  /* Parallel Bus Operational Register */
  unsigned int csr;
  unsigned int cnaf;
  unsigned int tcr;
  unsigned int srr;
  /* PCI Interface Operational Register */
  unsigned int fifo;
  unsigned int mwa;
  unsigned int mwtc;
  unsigned int mra;
  unsigned int mrtc;
  unsigned int ics;
  unsigned int bmcs;  
};

struct camac reg[] =
{
  {CSR, CNAF, TCR, SRR, FIFO, MWA, MWTC, MRA, MRTC, ICS, BMCS,},
};

struct naf_data {
  short mode;
  short naf;
  unsigned int data;
  unsigned int xq;
};

static int cc_probe(struct cc_struct *cc_pci_hdr, struct camac *cc_reg);

static void
cc_interrupt (int irq, void *dev_id, struct pt_regs *regs)
{
  struct cc_struct *cc = cc_table;
  unsigned int csr;
  
  if (dev_id != device) {
    /* printk("cc_interrupt: wrong device, dev_id = %p\n", dev_id); */
    return;
  }
  
  if (irq != cc->irq) {
    /* printk("cc_interrupt: wrong irq (=%d)\n",irq); */
    return;
  }

  csr = inl(reg->csr);
  
  /*
   * Reject improper interrupts. These happen when sharing
   * IRQ with another device - hardware problems?
   */
  if (!( ((csr & RFS ) && (csr & RFS_IENA )) ||
	 ((csr & DONE) && (csr & DONE_IENA)) ))
    return;

  outl((unsigned int) 
       ((~RFS_IENA & ~DONE_IENA & csr & RFS_MASK) | CLR_DNI | CLR_PCII),
       reg->csr);

#ifdef DEBUG2915
  printk("cc_interrupt: csr=%#x\n", csr);
  printk("cc->wait_LAM=%d\n", cc->wait_LAM);
  printk("cc->wait_DMA=%d\n", cc->wait_DMA);
#endif

  if (cc->wait_LAM && (csr & RFS)) {
    wake_up_interruptible(&cc->wait_LAM_q);
    /* --cc->wait_LAM; */
    cc->wait_LAM = 0;
  }
 
  if (cc->wait_DMA && (csr & DONE)) {
    wake_up_interruptible(&cc->wait_DMA_q);
    /* --cc->wait_DMA; */
    cc->wait_DMA = 0;
  }
}

static int
camac_single (short mode, short naf, int *data)
{
  int  fifo_try=0, done_try=0;
  unsigned long  flags;

#ifdef DEBUG2915
  printk("camac_single: mode = %#x, naf = %#x, cnaf = %#x, data = %#x\n",
	 mode, naf, ((inl(reg->cnaf) & CRATE_MASK) | naf), *data);
#endif

  save_flags(flags);
  cli();

  outl((inl(reg->cnaf) & CRATE_MASK) | naf, reg->cnaf);

  if (mode & WSIZE16)
    outl( (unsigned int)WSIZE16 | (inl(reg->csr) & WORD_MASK), reg->csr);
  else
    outl( (unsigned int)WSIZE24 | (inl(reg->csr) & WORD_MASK), reg->csr);

  if ((CC_NAFRK_F16 & naf) && !(CC_NAFRK_F08 & naf)) {  /* Write Operation */
    for (; fifo_try < MAX_FIFO_TRY; fifo_try++)
      if(!(inl(reg->bmcs) & OUT_FIFO_FULL)) break;
    if (fifo_try == MAX_FIFO_TRY) {
#ifdef DEBUG2915
      printk("camac_single: Timeout, outbound FIFO full\n");
#endif
    } else {
      outl((unsigned int)(*data), reg->fifo);
      outl((unsigned int)(GO | (inl(reg->csr) & CSR_MASK)), reg->csr);
      for (; done_try < MAX_DONE_TRY; done_try++)
	if (inl(reg->csr) & DONE) break;
#ifdef DEBUG2915
      if (done_try == MAX_DONE_TRY)
	printk("camac_single: Timeout, Write waiting for DONE\n");
      printk("csr=0x%8.8x\n",inl(reg->csr));
#endif
    }
  }
  else
  if (!(CC_NAFRK_F16 & naf) && !(CC_NAFRK_F08 & naf)) { /* Read Operation */
    outl((unsigned int)(GO | (inl(reg->csr) & CSR_MASK)), reg->csr);
    for (; done_try < MAX_DONE_TRY; done_try++)
      if (inl(reg->csr) & DONE) break;
    if (done_try == MAX_DONE_TRY) {
#ifdef DEBUG2915
      printk("camac_single: Timeout, Read waiting for DONE\n");
#endif
    } else {
      for (; fifo_try < MAX_FIFO_TRY; fifo_try++)
	if(!(inl(reg->bmcs) & IN_FIFO_EMPTY)) break;
      if (fifo_try < MAX_FIFO_TRY)
	*data = inl(reg->fifo) & ((mode & WSIZE16) ? 0xffff : 0xffffff);
#ifdef DEBUG2915
      else
	printk("camac_single: Timeout, inbound FIFO empty\n");
#endif
    }
  }
  else { /* Operational Commands */
    outl((unsigned int)(GO | inl(reg->csr)), reg->csr);
    for (; done_try < MAX_DONE_TRY; done_try++)
      if (inl(reg->csr) & DONE) break;
#ifdef DEBUG2915
    if (done_try == MAX_DONE_TRY)
      printk("camac_single: Timeout, Operation waiting for DONE\n");
#endif
  }

  restore_flags(flags);

  return ((fifo_try == MAX_FIFO_TRY || done_try == MAX_DONE_TRY) ? -EIO : 0);
}

static int
cc_reset (void)
{
  int  done_try, retval;
  outl((unsigned int) RST_INFC                    , reg->csr);
  outl((unsigned int)(CLR_PCII   | inl(reg->csr)) , reg->csr);
  outl((unsigned int)(FIFO_RESET | inl(reg->bmcs)), reg->bmcs);

  for (done_try = 0; done_try < MAX_DONE_TRY; done_try++)
    if (inl(reg->csr) & DONE) break;
  if((retval = (done_try == MAX_DONE_TRY) ? -EIO : 0))
    printk("cc_reset: Timeout, waiting for DONE\n");

#ifdef DEBUG2915
  printk("cc_reset: Crate Reset Complete, csr=%#x bmcs=%#x\n",
	 inl(reg->csr),inl(reg->bmcs));
#endif

  return retval;
}

#if   defined(LINUX_2_2)
static ssize_t
cc_read(struct file *file, char *buffer, size_t sizeb, loff_t *fpos)
#elif defined(LINUX_2_0)
static int
cc_read(struct inode *inode, struct file *file, char *buffer, int sizeb)
#endif
{

  unsigned int minor = CC_MINOR;
  struct cc_struct *cc = &cc_table[minor];
  int count;

#ifdef DEBUG2915
  int i;
  printk ("cc_read: enter with size=%d\n", sizeb);
#endif

  if (sizeb > BUFFER_SIZE || cc_buf == NULL) return -EINVAL;

  count = (inl(reg->csr) & WSIZE16) ? sizeb>>1 : sizeb>>2;
  outl(~(count-1), reg->tcr);
  outl(virt_to_phys(cc_buf), reg->mwa);
  outl(sizeb, reg->mwtc);

#ifdef DEBUG2915
  printk("cc_read: cc_buf=%x,  mwa=%x \n",(unsigned int)cc_buf, inl(reg->mwa));
  printk("cc_read: tcr=%x,  mwtc=%x\n",(unsigned int)inl(reg->tcr),inl(reg->mwtc));
#endif

  /* clear ABORT MASTER bit */
  outl(0x100000, reg->ics);

  /* Reset in and outbound fifos & go */
  outl((unsigned int) (FIFO_RESET | inl(reg->bmcs)), reg->bmcs); 
  outl((unsigned int) (GO | inl(reg->csr)), reg->csr);

  cli();
  /* Enable DONE Interrupt */
  outl((unsigned int)(DONE_IENA | inl(reg->csr)), reg->csr);

  /* Enable DMA from 2915 to PCI mem */
  outl(WTT_ENA, reg->bmcs);

  /* wait for DONE interrupt */
# if   defined(LINUX_2_2)
  if (interruptible_sleep_on_timeout (&cc->wait_DMA_q, DMA_TIMEOUT) == 0) {
# elif defined(LINUX_2_0)
  current->timeout = jiffies + DMA_TIMEOUT;
  cc->wait_DMA++;
  interruptible_sleep_on (&cc->wait_DMA_q);

  if (current->timeout == 0) {
# endif
#ifdef DEBUG2915
    printk("cc_read: Timeout occurred\n");
#endif
    return -ETIMEDOUT;
  }

  /* Set Single mode */
  outl(0xFFF0 & inl(reg->csr), reg->csr);

#ifdef DEBUG2915
  printk("cc_read: csr=%x,  bmcs=%x\n", inl(reg->csr), inl(reg->bmcs));
  printk("  after DMA: cc_buf=%x,  mwa=%x \n",(unsigned int)cc_buf, inl(reg->mwa));
  printk("  after DMA: tcr=%x,  mwtc=%x\n",inl(reg->tcr),inl(reg->mwtc));
  printk("  after DMA: ics=%x\n", inl(reg->ics));
#endif

  outl( (unsigned int)(FIFO_RESET | (~WTT_ENA & inl(reg->bmcs))), reg->bmcs);
  if(inl(reg->csr) & ERR) return -EIO;

#ifdef DEBUG2915
  for(i=0;i<10;i++)  printk("cc_buf[%d] = %x\n", i, (char)cc_buf[i]);
#endif

  copy_to_user((void *)buffer, (void *)cc_buf, sizeb);
  return (sizeb - inl(reg->mwtc));
}

#if   defined(LINUX_2_2)
static ssize_t
cc_write(struct file *file, const char *buffer, size_t sizeb, loff_t *fpos)
#elif defined(LINUX_2_0)
static int
cc_write(struct inode *inode, struct file *file, const char *buffer, int sizeb)
#endif
{

  unsigned int minor = CC_MINOR;
  struct cc_struct *cc = &cc_table[minor];
  int count;
#ifdef DEBUG2915  
  printk ("cc_write: enter with size=%d\n", sizeb);
#endif

  if (sizeb > BUFFER_SIZE || cc_buf == NULL) return -EINVAL;

  /* Moved this line from end of routine to here. (timmer) */
  copy_from_user((void *)cc_buf, (void *)buffer, sizeb);

  /*
   * reg->tcr specifies max # of words to be transferred from
   * 2915 to the crate.
   * reg->mrtc specifies # bytes to be transferred from PCI bus
   * to 2915.
   * 
   * reg->tcr format in 2's complement. Note that the >>1 and
   * >>2 simply divide by 2 and 4 to get the # of words.
   */
  count = (inl(reg->csr) & WSIZE16) ? sizeb>>1 : sizeb>>2;
  outl(~(count-1), reg->tcr);
  
  /*
   * static volatile char cc_buf[BUFFER_SIZE]
   * The address of this array is put in reg->mra.
   * The num of bytes is put in reg->mrtc.
   */
  
  outl(virt_to_phys(cc_buf), reg->mra);
  outl(sizeb, reg->mrtc);

  /* clear ABORT MASTER bit */
  outl(0x100000, reg->ics);

  /* Reset in and outbound fifos & go */
  outl((unsigned int) (FIFO_RESET | inl(reg->bmcs)), reg->bmcs); 
  outl((unsigned int) (GO | inl(reg->csr)), reg->csr);

  cli();
  /* Enable DONE Interrupt */
  outl((unsigned int)(DONE_IENA | inl(reg->csr)), reg->csr);

  /* Enable DMA from PCI mem to 2915 */
  outl(RDT_ENA, reg->bmcs);

  /* wait for DONE interrupt */
# if   defined(LINUX_2_2)
  if (interruptible_sleep_on_timeout (&cc->wait_DMA_q,
				      DMA_TIMEOUT) == 0) return -ETIMEDOUT;
# elif defined(LINUX_2_0)
  current->timeout = jiffies + DMA_TIMEOUT;
  cc->wait_DMA++;
  interruptible_sleep_on (&cc->wait_DMA_q);

  if (current->timeout == 0)  return -ETIMEDOUT;
# endif

  /* Set Single mode */
  outl(0xFFF0 & inl(reg->csr), reg->csr);
  
  outl( (unsigned int)(FIFO_RESET | (~RDT_ENA & inl(reg->bmcs))), reg->bmcs);
  if(inl(reg->csr) & ERR) return -EIO;

  return (sizeb - inl(reg->mrtc));
}

static int
cc_ioctl (struct inode *inode, struct file *file,
	  unsigned int cmd, unsigned long arg)
{
  unsigned int minor = MINOR (inode->i_rdev);
  struct cc_struct *cc = &cc_table[minor];
  struct naf_data command;
  int    i, done_try=0, retval = 0;

#ifdef DEBUG2915
  unsigned int ui;
  printk("cc_ioctl: Entered cmd = %x \n",cmd);
#endif

  switch (cmd) {
    
  case CCIOC_RESET:           /* Reset Interface */

    retval = cc_reset();
#ifdef DEBUG2915
    printk("CCIOC_RESET: reset\n");
#endif
    break;

  case CCIOC_SET_CRATE:       /* Set Crate */

    if (arg >= 0 && arg < CC_MAX_CRATE) {
      /* only do something if changing crates */
      if (cc->cur_crate != arg) {
	cc->cur_crate = (short) arg;
	outl((unsigned int) cc->cur_crate << 16, reg->cnaf);
	outl((unsigned int) (FIFO_RESET | inl(reg->bmcs)), reg->bmcs); 
      } else {
#ifdef DEBUG2915
	printk("CCIOC_SET_CRATE: crate already set to %hd\n", cc->cur_crate);
#endif
	break;
      }
    }
    else {
      return -EINVAL;
    }

    for (; done_try < MAX_DONE_TRY; done_try++)
      if (inl(reg->csr) & DONE) break;
    if ((retval = (done_try == MAX_DONE_TRY) ? -EIO : 0))
      printk("CCIOC_SET_CRATE: Timeout, waiting for DONE\n");

#ifdef DEBUG2915
    printk("CCIOC_SET_CRATE: crate set to %hd\n", cc->cur_crate);
#endif

    break;

  case CCIOC_ENABLE_INT:

#ifdef DEBUG2915
    printk("CCIOC_ENABLE_INT: enabled interrupt\n");
#endif
      
    outl((unsigned int) 
	 (RFS_IENA | (inl(reg->csr) & RFS_MASK)), reg->csr);
    break;

  case CCIOC_DISABLE_INT:

#ifdef DEBUG2915
    printk("CCIOC_DISABLE_INT: disabled interrupt\n");
#endif
        
    outl((unsigned int) 
	 (~RFS_IENA & (inl(reg->csr) & RFS_MASK)), reg->csr);

    break;
    
  case CCIOC_ENABLE_LAM:

    camac_single(SINGLE | WSIZE24,
		 NAFGEN(K3922_N,K3922_STAT_A,K3922_READ_F), &i);
    i |= K3922_STAT_SRQ;
    camac_single(SINGLE | WSIZE24,
		 NAFGEN(K3922_N,K3922_STAT_A,K3922_WRIT_F), &i);

#ifdef DEBUG2915
    printk("CCIOC_ENABLE_LAM: Before cli cc_status: %x\n",i);
#endif

    i = arg;
    camac_single(SINGLE | WSIZE24,
		 NAFGEN(K3922_N,K3922_LAMM_A,K3922_WRIT_F), &i);

#ifdef DEBUG2915
    printk("CCIOC_ENABLE_LAM: mask = %#x\n",i);
    printk("CCIOC_ENABLE_LAM: csr  = %#x\n",inl(reg->csr));
#endif
      
    break;

  case CCIOC_DISABLE_LAM:

    camac_single(SINGLE | WSIZE24,
		 NAFGEN(K3922_N,K3922_STAT_A,K3922_READ_F), &i);
    i &= ~K3922_STAT_SRQ;
    camac_single(SINGLE | WSIZE24,
		 NAFGEN(K3922_N,K3922_STAT_A,K3922_WRIT_F), &i);

    i = 0;
    camac_single(SINGLE | WSIZE24,
		 NAFGEN(K3922_N,K3922_LAMM_A,K3922_WRIT_F), &i);
#ifdef DEBUG2915
    printk("CCIOC_DISABLE_LAM:\n");
#endif
    break;
    
  case CCIOC_WAIT_LAM:

#ifdef DEBUG2915
    printk("CCIOC_WAIT_LAM: timeout = %ld, csr = %04x\n", arg, inl(reg->csr));
#endif

    /*
     * 'current' is a pointer to a task_struct structure which
     * is the current task on this processor.
     * Jiffies are in 100ths of a sec (see sched.h).
     */
    cli();

#ifdef DEBUG2915
    printk("Enter sleep %ld\n",current->signal);
#endif

    cc->wait_LAM++;
#   if   defined(LINUX_2_2)
    if (arg <= 0)
      interruptible_sleep_on (&cc->wait_LAM_q);
    else
      if (interruptible_sleep_on_timeout (&cc->wait_LAM_q, arg) == 0) {
#ifdef DEBUG2915
      printk("CCIOC_WAIT_LAM: Timeout occurred\n");
#endif
      return -ETIMEDOUT;
    }
#   elif defined(LINUX_2_0)
    if (arg <= 0)
      current->timeout = -1; /* infinity */
    else
      current->timeout = jiffies + arg;

    interruptible_sleep_on (&cc->wait_LAM_q);

#ifdef DEBUG2915
    printk("Exit sleep %ld\n",current->signal);
#endif

    if (current->timeout == 0) {
#ifdef DEBUG2915
      printk("CCIOC_WAIT_LAM: Timeout occurred\n");
#endif
      return -ETIMEDOUT;
    }
  
#ifdef DEBUG2915
    printk("CCIOC_WAIT_LAM: LAM occurred, timeleft = %ld\n", current->timeout);
#endif
#   endif /* LINUX_2_0 */

    if (signal_pending(current)) return -ERESTARTNOINTR;

    break;

  case CCIOC_WAKE_LAM:

    if (cc->wait_LAM) {
      wake_up_interruptible(&cc->wait_LAM_q);
      /* --cc->wait_LAM; */
      cc->wait_LAM = 0;
    }
 
    break;

  case CCIOC_SINGLE:

    copy_from_user(&command, (void *)arg, sizeof(command));
    retval = camac_single(command.mode, command.naf, &command.data);
    command.xq = (inl(reg->csr) &
		  (XQ_MASK | ERR | NAF_TIMEOUT | PBUS_TIMEOUT));
    copy_to_user((void *)arg, &command, sizeof(command));

#ifdef DEBUG2915
    /* if mode = 16 bit, else 24 */
    if (command.mode & WSIZE16)
      ui = (unsigned short) command.data;
    else
      ui = (unsigned int  ) command.data;
    printk(
    "CCIOC_SINGLE: cmd mode=%#x, naf=%#x, data=%#x, cmd.xq=%#x, q,x=%d,%d\n",
           command.mode, command.naf, ui, command.xq,
	   ((command.xq&NOQ)>>16)?0:1,((command.xq&NOX)>>17)?0:1);
    printk("\n");
#endif

    break;
    
  case CCIOC_SETUP_DMA:

    copy_from_user (&command, (void *)arg, sizeof(command));
    outl((inl(reg->cnaf) & CRATE_MASK) | command.naf, reg->cnaf);

#ifdef DEBUG2915
    printk("CCIOC_SETUP_DMA: cmd mode=%#x, naf=%#x, data=%#x\n",
           command.mode, command.naf, command.data);
#endif

    /* if 16bit words, else 24bit */
    if(command.mode & WSIZE16) 
      outl( WSIZE16 | inl(reg->csr), reg->csr);
    else
      outl(~WSIZE16 & inl(reg->csr), reg->csr);

    /* get transfer mode bits and set register */
    i = command.mode & TRANSFER_MASK;
    if ((i != QSTOP ) && (i != QIGNORE) &&
	(i != QSCAN ) && (i != QREPEAT)) return -EINVAL;
    outl(((inl(reg->csr) & ~TRANSFER_MASK) | i), reg->csr);
    break;

  case CCIOC_CMD_STAT:

    /* Check status of last cmd: x, q, error,& timeout bits. */
    i = ((inl(reg->csr)) &
	 (XQ_MASK | ERR | NAF_TIMEOUT | PBUS_TIMEOUT));
    put_user(i, (int *) arg);

#ifdef DEBUG2915
    printk("CCIOC_CMD_STAT: error bits of csr reg = %x\n", i);
#endif

    break;
    
  case CCIOC_PPOLL:

    /* Do a parallel poll. */    
    outl((unsigned int) (PPOLL | GO |(inl(reg->csr) & CSR_MASK)), reg->csr);
    for (; done_try < MAX_DONE_TRY; done_try++)
      if (inl(reg->csr) & DONE) break;
    if ((retval = (done_try == MAX_DONE_TRY) ? -EIO : 0))
      printk("CCIOC_PPOLL: Timeout, waiting for poll\n");
    else {
      i = inl(reg->srr);
      put_user(i, (int *) arg);
    }
#ifdef DEBUG2915
    printk("CCIOC_PPOLL: srr reg = %x\n", i);
#endif

    break;

  case CCIOC_REG_DUMP:

    /* Print out all registers */
    {
      int r1,r2,r3,r4;

      r1=inl(reg->csr); r2=inl(reg->cnaf);
      r3=inl(reg->tcr); r4=inl(reg->srr);
      printk("CCIOC_DEBUG:\nParallel Bus Operational Registers\n");
      printk("   CSR       CNAF        TCR        SRR\n");
      printk("x%08x  x%08x  x%08x  x%08x\n",r1,r2,r3,r4);

      r1=inl(reg->bmcs); r2=inl(reg->ics);
      printk("PCI Interface Operational Registers\n");
      printk("   BMCS      ICS\n");
      printk("x%08x  x%08x\n",r1,r2);

      r1=inl(reg->mwa); r2=inl(reg->mwtc);
      r3=inl(reg->mra); r4=inl(reg->mrtc);
      printk("   MWA       MWTC        MRA        MRTC \n");
      printk("x%08x  x%08x  x%08x  x%08x\n",r1,r2,r3,r4);
    }
    break;

  default:
    retval = -EINVAL;
  }

#ifdef DEBUG2915
  printk("cc_ioct: end\n");
#endif

  return retval;
}

static int
cc_open (struct inode *inode, struct file *file)
{
  /*
  unsigned int minor = CC_MINOR;
  struct cc_struct *cc = &cc_table[minor];
  */
  int  retval=0;
  MOD_INC_USE_COUNT;
  return retval;
}

static relse_t
cc_release (struct inode *inode, struct file *file)
{
  /*
  unsigned int minor = CC_MINOR;
  struct cc_struct *cc = &cc_table[minor];
  */
  MOD_DEC_USE_COUNT;
# if   defined(LINUX_2_2)
  return 0;
# endif
}

static struct file_operations cc_fops =
{
# ifdef LINUX_2_4
  THIS_MODULE                 /* module owner */,
# endif
  NULL,                       /* lseek   */
  cc_read,
  cc_write,
  NULL,                       /* readdir */
  NULL,                       /* select  */
  cc_ioctl,
  NULL,                       /* mmap    */
  cc_open,
# if   defined(LINUX_2_2)
  NULL,                       /* flush   */
# endif
  cc_release,
};

int
cc_init (void)
{
  struct cc_struct *cc;
  int  retval=0;

# ifdef LINUX_2_4
  memset(&cc_table[0],0,sizeof(cc_table[0]));
  init_waitqueue_head(&cc_table[0].wait_LAM_q);
  init_waitqueue_head(&cc_table[0].wait_DMA_q);
# endif

  if (register_chrdev(K2915_MAJOR, "check_drv", &cc_fops)) {
    printk("cc_init: Cannot register major device %d for k2915\n",
	   K2915_MAJOR);
    return -EIO;
  }

  if (cc_probe((struct cc_struct *)cc_table, (struct camac *)reg)) {
    printk("cc_init: BaseAddress or IRQ Error\n");
    return -EIO;
  }
  cc = cc_table;

  if ((check_region(cc->base1,IOR_SIZE)  != 0) ||
      (check_region(cc->base2,PBOR_SIZE) != 0)) {
    printk("cc_init: No space for K2915 registers\n");
    return -EIO;
  }
  request_region(cc->base1,IOR_SIZE, "CAMAC K2915(IOR)" );
  request_region(cc->base2,PBOR_SIZE,"CAMAC K2915(PBOR)");

  /*
   * Here is the strategy. First try to use a fast, non-shared
   * interrupt. If that fails, it means another device is also
   * using this IRQ. Next, try to use a shared interrupt, if
   * that fails, you must either change the driver code of
   * the conflicting device so that it shares IRQs, or try to
   * get the bios to assign another IRQ to this card. Good luck!
   */
  if (request_irq(cc->irq, cc_interrupt,
		  SA_INTERRUPT, device ,(void *) device))
    {
      /* Try shared IRQ */
      if ((retval = request_irq(cc->irq, cc_interrupt,
				SA_SHIRQ, device ,(void *) device)))
	{
	  printk("cc_init: can't allocate IRQ%d for K2915\n",cc->irq);
	  return retval;
      } else {
	printk("cc_init: using shared interrupt\n");
      }
  } else {
    printk("cc_init: using fast interrupt\n");
  }

  printk("K2915 CAMAC Device Driver has been Installed.\n");
  printk("   IRQ :   %8d\n",cc->irq);
  printk("   IOR : 0x%8.8x\n",cc->base1);
  printk("   PBOR: 0x%8.8x\n",cc->base2);
  printk("   CSR : 0x%8.8x\n",reg->csr);
  printk("   CNAF: 0x%8.8x\n",reg->cnaf);
  printk("   FIFO: 0x%8.8x\n",reg->fifo);

  if ((cc_buf = kmalloc(BUFFER_SIZE, GFP_KERNEL)) == NULL) {
    printk("cc_init: failed in kmalloc(%d)\n", BUFFER_SIZE);
  } else {
    printk("DMA_buf: 0x%8.8lx (size %d)\n",
	   virt_to_phys(cc_buf), BUFFER_SIZE);
  }

  return cc_reset();
}

#ifdef MODULE
int 
init_module (void)
{
  return cc_init();  
}

void
cleanup_module (void)
{
  struct cc_struct *cc = cc_table;
  if (MOD_IN_USE)
    printk("cc cleanup_module: K2915 busy (not removed)\n");
  else {
    outl(0xFFF0 & inl(reg->csr), reg->csr); /* Set Single mode */
    if (cc_buf != NULL) kfree(cc_buf);
    free_irq(cc->irq, device);
    release_region(cc->base1,IOR_SIZE);
    release_region(cc->base2,PBOR_SIZE);
    unregister_chrdev(K2915_MAJOR, "check_drv");
    printk("cc cleanup_module: K2915 device driver removed\n");
  }
}
#endif

static int 
cc_probe(struct cc_struct *cc_pci_hdr, struct camac *cc_reg)
{
  unsigned char  pci_irq_line, pci_timer;
  unsigned short pci_command, pci_status;
  /* PCI Interface Operational Register (IOR) */
  unsigned int pci_ior_addr;    
  /* PCI Parallel Bus Operational Registers (PBOR) */
  unsigned int pci_pbor_addr;
  
# if   defined(LINUX_2_2)
  struct pci_dev *pdev=NULL;
  if (!pci_present()) {
    printk("cc_pci: PCI bios does not exist\n"); return -1;}
  if ((pdev=pci_find_device(PCI_VENDOR_ID_KINETIC,
			    PCI_DEVICE_ID_KINETIC_2915,
			    pdev)) == NULL) {
    printk("cc_pci: PCI board for %s not found.\n", device); return -1;}

  pci_read_config_byte(pdev, PCI_INTERRUPT_LINE, &pci_irq_line);
  pci_read_config_byte(pdev, PCI_LATENCY_TIMER,  &pci_timer);
  if (pci_timer != LTR_SET) {
    pci_write_config_byte(pdev, PCI_LATENCY_TIMER, LTR_SET); }

  pci_read_config_word(pdev, PCI_COMMAND, &pci_command);
  pci_read_config_word(pdev, PCI_STATUS,  &pci_status);
  /*
    printk("pci_command => %x  pci_status = %x\n", pci_command, pci_status);
  */
  pci_read_config_dword(pdev, PCI_BASE_ADDRESS_0, &pci_ior_addr);
  pci_read_config_dword(pdev, PCI_BASE_ADDRESS_1, &pci_pbor_addr);
# elif defined(LINUX_2_0)
  unsigned char  pci_bus, pci_device_fn;
  if (!pcibios_present()) {
    printk("cc_pci: PCI bios does not exist\n"); return -1;}
  if (pcibios_find_device(PCI_VENDOR_ID_KINETIC,
			  PCI_DEVICE_ID_KINETIC_2915,
			  0, &pci_bus, &pci_device_fn)) {
    printk("cc_pci: PCI board for %s not found.\n", device); return -1;}

  pcibios_read_config_byte(pci_bus, pci_device_fn, PCI_INTERRUPT_LINE, 
			   &pci_irq_line);	        
  pcibios_read_config_byte(pci_bus, pci_device_fn, PCI_LATENCY_TIMER, 
			   &pci_timer);
  if (pci_timer != LTR_SET) {
    pcibios_write_config_byte(pci_bus, pci_device_fn, PCI_LATENCY_TIMER,
			      LTR_SET);
  }

  pcibios_read_config_word(pci_bus, pci_device_fn, PCI_COMMAND,
			   &pci_command);
  pcibios_read_config_word(pci_bus, pci_device_fn, PCI_STATUS,
			   &pci_status);
  /*
    printk("pci_command => %x  pci_status = %x\n", pci_command, pci_status);
  */

  pcibios_read_config_dword(pci_bus, pci_device_fn, PCI_BASE_ADDRESS_0,
			    &pci_ior_addr);
  pcibios_read_config_dword(pci_bus, pci_device_fn, PCI_BASE_ADDRESS_1,
			    &pci_pbor_addr);
# endif
  pci_ior_addr  &= PCI_BASE_ADDRESS_IO_MASK;
  pci_pbor_addr &= PCI_BASE_ADDRESS_IO_MASK;

  cc_pci_hdr->irq   = pci_irq_line;
  cc_pci_hdr->base1 = pci_ior_addr;
  cc_pci_hdr->base2 = pci_pbor_addr;

  cc_reg->csr  += pci_pbor_addr;
  cc_reg->cnaf += pci_pbor_addr;
  cc_reg->tcr  += pci_pbor_addr;
  cc_reg->srr  += pci_pbor_addr;

  cc_reg->fifo += pci_ior_addr;
  cc_reg->mwa  += pci_ior_addr;
  cc_reg->mwtc += pci_ior_addr;
  cc_reg->mra  += pci_ior_addr;
  cc_reg->mrtc += pci_ior_addr;
  cc_reg->ics  += pci_ior_addr;
  cc_reg->bmcs += pci_ior_addr;
  /*
    printk("K2915 card at ior = %#x, pbor = %#x, irq = %d\n",
            pci_ior_addr, pci_pbor_addr, pci_irq_line);
  */

  return 0;
}

/*
 *  commander -- MARS main control program
 */

#include <sys/types.h>
#include <sys/ipc.h>
#include <sys/shm.h>
#include <sys/sem.h>
#include <sys/wait.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <unistd.h>
#include <stdlib.h>
#include <stdio.h>
#include <time.h>
#include <string.h>
#include <sys/ioctl.h>
#include "hsm_ioctl.h"
#include "crashm.h"

#define CMD_PATH        1
#define CMD_START       2
#define CMD_STOP        3
#define CMD_TRANSFER    4
#define CMD_BLOCKS      5
#define CMD_SCALER      6
#define CMD_RUNNO       7
#define CMD_EXIT       99

const struct {char *name; int min, key; }
cmd_table[] = {
  {"path"      ,  1, CMD_PATH      },
  {"start"     ,  3, CMD_START     },
  {"stop"      ,  3, CMD_STOP      },
  {"transfer"  ,  1, CMD_TRANSFER  },
  {"blocks"    ,  1, CMD_BLOCKS    },
  {"scaler"    ,  2, CMD_SCALER    },
  {"runno"     ,  1, CMD_RUNNO     },
  {"exit"      ,  1, CMD_EXIT      },
  {""          ,  0, 0             }
};

int chk_cmd(char *arg)
{
  char s[256]; int i, n;
  while (*arg == ' ') arg++;
  for (n = 0; *arg != ' ' && *arg != 0; arg++)
    s[n++] = ((*arg < 'a') ? *arg + ' ' : *arg); s[n] = 0;
  for (i = 0; cmd_table[i].key != 0; i++) {
    if (n >= cmd_table[i].min && n <= strlen(cmd_table[i].name))
      if (!strncmp(s, cmd_table[i].name, n)) return cmd_table[i].key;
  }
  return -1;
}

int rmt_path();
int chk_sampler();

#define gets(s) (fgets(s,sizeof(s),stdin)?s[strlen(s)-1]=0,s:NULL)
#define set_time(a,b)  {\
time_t tp=time(NULL);\
strftime(a, 9,"%H:%M:%S",localtime(&tp));\
strftime(b,10,"%d-%b-%y",localtime(&tp));}

int     shmid, semid;
CRASHM *shmp;

int main(int argc, char *argv[])
{
  int    fd, i, v;
  char   s[256], path[256]="\0";
  struct sembuf semcmd;
  setvbuf(stdout, (char *)NULL, _IONBF, 0); /* set stdout unbuffered */
  if ((shmid = shmget(SHMKEY, sizeof(CRASHM), IPC_CREAT|0600)) == -1)
    {puts("! Cannot create shared memory"); exit(2);}
  if ((semid = semget(SEMKEY, SEM_NUM       , IPC_CREAT|0600)) == -1)
    {puts("! Cannot create semaphore"); exit(2);}
  shmp = (CRASHM *)shmat(shmid, 0, 0);
  if (!(argc > 1 && !strcmp(argv[1], "-n"))) {
    shmp->wp = shmp->runno = -1;
    shmp->acquire = shmp->remote = shmp->fd = shmp->nblock = shmp->mtape = 
      shmp->user[0] = shmp->host[0] = shmp->pwd[0] = shmp->path[0] = 0;
    for (i = 0; i < MAX_SAMPLERS; i++) shmp->sampler[i].pid = 0;}
  if ((fd = open("/dev/hsm", O_RDWR)) == -1)
    {puts("! VME/HSM device open error."); exit(2);}
  ioctl(fd, HSM_DAQ_INIT, 0);
  while (gets(s)) {
    switch (chk_cmd(s)) {
    case CMD_PATH:
      if (shmp->acquire) puts("# Stop DAQ first"); else gets(path);
      break;
    case CMD_START:
      if (shmp->acquire) {puts("# Stop before start"); break;}
      gets(shmp->comment);
      shmp->remote = shmp->mtape = 0;
      if (path[0]) if (rmt_path(path)) break; path[0]=0;
      bzero((char *)shmp->scaler, sizeof(int)*SCL_NUM_DATA); /* clear scaler */
      chk_sampler();
      shmp->runno++;
      shmp->nblock = shmp->badblock = 0;
      shmp->wp = -1; /* incremented to zero by recorder */
      for (i = 0; i < MAX_SAMPLERS; i++) shmp->sampler[i].block = 0;
      set_time(shmp->sta_time, shmp->sta_date);
      shmp->sto_time[0] = shmp->sto_date[0] = 0;
      ioctl(fd, HSM_DAQ_WRCMT, 0); /* notify recorder to write comment */
      sem_op(semid, semcmd, sem_record, -1); /* wait for xfer done */
      ioctl(fd, HSM_DAQ_START, 0);
      shmp->acquire = 1;
      printf("<< START >>\n%4.4d\n", shmp->runno);
      break;
    case CMD_STOP:
      if (!shmp->acquire) {puts("# Start before stop"); break;}
      if (ioctl(fd, HSM_DAQ_STOP, 0)) /* if last buffer waiting to be xfered */
	sem_op(semid, semcmd, sem_record, -1); /* wait for xfer done */
      shmp->acquire = 0;
      gets(shmp->comment);
      set_time(shmp->sto_time, shmp->sto_date);
      puts("<< STOP >>");
      usleep(50000L); /* this delay is required, but why ? */
      ioctl(fd, HSM_DAQ_WRCMT, 0); /* notify recorder to write comment */
      sem_op(semid, semcmd, sem_record, -1); /* wait for xfer done */
      chk_sampler();
      break;
    case CMD_TRANSFER:
      if (!shmp->acquire) break;
      if (ioctl(fd, HSM_DAQ_XFER, 0)) /* force buffer transfered */
	sem_op(semid, semcmd, sem_record, -1); /* wait for xfer done */
      break;
    case CMD_BLOCKS:
      chk_sampler();
      printf("<< BLOCKS >>\n%d blks", shmp->nblock);
      if (shmp->mtape) {
	v = shmp->mtblock*HSM_BLK_SIZE*sizeof(short);
	printf(" (%d.%d MB on tape)", v/1048576, (v%1048576)/104858);}
      puts("");
      break;
    case CMD_SCALER:
      chk_sampler();
      set_time(shmp->pri_time,shmp->pri_date);
      printf("RUN-%4.4d  START => %8s  STOP => %8s   Print => %8s  %9s\n",
	     shmp->runno, shmp->sta_time, shmp->sto_time, shmp->pri_time,
	     shmp->sta_date);
      printf("%s\n", shmp->comment);
      for (i = 0; i < SCL_NUM_DATA; i++) printf("%10d", shmp->scaler[i]);
      puts("");
      for (i = 0; i < MAX_SAMPLERS; i++)
	if (shmp->sampler[i].pid)
	  printf("%3d%6d: %-20s%10d (%10d)\n", i, shmp->sampler[i].pid,
		 shmp->sampler[i].name, shmp->sampler[i].block, shmp->nblock);
      break;
    case CMD_RUNNO:
      if (scanf("%d\n", &v) == 1 && v >= 0 && v < 10000)
	shmp->runno = v;
      else
	puts("# Invalid Run No.");
      break;
    case CMD_EXIT:
      if (shmp->acquire) {puts("# Stop before exit"); break;}
      goto EXIT;
    default:
//    printf("# Invalid Command (%s).\n", s);
      printf("Invalid Command.\n"); /* not to make passwd appear on screen...*/
      break;
    }
  }
 EXIT:
  shmp->acquire = -1;
  ioctl(fd, HSM_DAQ_FINISH, 0); /* relieve recorder from WAITBUF loop */
  sem_op(semid, semcmd, sem_newdat, 1); /* wake up sampler(s) if waiting */
  /* delay is not necessary, because EIDRM error does the same job */
  usleep(100000L);
  close(fd);
  shmdt((char *)shmp);
  shmctl(shmid, IPC_RMID, 0);
  semctl(semid, 0, IPC_RMID, 0);
  exit(0);
}

#include <netdb.h>
#include <sys/socket.h>
#include <pwd.h>

char   sh[]="\
path=%s\n\
file=run%4.4d.dat\n\
if [ -c $path ]\n\
  then\n\
    if [ -w $path ]\n\
      then {\n\
        MT=`mt status -f $path` \
                           || { echo e\\# $path is not available.; exit 2; }\n\
        echo $MT | grep -q ONLINE \
                           || { echo e\\# media not loaded.; exit 2; }\n\
        echo $MT | grep -q WR_PROT \
                           && { echo e\\# write-protected media.; exit 2; }\n\
        echo $MT | grep -q BOT \
                           && echo t0 || echo t\n\
      }\n\
      else { echo e\\# $path is write protected.; exit 2;}\n\
    fi\n\
  elif [ -d $path ]\n\
    then\n\
      if [ -w $path ]\n\
        then\n\
          if [ -e $path/$file ]\n\
            then\n\
              if [ -w $path/$file ]\n\
                then { mv $path/$file $path/$file~; echo d; }\n\
                else echo e\\# $path/$file exists and write-protected.\n\
              fi\n\
            else echo d\n\
          fi\n\
        else echo e\\# $path is write protedted.\n\
      fi\n\
  else echo e\\# $path is invalid path\n\
fi\n\
";

struct servent *serv;

int rmt_path(char *path)
{
  char   *q, *user=(char *)NULL, *host=(char *)NULL, s[2048];
  int     sd=0;
  FILE   *fd;
  if ((shmp->remote = ((q = strchr(path, ':')) != NULL))) {
    host = path; *q = 0; path = ++q;
    if ((q = strchr(host, '@')) != NULL) {user = host; *q = 0; host = ++q;}
    else user = getenv("LOGNAME");
    if (strcmp(host, shmp->host) || strcmp(user, shmp->user)) {
      if (isatty(0)) {       /* invoked from terminal */
	sprintf(s, "Password (%s:%s): ", host, user);
	strcpy(shmp->pwd, getpass(s));
      } else {               /* invoked as subprocess */
	printf("? Password (%s:%s):\n", host, user);
	gets(shmp->pwd);
      }
      strcpy(shmp->host, host); strcpy(shmp->user, user);
    }
  }
  strcpy(shmp->path, path);
  sprintf(s, sh, path, shmp->runno+1);
  if (!shmp->remote) {
    if ((fd = popen(s, "r")) == NULL) {puts("# popen error"); return -1;}
  } else {
    if ((serv = getservbyname("exec", "tcp")) == NULL)
      {puts("# exec/tcp: service not available"); return -1;}
    if ((sd = rexec((char **)(&host), serv->s_port, user,
		    shmp->pwd, "/bin/sh", (int *)NULL)) == -1)
      {puts("# rexec fail"); shmp->host[0] = 0; return -1;}
    fd = fdopen(sd, "r+");
    fputs(s, fd); fflush(fd);
  }
  s[0] = 0;
  if (fgets(s, 256, fd) == NULL) puts("# rexec script error");
  if (!shmp->remote) pclose(fd);
  else {fclose(fd); shutdown(sd, 2); close(sd);}
  switch (s[0]) {
  case 't':
    shmp->mtape = 1;
    printf("<< OPEN >>\n%s (tape", path);
    if (s[1] == '0') {printf(", new volume"); shmp->mtblock =0;}
    if (shmp->remote) printf(") on %s@%s\n", user, host);
    else puts(")");
    break;
  case 'd':
    shmp->mtape = 0;
    printf("<< OPEN >>\n%s/run%4.4d.dat", path, shmp->runno+1);
    if (shmp->remote) printf(" on %s@%s", user, host);
    puts("");
    break;
  case 'e':
    puts((char *)&s[1]);
    return -1;
  default:
    printf("# unexpected error (%s)\n", s);
    return -1;
  }
  return 0;
}

int chk_sampler()
{
  FILE *fd;
  int   p[1024], i, j, n=0;
  char  s[100];
  fd = popen("ps xch", "r");
  while (fgets(s, 100, fd) != NULL)
    if ((p[n] = atoi(s))) {if (++n >= 1024) return 1;}
  pclose(fd);
  for (i = 0; i < MAX_SAMPLERS; i++) {
    for (j = 0; j < n; j++) if (shmp->sampler[i].pid == p[j]) goto found;
    shmp->sampler[i].pid = 0;
  found:
  }
  return 0;
}

/*
    header file of VME/HSM DAQ system.  

    CRASHM stands for 
      Commander, Recorder and Analyzer's SHared Memory file, 
    and has nothing to do with the word "crash".  
*/

#ifndef CRASHM_H
#define CRASHM_H

#ifndef HSM_CONF_H
#include "hsm_conf.h"
#endif

#ifndef SCL_CONF_H
#include "scl_conf.h"
#endif

#define SHMKEY       1048577
#define SEMKEY       SHMKEY
#define SEM_BUFFER  (SEMKEY+1)
#define SEM_SAMPLE  (SEMKEY+2)
#define sem_record   0
#define sem_newdat   1
#define SEM_NUM      2
#define sem_op(id,buf,num,op) \
{buf.sem_num=num;buf.sem_op=op;buf.sem_flg=0;semop(id,&buf,1);}

#define MAX_SAMPLERS 16
#define CRA_BLK_NUM HSM_BLK_NUM

typedef struct {
  unsigned short                 /* block data buffer            */
           buffer[CRA_BLK_NUM][HSM_BLK_SIZE];
  unsigned int                   /* accumulated scaler           */
           scaler[SCL_NUM_DATA];
  int      wp;                   /* pointer to written block     */
  int      acquire;              /* status of data acquisition   */

  int      runno;                /* Run No.                      */
  char     sta_time[16];         /* start time                   */
  char     sto_time[16];         /* stop  time                   */
  char     pri_time[16];         /* print time (what is print ?) */
  char     sta_date[16];         /* start date                   */
  char     sto_date[16];         /* stop  date                   */
  char     pri_date[16];         /* print date (what is print ?) */
  char     comment[80];          /* comment                      */

  int      remote;               /* remote recording (0 or 1)    */
  char     user[20];             /* user name of remote machine  */
  char     host[80];             /* host name of remote machine  */
  char     pwd[20];              /* password  of remote machine  */
  char     path[256];            /* file path for record         */
  int      fd;                   /* file descriptor              */

  int      nblock;               /* No. of valid data block      */
  int      badblock;             /* No. of  bad  data block      */
  int      mtape;                /* device is mag. tape (1 or 0) */
  int      mtblock;              /* No. of blocks written to MT  */
  struct  {                      /* statistics of samplers       */
    int    pid;
    char   name[20];
    int    block;
  }        sampler[MAX_SAMPLERS];
} CRASHM;

#define block_scaler(blk,ch) \
*(unsigned int *)&(shmp->buffer[blk][SCL_BLK_OFS+2*ch])

/* offset of Run No. etc. in start/stop block (in byte) */
#define BLK_RUN_OFS  20
/* offset of comment in start/stop block (in byte) */
#define BLK_CMT_OFS 100

#endif /* CRASH_H */

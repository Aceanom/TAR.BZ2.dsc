/************************************************************************
 *									*
 *	Copyright 1993 by Motorola Wireless Data Group,			*
 *			  Bothell, WA					*
 *									*
 *	Motorola hereby grants permission to use, copy, modify and	*
 *	distribute  this software and its documentation for any		*
 *	purpose and without fee, provided that you retain this		*
 *	copyright notice in all copies.  Motorola makes no		*
 *	representations about the suitability of this software for any	*
 *	purpose.  Motorola provides this software ``as is'' without	*
 *	express or implied warranty.					*
 *									*
 ************************************************************************/

/* $Header: /users/jaws/joek/SVipc/RCS/patchlevel.h,v 1.6 1996/05/08 20:39:03 joek Exp $ */

/*
 * File: SVipc/patchlevel.h
 * Facility: System V IPC Interface to Tcl
 * Description:
 *	Provide patchlevel number to insure any patches get applied correctly.
 */

#define SVIPC_PATCHLEVEL 0

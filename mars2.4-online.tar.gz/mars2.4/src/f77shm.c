/*
 *  "libf77shm.a"
 *
 *   A library callable from f77 (f2c) to allow accessing to shared memory. 
 *
 *   SUBROUTINE GETHDR(RUNNO, COMENT, STATIM, STADAT, STOTIM, STODAT, *)
 *   INTEGER*4 RUNNO
 *   CHARACTER COMENT*80, STATIM*8, STADAT*9, STOTIM*8, STODAT*9
 *        ---- RETURN 1 in failure of attaching shared memory. 
 *
 *   SUBROUTINE GETSCL(SCALER, *)
 *   INTEGER*4 SCALER(16,N)
 *        ---- N must be a proper value.  
 *        ---- RETURN 1 in failure of attaching shared memory. 
 *
 *   SUBROUTINE SHMDET
 *        ---- Must be called before finishing program.  
 */

#include <sys/ipc.h>
#include <sys/shm.h>
#include <string.h>
#include "crashm.h"

static int     shmid=0;
static CRASHM *shmp =(CRASHM *)NULL;

static int attach()
{
  if (shmp == NULL) {
    if ((shmid = shmget(SHMKEY, sizeof(CRASHM), 0400)) == -1)
      return 1;
    shmp = (CRASHM *)shmat(shmid, 0, 0);
  }
  return 0;
}

int gethdr_(int *runno,
	    char *comment,
	    char *sta_time, char *sta_date, 
	    char *sto_time, char *sto_date,
	    int len_comment,
	    int len_sta_time, int len_sta_date, 
	    int len_sto_time, int len_sto_date)
{
  if (attach()) return 1;
  *runno = shmp->runno;
  memset (comment, (int)' ', len_comment);
  if (len_comment > strlen(shmp->comment))
      len_comment = strlen(shmp->comment);
  strncpy(comment, shmp->comment, len_comment);
  memset (sta_time, (int)' ', len_sta_time);
  if (len_sta_time > strlen(shmp->sta_time))
      len_sta_time = strlen(shmp->sta_time);
  strncpy(sta_time, shmp->sta_time, len_sta_time);
  memset (sta_date, (int)' ', len_sta_date);
  if (len_sta_date > strlen(shmp->sta_date))
      len_sta_date = strlen(shmp->sta_date);
  strncpy(sta_date, shmp->sta_date, len_sta_date);
  memset (sto_time, (int)' ', len_sto_time);
  if (len_sto_time > strlen(shmp->sto_time))
      len_sto_time = strlen(shmp->sto_time);
  strncpy(sto_time, shmp->sto_time, len_sto_time);
  memset (sto_date, (int)' ', len_sto_date);
  if (len_sto_date > strlen(shmp->sto_date))
      len_sto_date = strlen(shmp->sto_date);
  strncpy(sto_date, shmp->sto_date, len_sto_date);
  return 0;
}

int getscl_(int *scaler)
{
  if (attach()) return 1;
  memcpy(scaler, shmp->scaler, sizeof(shmp->scaler));
  return 0;
}

void detach_() {shmdt((char *)shmp);}

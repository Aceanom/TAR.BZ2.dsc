/*
 *  recorder -- MARS raw-data recorder
 */

#include <sys/types.h>
#include <sys/ipc.h>
#include <sys/shm.h>
#include <sys/sem.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <unistd.h>
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <sys/ioctl.h>
#include "hsm_conf.h"
#include "scl_conf.h"
#include "hsm_ioctl.h"
#include "crashm.h"

int rmt_open();
int rmt_close();

int     shmid;
CRASHM *shmp;
int     semid, sem_buffer, sem_sample;

int main(int argc, char *argv[])
{
  int           fd, wp, *p, i, hsm_addr;
  struct sembuf semcmd;
  setvbuf(stdout, (char *)NULL, _IONBF, 0); /* set stdout unbuffered */
  if ((shmid = shmget(SHMKEY, sizeof(CRASHM), IPC_CREAT|0600)) == -1)
    {puts("! Cannot create shared memory"); exit(2);}
  if ((semid = semget(SEMKEY, SEM_NUM       , IPC_CREAT|0600)) == -1 ||
      (sem_buffer = semget(SEM_BUFFER, CRA_BLK_NUM, IPC_CREAT|0600)) == -1 ||
      (sem_sample = semget(SEM_SAMPLE, CRA_BLK_NUM, IPC_CREAT|0600)) == -1)
    {puts("! Cannot create semaphore"); exit(2);}
  shmp = (CRASHM *)shmat(shmid, 0, 0);
  if ((fd = open("/dev/hsm", O_RDWR)) == -1)
    {puts("! VME/HSM device open error."); exit(2);}
  while (!ioctl(fd, HSM_DAQ_WAITBUF, &hsm_addr)) { /* wait for buffer */
    wp = ++shmp->wp % CRA_BLK_NUM;
    sem_op(sem_sample, semcmd, wp, 0); /* wait for sampler(s) done */
    sem_op(sem_buffer, semcmd, wp, 1); /* lock buffer */
    if (shmp->acquire) {
      /* get a buffer with DMA */
      lseek(fd, (off_t)hsm_addr, SEEK_SET);
      if (read(fd, shmp->buffer[wp], HSM_BLK_SIZE*sizeof(short))
	  != HSM_BLK_SIZE*sizeof(short))
	HSM_BLK_ID(shmp->buffer[wp]) = HSM_BID_BAD;
      /* get scalers */
      p = (int *)&(shmp->buffer[wp][SCL_BLK_OFS]);
      ioctl(fd, HSM_DAQ_GETSCL, p);
      if (!HSM_BID_VALID(HSM_BLK_ID(shmp->buffer[wp]))) {
	shmp->badblock++;
      } else { /* add scaler to "summed" scaler */
	for (i = 0; i < SCL_NUM_DATA; i++) shmp->scaler[i] += *(p++);
	shmp->nblock++;
      }
    } else {
      /* write comment block */
      bzero(shmp->buffer[wp], HSM_BLK_SIZE*sizeof(short));
      HSM_BLK_ID(shmp->buffer[wp]) =
	(shmp->sto_time[0] ? HSM_BID_STO : HSM_BID_STA);
      sprintf((char *)(&shmp->buffer[wp])+BLK_RUN_OFS, 
	      "RUN-%4.4d  START => %8s  STOP => %8s   Print => %8s  %9s", 
	      shmp->runno, shmp->sta_time, shmp->sto_time, shmp->pri_time, 
	      shmp->sta_date);
      sprintf((char *)(&shmp->buffer[wp])+BLK_CMT_OFS,
	      "%-160s", shmp->comment);
      usleep(50000L);
    }
    sem_op(sem_buffer, semcmd, wp, -1); /* free buffer */
    if ((i = semctl(semid, sem_newdat, GETNCNT, 0)))
      sem_op(semid, semcmd, sem_newdat, i); /* wake up sampler(s) if waiting */
//#define MONITOR
#ifdef MONITOR
    printf("wp=%4d, %4.4x\n",
	   shmp->wp, shmp->buffer[wp][HSM_BLK_SIZE-2]);
    for (i = 0; i < 32; i++) printf(" %4.4x", shmp->buffer[wp][i]); puts("");
#endif
    if (shmp->path[0]) {                /* write data to storage */
      if (HSM_BLK_ID(shmp->buffer[wp]) == HSM_BID_STA) if (rmt_open()) break;
      if (write(shmp->fd, shmp->buffer[wp], HSM_BLK_SIZE*sizeof(short))
	  != HSM_BLK_SIZE*sizeof(short)) {
	perror("write"); puts("# write error");
	ioctl(fd, HSM_DAQ_STOP, 0); close(shmp->fd);}
      if (shmp->mtape) shmp->mtblock++;
      if (HSM_BLK_ID(shmp->buffer[wp]) == HSM_BID_STO) if (rmt_close()) break;
    }
    /* notify that xfer & record done, enable DAQ if necessary */
    ioctl(fd, HSM_DAQ_WASREAD, 0);
    if (semctl(semid, sem_record, GETNCNT, 0))
      sem_op(semid, semcmd, sem_record, 1); /* wake up cmmnder if waiting */
  }
  close(fd);
  shmdt((char *)shmp);
  semctl(sem_buffer, 0, IPC_RMID, 0);
  semctl(sem_sample, 0, IPC_RMID, 0);
  exit(0);
}

#include <netdb.h>
#include <sys/socket.h>

struct  servent *serv;

int rmt_open()
{
  char  *host=(char *)shmp->host, s[256];
  if (shmp->remote) serv = getservbyname("exec", "tcp");
  if (shmp->mtape) {    /* record to tape */
    if (!shmp->remote) {
      if ((shmp->fd = open(shmp->path, O_CREAT | O_WRONLY, 0644)) == -1)
	{puts("# mt open error."); shmp->fd = 0; return -1;}
    } else {
      sprintf(s, "/bin/dd bs=%d of=%s",
	      HSM_BLK_SIZE*sizeof(short), shmp->path);
      if ((shmp->fd = rexec((char **)(&host), serv->s_port, shmp->user,
			    shmp->pwd, s, (int *)NULL)) == -1)
	{puts("# remote mt open error."); shmp->fd = 0; return -1;}
    }
  } else {              /* record to disk */
    if (!shmp->remote) {
      sprintf(s, "%s/run%4.4d.dat", shmp->path, shmp->runno);
      if ((shmp->fd = open(s, O_CREAT | O_WRONLY, 0644)) == -1)
	{puts("# file open error."); shmp->fd = 0; return -1;}
    } else {
      sprintf(s, "/bin/dd bs=%d of=%s/run%4.4d.dat", 
	      HSM_BLK_SIZE*sizeof(short), shmp->path, shmp->runno);
      if ((shmp->fd = rexec((char **)(&host), serv->s_port, shmp->user,
			    shmp->pwd, s, (int *)NULL)) == -1)
	{puts("# remote file open error."); shmp->fd = 0; return -1;}
    }
  }
  return 0;
}

int rmt_close()
{
  char  *host=(char *)shmp->host, s[80];
  int    sd;
  FILE  *fd;
  if (shmp->remote) shutdown(shmp->fd, 2);
  close(shmp->fd);
  shmp->fd = shmp->path[0] = 0;
  printf("<< CLOSE >>\n%d blks (%d bad-blks",
	 shmp->nblock+2, shmp->badblock);
  if (shmp->mtape) {
    int  b;
    sprintf(s, "mt weof 2 -f %s ; mt bsfm 1 -f %s \n", shmp->path, shmp->path);
    if (!shmp->remote)
      return system(s);
    else {
      if ((sd = rexec((char **)(&host), serv->s_port, shmp->user,
		      shmp->pwd, "/bin/sh", (int *)NULL)) == -1)
	{puts("# rexec fail"); return -1;}
      fd = fdopen(sd, "r+");
      fputs(s, fd); fflush(fd); fclose(fd);
      shutdown(sd, 2); close(sd);
    }
    b = shmp->mtblock*HSM_BLK_SIZE*sizeof(short);
    printf(", %d.%d MB on tape", b/1048576, (b%1048576)/104858);
  }
  puts(")");
  return 0;
}

#include "analyzer.h"

void hststo_(unsigned int *scaler)
{
}

/*
 *  analyzer -- MARS raw-data analyzer main routine
 */

#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <signal.h>
#include <netdb.h>
#include <sys/socket.h>
#include <pwd.h>
#include "crashm.h"
#include "analyzer.h"
#include "fera.h"

static unsigned short buffer[HSM_BLK_SIZE];
static unsigned int   qwdbuf[HSM_BLK_SIZE];
static unsigned int   scaler[SCL_NUM_DATA];
static unsigned int   nblock=0, lblock=0, nevent=0, levent=0, analyzed=0;

static int  interrupt=0;
static int  intreturn=0;
static void sighandler()
{
  interrupt = 1;
  intreturn = usrast_();
  signal(SIGINT, sighandler);
}

static int  tenblock=0;

static int  summary_out=0;
static void summary()
{
  if (intreturn) puts("\n** stopped by interrupt. **");
  printf("\nanalysis summary:\n");
  printf("  %-8s%12s%12s\n", " "       , "blocks", "events");
  printf("  %-8s%12d%12d\n", "valid"   , nblock  , nevent);
  printf("  %-8s%12d%12d\n", "illigal" , lblock  , levent);
  printf("  %-8s%12s%12d\n", "analyzed", " "     , analyzed);
  puts  ("  * comment blocks are not included.\n"); fflush(stdout);
  summary_out = 1;
}
static int blockman()
{
  char  runno[9], comment[81];
  int   i, buflen=HSM_BLK_LEN(buffer);
  if (tenblock && nblock%10 == 0)
    {fprintf(stderr, " %d-block\r", nblock); fflush(stderr);}
  switch (HSM_BLK_ID(buffer)) {
  case HSM_BID_STA:
    nblock = lblock = nevent = levent = analyzed = summary_out = 0;
    bzero(scaler, sizeof(scaler));
    strncpy(runno  , (char *)buffer+BLK_RUN_OFS,  8); runno[8] = 0;
    strncpy(comment, (char *)buffer+BLK_CMT_OFS, 80); comment[80] = 0;
    hststa_(runno, comment, 8, 80);
    printf("\nStart %s\n%s\n", runno, comment); fflush(stdout);
    return intreturn;
  case HSM_BID_STO:
    hststo_(scaler);
    strncpy(runno  , (char *)buffer+BLK_RUN_OFS,  8); runno[8] = 0;
    strncpy(comment, (char *)buffer+BLK_CMT_OFS, 80); comment[80] = 0;
    printf("\nStop  %s\n%s\n", runno, comment); fflush(stdout);
    summary();
    return intreturn;
  case HSM_BID_RAW(0):
  case HSM_BID_RAW(1):
  case HSM_BID_RAW(2):
  case HSM_BID_RAW(3):
  case HSM_BID_RAW(4):
  case HSM_BID_RAW(5):
  case HSM_BID_RAW(6): /* only up to this, as VME IRQ is 1 thru 7 */
    nblock++;
    if (stablk_((unsigned int *)&buffer[SCL_BLK_OFS])) return intreturn;
    for (i = HSM_HDR_LEN; i < buflen; ) {
      int j=0, k;
      if (intreturn) goto abort;
      if (!EVENT_HEADER(buffer[i])) {
	levent++;
	printf("Illigal event-header (%4.4x)\n", buffer[i]);
	do {if (++i >= buflen) goto abort;} while (!EVENT_HEADER(buffer[i]));}
      do {
	if (!FERA_HEADER(buffer[i])) {
	  levent++;
	  printf("Illigal FERA-header (%4.4x) at %4.4x\n", buffer[i], i);
	  do if (++i >= buflen) goto abort; while (!EVENT_HEADER(buffer[i]));
	  goto next_event;}
	switch (FERA_TYPE(buffer[i])) {
	case 0: /* 4300B, AD413A, AD114, etc. */
	  for (k = FERA_VDC0(buffer[i])+1 /* header */; k > 0; k--)
	    qwdbuf[j++] = buffer[i++];
	  break;
	case 1: /* 3341, 3351, 3371, etc. */
	  for (k = FERA_VDC1(buffer[i])+2 /* hdr+pw */; k > 0; k--)
	    qwdbuf[j++] = buffer[i++];
	  break;
	case 2: /* 3377, etc. There is no word count */
	  do qwdbuf[j++] = buffer[i++];
	  while (!FERA_HEADER(buffer[i]) && i < buflen);
	  break;
	case 3: /* unsupported FERA type */
	  levent++;
	  printf("Unsupported FERA type (%4.4x)\n", buffer[i]);
	  do if (++i >= buflen) goto abort; while (!EVENT_HEADER(buffer[i]));
	  goto next_event;
	}
      } while (!EVENT_HEADER(buffer[i]) && i < buflen);
      nevent++;
      switch (event1_((int *)qwdbuf, &j)) {
      case 0: analyzed++; break;
      case 1:             break;
      case 2: goto abort;
      case 3: return 1;
      }
  next_event:
    } /* for (i = HSM_HDR_LEN; i < buflen; ) */
  abort:
//#define MONITOR
#ifdef MONITOR
    printf("nblock=%d (%4.4x,%4.4x), nevent=%d (%4.4x), levent=%d (%4.4x)\n",
	   nblock, nblock, HSM_BLK_SN(buffer), nevent, nevent, levent, levent);
#endif
    for (i = 0; i < SCL_NUM_DATA; i++)
      scaler[i] += ((unsigned int *)&buffer[SCL_BLK_OFS])[i];
    return (endblk_((unsigned int *)&buffer[SCL_BLK_OFS]) || intreturn);
  case HSM_BID_BAD:
  default:
    lblock++;
    return intreturn;
  }
}

#define gets(s) (fgets(s,sizeof(s),stdin)?s[strlen(s)-1]=0,s:NULL)

static char  user[20]=USERNAME;
static char  host[80]=HOSTNAME;
static char  sampler[256]=SAMPLER;
static char  ID[256]="\0";

int main(int argc, char *argv[])
{
  char   c, localhost[80], pwd[20], s[256], *proc;
  extern char *optarg;
  extern int   optind, opterr, optopt;
  FILE  *fd;
  int    sd=0, i;
  if ((proc = rindex(argv[0], '/')) != NULL) proc++; else proc = argv[0];
  while ((c = getopt(argc, argv, "l:r:s:bh")) != -1)
    switch(c) {
    case 'l':
      strcpy(user, optarg);
      break;
    case 'r':
      sprintf(s, "nslookup %s 2> /dev/null | awk '/Name:/{print $2}'", optarg);
      fd = popen(s, "r"); s[0] = 0; fgets(s, sizeof(s), fd); fclose(fd);
      if (!s[0]) {fprintf(stderr, "illegal host -- %s\n", optarg); exit(2);}
      s[strlen(s)-1] = 0 /* to eliminate "\n" */; strcpy(host, s);
      break;
    case 's':
      strcpy(sampler, optarg);
      break;
    case 'b':
      tenblock = 1;
      break;
    case 'h':
    default :
      printf("Usage:  %s [-l user] [-r host] [-s sampler] [-b] [-h] [id_name]\
\n", proc);
      exit(2);
    }
  if (optind < argc) strncpy(ID, argv[optind], sizeof(ID));
  if (!ID[0]) strcpy(ID, proc);
  fd = popen("hostname -f", "r");
  fgets(localhost, sizeof(localhost), fd);
  pclose(fd);
  localhost[strlen(localhost)-1] = 0;
  if (host[0] == 0 || !strcmp(host, localhost)) { /* initiate local sampler */
    /* discard SIGINT at this stage, so as not to pass SIGINT to sub-proc. */
    signal(SIGINT, SIG_IGN); 
    sprintf(s, sampler, ID);
    if ((fd = popen(s, "r")) == NULL) {fputs("popen error" ,stderr); exit(2);}
  } else {                                       /* initiate remote sampler */
    struct servent *serv;
    char  *rhost = (char *)host;
    if (isatty(0)) {       /* invoked from terminal */
      sprintf(s, "Password (%s@%s): ", user, host);
      strcpy(pwd, getpass(s));
    } else {               /* invoked as subprocess */
      printf("Password (%s@%s): ", user, host);
      gets(pwd);
    }
    if ((serv = getservbyname("exec", "tcp")) == NULL)
      {fputs("exec/tcp: service not available", stderr); exit(2);}
    sprintf(s, sampler, ID);
    if ((sd = rexec((char **)&rhost, serv->s_port, user,
		    pwd, s, (int *)NULL)) == -1)
      {fputs("rexec fail", stderr); exit(2);}
    fd = fdopen(sd, "r");
  }
  setvbuf(fd, (char *)NULL, _IOFBF, HSM_BLK_SIZE*sizeof(short));
  signal(SIGINT, sighandler);
  i = SCL_NUM_DATA; 
  hstini_(ID, &i, strlen(ID));
  while (1) {
    if (fread(buffer, sizeof(short), HSM_BLK_SIZE, fd) == HSM_BLK_SIZE)
      {if (blockman()) break;}
    else {
      if (feof(fd)) break;
      usleep(10000L);              /* trap for SysV-style signal processing, */
      if (interrupt) interrupt = 0;/* which aborts system calls at signal. */
      else {if (*(char *)buffer == '#') fputs((char *)buffer, stderr); break;}
    }
  }
  if (!strcmp(host, localhost)) pclose(fd);
  else {fclose(fd); shutdown(sd, 2); close(sd);}
  if (!summary_out) summary();
  hstend_(scaler);
  exit(0);
}

/* dummy MAIN routine for libf2c.so */

void MAIN__(){}

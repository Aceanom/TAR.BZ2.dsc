/*
 *  "libtclshm.so"
 *
 *   creates a tcl command : crashm
 *
 *   its subcommands:
 *
 *      attach     -- attach shared memory and   link variables
 *      detach     -- detach shared memory and unlink variables
 *
 */

#include <sys/types.h>
#include <sys/ipc.h>
#include <sys/shm.h>
#include <unistd.h>
#include <string.h>
#include <tcl.h>
#include <svipc.h>
#include "crashm.h"

extern int Svipc_LinkVar
(Tcl_Interp *interp, char *varName, char *addr, int type, int elements);
extern int Svipc_UnlinkVar
(Tcl_Interp *interp, char *varName);
extern int Svipc_LinkedVarWritable
(Tcl_Interp *interp, char *varName, int writable);

static int     shmid;
static CRASHM *shmp;

int Tclshm_Init ( Tcl_Interp *interp )
{
  extern int crashmCmd _ANSI_ARGS_(( ClientData clientData, 
                                     Tcl_Interp *interp, 
                                     int argc, char *argv[] ));
  Tcl_CreateCommand(interp, "crashm", (Tcl_CmdProc *)crashmCmd,
                    (ClientData) NULL, (Tcl_CmdDeleteProc *)NULL );
  return TCL_OK;
}

#define I_LinkVar(name,addr,elem) \
Svipc_LinkVar(interp, name, (char *)&shmp->addr, \
TCL_LINK_INT|TCL_LINK_READ_ONLY, elem)
#define S_LinkVar(name,addr) \
addr[0] = shmp->addr; \
Svipc_LinkVar(interp, name, (char *)addr, \
TCL_LINK_STRING|TCL_LINK_READ_ONLY, 0)

static char *sta_time[1], *sto_time[1], *pri_time[1],
            *sta_date[1], *sto_date[1], *pri_date[1],
            *comment[1], *sampler_name[MAX_SAMPLERS][1];

int crashmCmd _ANSI_ARGS_(( ClientData clientData, 
			   Tcl_Interp *interp, 
			   int argc, char *argv[] )) 
{
  int   i;
  char  s[40];
  if (*argv[1] == 'a' && !strcmp(argv[1], "attach")) {
    if ((shmid = shmget(SHMKEY, sizeof(CRASHM), 0400)) == -1) {
      Tcl_SetResult(interp, "Error: cannot get shared memory", TCL_STATIC);
      return TCL_ERROR;}
    shmp = (CRASHM *)shmat(shmid, 0, 0);
    I_LinkVar("Scaler"    , scaler  , SCL_NUM_DATA);
    I_LinkVar("Run_No"    , runno   , 1);
    S_LinkVar("Start_Time", sta_time);
    S_LinkVar("Stop_Time" , sto_time);
    S_LinkVar("Print_Time", pri_time);
    S_LinkVar("Start_Date", sta_date);
    S_LinkVar("Stop_Date" , sto_date);
    S_LinkVar("Print_Date", pri_date);
    S_LinkVar("Comment"   , comment );
    I_LinkVar("Block_No"  , nblock  , 1);
    I_LinkVar("Bad_Block" , badblock, 1);
    I_LinkVar("Mag_Tape"  , mtape   , 1);
    I_LinkVar("MT_Block"  , mtblock , 1);
    for (i = 0; i < MAX_SAMPLERS; i++) {
      sprintf(s, "Sampler(%d,pid)", i);
      I_LinkVar(s, sampler[i].pid, 1);
      sprintf(s, "Sampler(%d,name)", i);
      sampler_name[i][0] = shmp->sampler[i].name;
      Svipc_LinkVar(interp, s, (char *)sampler_name[i], 
		    TCL_LINK_STRING|TCL_LINK_READ_ONLY, 0);
      sprintf(s, "Sampler(%d,block)", i);
      I_LinkVar(s, sampler[i].block, 1);
    }
    sprintf(s, "%d", MAX_SAMPLERS);
    Tcl_SetVar(interp, "MAX_SAMPLERS", s, TCL_GLOBAL_ONLY);
    sprintf(s, "%d", HSM_BLK_SIZE*sizeof(short));
    Tcl_SetVar(interp, "BLOCK_SIZE", s, TCL_GLOBAL_ONLY);
    return TCL_OK;
  }

  if (*argv[1] == 'd' && !strcmp(argv[1], "detach")) {
    Svipc_UnlinkVar(interp, "Scaler"    );
    Svipc_UnlinkVar(interp, "Run_No"    );
    Svipc_UnlinkVar(interp, "Start_Time");
    Svipc_UnlinkVar(interp, "Stop_Time" );
    Svipc_UnlinkVar(interp, "Print_Time");
    Svipc_UnlinkVar(interp, "Start_Date");
    Svipc_UnlinkVar(interp, "Stop_Date" );
    Svipc_UnlinkVar(interp, "Print_Date");
    Svipc_UnlinkVar(interp, "Comment"   );
    Svipc_UnlinkVar(interp, "Block_No"  );
    Svipc_UnlinkVar(interp, "Bad_Block" );
    Svipc_UnlinkVar(interp, "Mag_Tape"  );
    Svipc_UnlinkVar(interp, "MT_Block"  );
    for (i = 0; i < MAX_SAMPLERS; i++) {
      sprintf(s, "Sampler(%d,pid)"  , i); Svipc_UnlinkVar(interp, s);
      sprintf(s, "Sampler(%d,name)" , i); Svipc_UnlinkVar(interp, s);
      sprintf(s, "Sampler(%d,block)", i); Svipc_UnlinkVar(interp, s);
    }
    shmdt((char *)shmp);
    return TCL_OK;
  }

  Tcl_SetResult(interp, "Error: invalid subcommand", TCL_STATIC);
  return TCL_ERROR;
}

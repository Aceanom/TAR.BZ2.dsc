/*
 *  sampler -- MARS raw-data sampler
 */

#include <sys/types.h>
#include <sys/ipc.h>
#include <sys/shm.h>
#include <sys/sem.h>
#include <fcntl.h>
#include <stdlib.h>
#include <stdio.h>
#include <unistd.h>
#include <string.h>
#include <signal.h>
#include <sys/stat.h>
#include "hsm_conf.h"
#include "crashm.h"

int     shmid, semid, sem_buffer, sem_sample;
CRASHM *shmp;

unsigned short buffer[HSM_BLK_SIZE];

int main(int argc, char *argv[])
{
  int    rp, bp, ID;
  struct sembuf semcmd;
  if ((shmid = shmget(SHMKEY, sizeof(CRASHM), 0600)) == -1)
    {puts("# Cannot get shared memory"); exit(2);}
  if ((semid = semget(SEMKEY, SEM_NUM, 0600)) == -1 ||
      (sem_buffer = semget(SEM_BUFFER, CRA_BLK_NUM, 0600)) == -1 ||
      (sem_sample = semget(SEM_SAMPLE, CRA_BLK_NUM, 0600)) == -1)
    {puts("# Cannot get semaphore"); fflush(stdout); exit(2);}
  shmp = (CRASHM *)shmat(shmid, 0, 0);
  for (ID = 0; ID < MAX_SAMPLERS; ID++) {
    if (!shmp->sampler[ID].pid) {
      shmp->sampler[ID].pid = (int)getpid();
      if (argc > 1 && sizeof(shmp->sampler[ID].name) > strlen(argv[1]))
	strcpy(shmp->sampler[ID].name, argv[1]);
      else
	sprintf(shmp->sampler[ID].name, "Analyzer#%2.2d", ID);
      shmp->sampler[ID].block = 0;
      break;}
  }
  if (ID == MAX_SAMPLERS)
    {puts("# Too many samplers."); shmdt((char *)shmp); exit(2);}
//signal(SIGINT, SIG_IGN);
  setvbuf(stdout, (char *)NULL, _IOFBF, HSM_BLK_SIZE*sizeof(short));
  for (rp = 0; !feof(stdout); rp++) {
    if (shmp->wp < rp) sem_op(semid, semcmd, sem_newdat, -1);
    if (shmp->acquire < 0) goto EXIT;
    if (shmp->wp < rp) rp = 0; /* pointer has been reset while waiting */
    if (shmp->wp - rp >= CRA_BLK_NUM) rp = shmp->wp - CRA_BLK_NUM + 1;
    bp = rp % CRA_BLK_NUM;
    sem_op(sem_buffer, semcmd, bp,  0); /* wait if xfer is active */
    sem_op(sem_sample, semcmd, bp,  1); /* lock buffer */
    memcpy(buffer, shmp->buffer[bp],
	   sizeof(short)*HSM_BLK_SIZE); /* copy data to local buffer */
    sem_op(sem_sample, semcmd, bp, -1); /* free buffer */
    if (HSM_BLK_ID(buffer) != HSM_BID_BAD) {
      fwrite(buffer, sizeof(short), HSM_BLK_SIZE, stdout);
      if (HSM_BID_VALID(HSM_BLK_ID(buffer))) shmp->sampler[ID].block++;
    }
  }
 EXIT:
  shmp->sampler[ID].pid = 0;
  shmdt((char *)shmp);
  exit(0);
}

#include <stdio.h>
#include <f2c.h>

integer rename_(oldname, newname, oldname_len, newname_len)
register char *oldname;
register char *newname;
ftnlen oldname_len;
ftnlen newname_len;
{
    char oldnam[255], newnam[255];
    register char *bp, *blast;

    blast = oldnam + (oldname_len < 255 ? oldname_len : 255);
    for (bp = oldnam ; bp<blast && *oldname!='\0' && *oldname!=' ' ; )
      *bp++ = *oldname++;
    *bp = '\0';

    blast = newnam + (newname_len < 255 ? newname_len : 255);
    for (bp = newnam ; bp<blast && *newname!='\0' && *newname!=' ' ; )
      *bp++ = *newname++;
    *bp = '\0';

    return rename(oldnam,newnam);
}

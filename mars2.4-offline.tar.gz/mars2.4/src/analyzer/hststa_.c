#include "analyzer.h"

void hststa_(char *runno, char *comment, int lrunno, int lcomment)
{
}

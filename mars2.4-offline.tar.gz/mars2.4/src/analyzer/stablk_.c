#include "analyzer.h"

int stablk_(unsigned int scaler[])
{
  return 0;
}

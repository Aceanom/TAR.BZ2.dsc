#include <stdio.h>
#include "analyzer.h"

int  usrast_()
{
  printf("Interrupt !  Abort program (y/[n]) ? ");
  return (getchar() == (int)'y');
}

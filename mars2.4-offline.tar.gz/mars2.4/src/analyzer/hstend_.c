#include "analyzer.h"

void hstend_(unsigned int *scaler)
{
}

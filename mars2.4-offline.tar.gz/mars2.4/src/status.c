/*
 *  status -- MARS status display
 */

#include <sys/types.h>
#include <sys/ipc.h>
#include <sys/shm.h>
#include <fcntl.h>
#include <stdlib.h>
#include <stdio.h>
#include <unistd.h>
#include <signal.h>
#include <sys/stat.h>
#include <time.h>
#include <string.h>
#include "hsm_conf.h"
#include "crashm.h"

#define CLS     "\x1b[2J"
#define HOME    "\x1b[H"
#define CLREOL  "\x1b[K"
#define BOLD    "\x1b[1m"
#define ULINE   "\x1b[4m"
#define REVERSE "\x1b[7m"
#define NORMAL  "\x1b[m"
#define INVISBL "\x1b[?25l"
#define VISIBLE "\x1b[?25h"

int     shmid;
CRASHM *shmp;

void interrupt()
{
  shmdt((char *)shmp);
  printf("\n%s", VISIBLE);
  exit(0);
}

int main(int argc, char *argv[])
{
  double BI_UNIT=0.1; /* 0.1 nC/pulse for ORTEC 439 */
  double CLOCKHZ=1000.0; /* 1 kHz clock generator */
  int    SLEEP=3, blink=0;
  int    SCL_CHAN=(SCL_NUM_DATA<4*12)?SCL_NUM_DATA:SCL_NUM_DATA/4;
  int    prev[4]={0,0,0,0}, nblock=0, sampler[MAX_SAMPLERS];
  double blksize=HSM_BLK_SIZE*sizeof(short)/1024.0;
  char  *scl_name[4]={"Clock", "BeamInt.", "Event", "Trigger"};
  char  *acquire [2]={"         ", "ACQUIRING"};
  char  *record  [2]={"         ", "RECORDING"};
  char  *reverse [2]={BOLD, REVERSE};
  char   option;
  while ((option = getopt(argc, argv, "c:b:s:i:h")) != -1)
    switch (option) {
    case 'c': CLOCKHZ = atof(optarg); break;
    case 'b': BI_UNIT = atof(optarg); break;
    case 's': SCL_CHAN = atoi(optarg); break;
    case 'i': SLEEP = atoi(optarg); break;
    default :
    case 'h': printf("Usage: %s [option]\n\
	-c %sx%s : frequency of clock generator (default =%8.1f Hz)\n\
	-b %sx%s : B.I. charge per pulse (default =%5.2f nano Coulomb)\n\
	-s %sn%s : scaler channles per module (default = %d channels)\n\
	-i %sn%s : update interval in sec (default = %d sec)\n\
	-h   : show this message\n\
", argv[0], ULINE, NORMAL, CLOCKHZ , ULINE, NORMAL, BI_UNIT,
	    ULINE, NORMAL, SCL_CHAN, ULINE, NORMAL, SLEEP);
      exit(2);
    }
  if ((shmid = shmget(SHMKEY, sizeof(CRASHM), 0400)) == -1)
    {puts("# Cannot get shared memory"); exit(2);}
  shmp = (CRASHM *)shmat(shmid, 0, 0);
  signal(SIGINT, interrupt);
  bzero(sampler, MAX_SAMPLERS*sizeof(int));
  printf("%s%s%s", INVISBL, HOME, CLS);
  for (;;) {
    int    i, j, n=0, sum[4], diff[4], dblock=shmp->nblock-nblock;
    time_t tp=time(NULL);
    char   stime[20];
    unsigned short *p = shmp->buffer[shmp->wp % CRA_BLK_NUM];
    strftime(stime, 20, "%H:%M:%S  %d-%b-%y", localtime(&tp));
    printf("%s%s%24s%s%25s%s\n", HOME,
	   ULINE, " ", "Data Acquisition Status Monitor", " ", NORMAL);
    printf("%sRUN-%4.4d%s   Start => %8s   Stop => %8s    Print => %s\n",
	   BOLD, shmp->runno, NORMAL, 
	   shmp->sta_time, shmp->sto_time, stime);
    printf("%s%s\n", shmp->comment, CLREOL);
    i = (shmp->path[0] != 0);
    printf("  %s%s%s    %s%s%s %s%s\n",
	   reverse[blink*shmp->acquire], acquire[shmp->acquire], NORMAL, 
	   reverse[(blink=1-blink)*i], record[i], NORMAL,
	   shmp->path, CLREOL);
    printf(" %s %d blocks ( %d bad ) %6.1f MB",
	   CLREOL, shmp->nblock, shmp->badblock, shmp->nblock*blksize/1024.0);
    if (shmp->mtape)
      printf("  ( %6.1f MB on tape )", shmp->mtblock*blksize/1024.0);
    puts(CLREOL);
//  printf("%sRate:%s%35s", ULINE, NORMAL, " ");
    printf("%sRate:%s%15s%8s%12s", ULINE, NORMAL, "diff.", "mean", " ");
    printf("%sAnalyzer:%s%12s  name\n", ULINE, NORMAL, "pid");
    for (i = 0; i < 4; i++) {
      sum[i] = 0;
      for (j = i; j < SCL_NUM_DATA; j += SCL_CHAN)
	sum[i] += shmp->scaler[j];
      diff[i] = sum[i] - prev[i];
      prev[i] = sum[i];
    }
    printf("  Beam Int.  %7.3f (%7.3f) nA    ",
	   (diff[0]>0)?(diff[1]*BI_UNIT)/(diff[0]/CLOCKHZ):0.0,
	   (sum [0]>0)?(sum [1]*BI_UNIT)/(sum [0]/CLOCKHZ):0.0);
    while (n < MAX_SAMPLERS && shmp->sampler[n].pid == 0) n++;
    if (n < MAX_SAMPLERS) {
      printf("%s   %5.1f (%5.1f) %%%6d  %s\n", CLREOL,
	     (dblock>0)?100.0*(shmp->sampler[n].block-sampler[n])/dblock:0.0,
	     (shmp->nblock>0)?100.0*shmp->sampler[n].block/shmp->nblock:0.0,
	     shmp->sampler[n].pid, shmp->sampler[n].name);
      n++;
    } else printf("%s\n", CLREOL);
    printf("  Evnt Rate  %7.1f (%7.1f) cps   ",
	   (diff[0]>0)?(diff[2]*1.0)/(diff[0]/CLOCKHZ):0.0,
	   (sum [0]>0)?(sum [2]*1.0)/(sum [0]/CLOCKHZ):0.0);
    while (n < MAX_SAMPLERS && shmp->sampler[n].pid == 0) n++;
    if (n < MAX_SAMPLERS) {
      printf("%s   %5.1f (%5.1f) %%%6d  %s\n", CLREOL,
	     (dblock>0)?100.0*(shmp->sampler[n].block-sampler[n])/dblock:0.0,
	     (shmp->nblock>0)?100.0*shmp->sampler[n].block/shmp->nblock:0.0,
	     shmp->sampler[n].pid, shmp->sampler[n].name);
      n++;
    } else printf("%s\n", CLREOL);
    printf("  Live Time  %7.1f (%7.1f) %%     ",
	   (diff[2]>0)?(100.0*diff[3])/(diff[2]*1.0):0.0,
	   (sum [2]>0)?(100.0*sum [3])/(sum [2]*1.0):0.0);
    while (n < MAX_SAMPLERS && shmp->sampler[n].pid == 0) n++;
    if (n < MAX_SAMPLERS) {
      printf("%s   %5.1f (%5.1f) %%%6d  %s\n", CLREOL,
	     (dblock>0)?100.0*(shmp->sampler[n].block-sampler[n])/dblock:0.0,
	     (shmp->nblock>0)?100.0*shmp->sampler[n].block/shmp->nblock:0.0,
	     shmp->sampler[n].pid, shmp->sampler[n].name);
      n++;
    } else printf("%s\n", CLREOL);
    printf("  Data Rate  %7.1f (%7.1f) kB/sec",
	   (diff[0]>0)?((shmp->nblock-nblock)*blksize)/(diff[0]/CLOCKHZ):0.0,
	   (sum [0]>0)?( shmp->nblock        *blksize)/(sum [0]/CLOCKHZ):0.0);
    while (n < MAX_SAMPLERS && shmp->sampler[n].pid == 0) n++;
    if (n < MAX_SAMPLERS) {
      printf("%s   %5.1f (%5.1f) %%%6d  %s\n", CLREOL,
	     (dblock>0)?100.0*(shmp->sampler[n].block-sampler[n])/dblock:0.0,
	     (shmp->nblock>0)?100.0*shmp->sampler[n].block/shmp->nblock:0.0,
	     shmp->sampler[n].pid, shmp->sampler[n].name);
      n++;
    } else printf("%s\n", CLREOL);
    nblock = shmp->nblock;
    for (i = 0; i < MAX_SAMPLERS; i++) sampler[i] = shmp->sampler[i].block;
    printf("%sScaler:%s   ", ULINE, NORMAL);
    for (i = 0; i < 4; i++) printf("%15s%1d", "mode#", i); puts("");
    for (i = 0; i < 4; i++) {
      printf("  %-8s", scl_name[i]);
      for (j = i; j < SCL_NUM_DATA; j += SCL_CHAN)
	printf("%16d", shmp->scaler[j]);
      puts("");
    }
    printf("%sBuffer[%2d]:%s\n", ULINE, shmp->wp%CRA_BLK_NUM, NORMAL);
    for (i = 0; i < 16*8; i++) printf(" %4.4X", *p++);
    fflush(stdout);
    sleep(SLEEP);
  }
}

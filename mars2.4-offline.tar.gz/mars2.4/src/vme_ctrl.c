#include <stdio.h>
#include <unistd.h>
#include <string.h>
#include <errno.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <sys/ioctl.h>
#include "vmehb_ioctl.h"

#define CMD_ON          1
#define CMD_OFF         2
#define CMD_RESET       3
#define CMD_UNMAP       4
#define CMD_TRACE       5
#define CMD_HELP       99
const struct {char *name; int min, key; }
cmd_table[] = {
  {"online"  ,  2, CMD_ON    },
  {"offline" ,  2, CMD_OFF   },
  {"reset"   ,  1, CMD_RESET },
  {"unmap"   ,  1, CMD_UNMAP },
  {"trace"   ,  1, CMD_TRACE },
  {"help"    ,  1, CMD_HELP  },
  {""        ,  0, 0         }
};

int check_cmd(char *arg)
{
  char s[256]; int i, n;
  while (*arg == ' ') arg++;
  for (n = 0; *arg != ' ' && *arg != 0; arg++)
    s[n++] = ((*arg < 'a') ? *arg + ' ' : *arg); s[n] = 0;
  for (i = 0; cmd_table[i].key != 0; i++) {
    if (n >= cmd_table[i].min && n <= strlen(cmd_table[i].name))
      if (!strncmp(s, cmd_table[i].name, n)) return cmd_table[i].key;
  }
  return -EINVAL;
}

int main(int argc, char *argv[])
{
  int    fd, i, status;
  if (geteuid()) {puts("Only root can run this command."); exit(2);}
  if ((fd = open("/dev/vme32d32", O_RDWR)) == -1) {perror(argv[1]); exit(2);}
  if (argc == 1) goto help;
  switch (check_cmd(argv[1])) {
  case CMD_ON:
    ioctl(fd, VME_CRATE_ON, &status);
    if (errno) {perror("VME hardware may be off "); close(fd); exit(1);}
    break;
  case CMD_OFF:
    ioctl(fd, VME_CRATE_OFF, &status);
    break;
  case CMD_RESET:
    printf("Resetting (wait a second) ... "); fflush(stdout);
    ioctl(fd, VME_RESET, 0);
    if (errno) {perror("\nVME hardware may be off "); close(fd); exit(1);}
    printf("done.\n");
    break;
  case CMD_UNMAP:
    ioctl(fd, VME_CLEAR_MAPS, 0);
    break;
  case CMD_TRACE:
    ioctl(fd, VME_TRACE_INFO, 0);
    break;
  case CMD_HELP:
    goto error;
  default:
    printf("%s: illigal command (%s).\n", argv[0], argv[1]);
    goto error;
  }
  close(fd); exit(0);
 error:
  close(fd);
 help:
  printf("%s: available commands are...\n", argv[0]);
  for (i = 0; cmd_table[i].key != 0; i++)
    printf("\t%s\n", cmd_table[i].name);
  puts("");
  exit(1);
}

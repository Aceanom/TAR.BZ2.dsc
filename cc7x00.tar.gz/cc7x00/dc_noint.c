/*                                                          */
/*         ... ... ... <<< dc_noint.c >>> ... ... ...       */
/*                                                          */
/*              A pseudo interrupt handler of               */
/*                                                          */
/*                      A device driver                     */
/*          for Toyo CC/7x00 CAMAC crate controller         */
/*                on Linux 2.0 & 2.2 kernels                */
/*                                                          */

/*
 *  Subsidiary function called at enabling interrupt
 */
static void dc_int_on() { }

/*
 *  Subsidiary function called at disabling interrupt
 */
static void dc_int_off() { }

/*
 *  Main function of interrupt handler
 */
static void dc_int(int irq, void *dev_id, struct pt_regs *regs) {}

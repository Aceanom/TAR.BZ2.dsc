/*                                                          */
/*            ... ... ... <<< dc.c >>> ... ... ...          */
/*                                                          */
/*                      A device driver                     */
/*          for Toyo CC/7x00 CAMAC crate controller         */
/*                on Linux 2.0 & 2.2 kernels                */
/*                                                          */

#include <linux/kernel.h>
#include <linux/sched.h>
#include <linux/tty.h>
#include <linux/signal.h>
#include <linux/errno.h>
#include <linux/fs.h>
#include <linux/ioport.h>
#include <asm/io.h>
#include <asm/system.h>
#include <asm/irq.h>
#ifdef MODULE
#include <linux/module.h>
#define DC_INIT_RET(x)  return x
#else
#define MOD_INC_USE_COUNT
#define MOD_DEC_USE_COUNT
#define DC_INIT_RET(x)  return kmem_start
#endif

#include <linux/version.h>
#if   LINUX_VERSION_CODE >= 0x020100
#  include <asm/uaccess.h>
#  include <linux/poll.h>
#  define LINUX_2_2
#  define relse_t         int
#  define uint_t          unsigned int
#  define DC_MINOR        MINOR(file->f_dentry->d_inode->i_rdev)
#  if LINUX_VERSION_CODE >= 0x020300
#    define LINUX_2_4
#  else
#    define DECLARE_WAIT_QUEUE_HEAD(name) struct wait_queue *name=NULL
#  endif
#elif LINUX_VERSION_CODE >= 0x020000
#  include <asm/segment.h>
#  define LINUX_2_0
#  define relse_t         void
#  define DC_MINOR        MINOR(inode->i_rdev)
#  define copy_from_user  memcpy_fromfs
#  define copy_to_user    memcpy_tofs
#  define signal_pending(current)  (current->signal & ~current->blocked)
#else
#  error "This kernel is too old: not supported by this file"
#endif

#include "dc.h"
#include "dc_aux.h"

static char   dc_dev_id[] = HARDWARE;
static DECLARE_WAIT_QUEUE_HEAD(wait_que);
static int    wakeups     = 0;

#define EV_MAX 65536
static int   dc_int_count, dc_int_lost;
static unsigned short      dc_last_data;
static int   dc_rp=0,      dc_wp=0;
static int   dc_ev_max=EV_MAX;
static unsigned short      dc_evbuff[EV_MAX];

static int     dc_open   (struct inode *inode, struct file *file) {
  MOD_INC_USE_COUNT;
  return 0; 
}

static relse_t dc_release(struct inode *inode, struct file *file) {
  MOD_DEC_USE_COUNT;
#if   defined(LINUX_2_2)
  return 0;
#endif
}

#if   defined(LINUX_2_2)
static ssize_t dc_read   (struct file *file, char *buffer, 
					size_t count, loff_t *fpos) {
#elif defined(LINUX_2_0)
static int     dc_read   (struct inode *inode, struct file *file, 
					char *buffer, int count) {
#endif
  int nbytes=0;
  if((dc_wp==dc_rp) && (DC_MINOR==0)) {
    wakeups++;
    interruptible_sleep_on(&wait_que);
    if(wakeups) wakeups--;
    if(signal_pending(current)) return -ERESTARTNOINTR;
  }
  nbytes=(dc_wp-dc_rp)*sizeof(short);
  if(nbytes>count) nbytes=((count)>>1)<<1;
  if((dc_rp%EV_MAX)*sizeof(short)+nbytes>EV_MAX*sizeof(short)) {
    copy_to_user((void *)buffer,
		 &dc_evbuff[dc_rp%EV_MAX],
		 (EV_MAX-dc_rp%EV_MAX)*sizeof(short));
    copy_to_user((void *)(buffer+(EV_MAX-dc_rp%EV_MAX)*sizeof(short)),
		 dc_evbuff,
		 nbytes-(EV_MAX-dc_rp%EV_MAX)*sizeof(short));
  } else {
    copy_to_user((void *)buffer,&dc_evbuff[dc_rp%EV_MAX],nbytes);
  }
  dc_rp+=nbytes/sizeof(short);
  return nbytes;
}

#if   defined(LINUX_2_2)
static ssize_t dc_write  (struct file * file, const char * buffer,
					size_t count, loff_t *fpos) {
#elif defined(LINUX_2_0)
static int     dc_write  (struct inode * inode, struct file * file, 
					const char * buffer, int count) {
#endif
  return 0;
}

#if   defined(LINUX_2_2)
static uint_t  dc_poll   (struct file * file, poll_table * wait) {
  poll_wait(file,&wait_que,wait);
  if(dc_wp<=dc_rp) return (POLLIN|POLLRDNORM);
  return 0;
}
#elif defined(LINUX_2_0)
static int     dc_select (struct inode * inode, struct file * file,
				int sel_type, select_table * wait) {
  switch(sel_type) {
  case SEL_IN:  
    if(dc_wp<=dc_rp) {
      select_wait(&wait_que,wait);
      return 0;
    }
    break;
  case SEL_OUT: break;
  case SEL_EX: {
    int lampat;
    DC_AUX_LAMP(lampat);
    if(lampat==0) {
      select_wait(&wait_que,wait);
      return 0;
    }
    break;
  }
  default: break;
  }
  return 1;
}
#endif

#include "dc_int.c"

static int     dc_ioctl  (struct inode *inode, struct file *file,
				unsigned int cmd, unsigned long arg) {
  int   ans=0, lampat, i;
  unsigned long flags;
  switch(cmd) {
  case DC_INITIAL:
    if (arg >= MAX_CRATE) {ans=-1; break;}
    save_flags(flags);
    cli();
    DC_AUX_CRATE(arg);
    DC_AUX_DISI;
    if(DC_AUX_ONL) ans=0; else ans=-1;
    restore_flags(flags);
    break;
  case DC_Z: 
    save_flags(flags);
    cli();
    DC_AUX_Z;
    ans=dc_cycle_wait(255);
    restore_flags(flags);
    break;
  case DC_C: 
    save_flags(flags);
    cli();
    DC_AUX_C;
    ans=dc_cycle_wait(255);
    restore_flags(flags);
    break;
  case DC_I:
    save_flags(flags);
    cli();
    DC_AUX_I(arg);
    restore_flags(flags);
    break;
  case DC_L_P:
    DC_AUX_LAMP(lampat);
    put_user(lampat,(long *)arg);
    break;
  case DC_L_E:
    DC_AUX_LAMP(lampat);
    for(i=0;i<24;i++) if((lampat/(1<<i))%2) goto lamhit;
  lamhit:
    if(i<24) i++; else i=0;
    put_user(i,(long*)arg);
    break;
  case DC_CYCLE: {
    DCCycle dcc;
    copy_from_user(&dcc,(void *)arg,sizeof(DCCycle));
    save_flags(flags);
    cli();
    DC_AUX_NAF(dcc.n,dcc.a,dcc.f);
    if((dcc.f&0x18)==0x10) DC_AUX_WRITE(dcc.data);
    DC_AUX_GO;
    ans=dc_cycle_wait(255);
    dcc.stat=DC_AUX_STAT(DC_IN_CSR);
    if((dcc.f&0x18)==0x00) DC_AUX_READ(dcc.data);
    restore_flags(flags);
    copy_to_user((void *)arg,&dcc,sizeof(dcc));
    break;
  }
  case DC_INTTST: {
    struct pt_regs regs;
    save_flags(flags);
    cli();
    dc_int(IRQ,dc_dev_id,&regs);
    restore_flags(flags);
    break;
  }
  case DC_INTON:
    save_flags(flags);
    cli();
    dc_int_on();
    dc_int_count=0;
    DC_AUX_ENAI;
    restore_flags(flags);
    break;
  case DC_INTOFF:
    save_flags(flags);
    cli();
    DC_AUX_DISI;
    dc_int_off();
    restore_flags(flags);
    wake_up_interruptible(&wait_que);
    /* wakeups=0; */
    break;
  case DC_INTCLR:
    if (wakeups) wake_up(&wait_que);
    dc_rp=0;
    dc_wp=0;
    dc_int_lost=0;
    dc_int_count=0;
    break;
  case DC_INTCNT:
    put_user(dc_int_count,(long*) arg);
    break;
  case DC_INTLOS:
    put_user(dc_int_lost,(long*) arg);
    break;
  case DC_INTWRD:
    put_user(dc_last_data,(long*) arg);
    break;
  case DC_INTEOF:
    dc_evbuff[(dc_wp++)%EV_MAX]=0xffff;
    if (wakeups) wake_up(&wait_que);
    break;
  case DC_USERST:
    while(MOD_IN_USE) MOD_DEC_USE_COUNT;
    MOD_INC_USE_COUNT;
    break;
  default: break;
  }
  return ans;
}

static struct file_operations dc_fops = {
# if   defined(LINUX_2_4)
  THIS_MODULE /* module owner */,
# endif
  NULL	/* dc_lseek */,
  dc_read,
  dc_write,
  NULL	/* dc_readdir */,
# if   defined(LINUX_2_2)
  dc_poll,
# elif defined(LINUX_2_0)
  dc_select,
# endif
  dc_ioctl,
  NULL	/* dc_mmap */,
  dc_open,
# if   defined(LINUX_2_2)
  NULL	/* dc_flush */,
# endif
  dc_release
};	/* if not defined, replace to NULL. */

#ifndef MODULE
unsigned long dc_init(unsigned long kmem_start) {
#else
int init_module(void) {
#endif
  printk(DEVICE ": %s CAMAC crate controller.\n",HARDWARE);
# ifdef CC7700PCI
  if (dc_pci_config()) DC_INIT_RET(-ENODEV);
# endif
  printk(DEVICE ": IRQ = %d,  I/O BASE = 0x%x\n",IRQ,PNO);
  printk(DEVICE ": buffer size is %d bytes\n", dc_ev_max*sizeof(short));
  if (register_chrdev(DC_NO,DEVICE,&dc_fops)) {
    printk(DEVICE ": error -- cannot register to major device %d !\n",DC_NO);
    DC_INIT_RET(-ENODEV);
  }
  if (check_region(PNO,IO_REGION)) {
    printk(DEVICE ": error -- cannot register IOport %x !\n",PNO);
    unregister_chrdev(DC_NO,DEVICE);
    DC_INIT_RET(-ENODEV);
  }
  request_region(PNO,IO_REGION,DEVICE);
  if (request_irq(IRQ,dc_int,SA_INTERRUPT|SA_SHIRQ,HARDWARE,dc_dev_id)) {
    printk(DEVICE ": error -- cannot register IRQ %d !\n",IRQ);
    release_region(PNO,IO_REGION);
    unregister_chrdev(DC_NO,DEVICE);
    DC_INIT_RET(-ENODEV);
  }
  printk(DEVICE ": driver installed.\n");
  DC_INIT_RET(0);
}
#ifdef  MODULE
void cleanup_module(void) {
  printk(DEVICE ": driver removed.\n");
  free_irq(IRQ,dc_dev_id);
  release_region(PNO,IO_REGION);
  unregister_chrdev(DC_NO,DEVICE);
}
#endif

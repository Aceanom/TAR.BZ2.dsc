/*
 * "libtclcam.so"
 *
 *  Tcl library for CC/7x00 device driver
 *
 *  creates a tcl command : camac
 *
 *  its subcommands and return values:
 *
 *    crate   c        ; 0=online, -1=offline
 *    read    n a f v  ; Q X  (v must be variable name)
 *    write   n a f d  ; Q X
 *    naf     n a f    ; Q X
 *    lam              ; LAM pattern string (index 0 => n 1)
 *    Z
 *    initialize
 *    C
 *    clear
 *    I       i        ; i = 0 or 1
 *    inhibit i
 *   
 */

#include <fcntl.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <unistd.h>
#include <stdlib.h>
#include <sys/ioctl.h>
#include <string.h>
#include <stdio.h>
#include <tcl.h>
#include "dc.h"
#include "dc_aux.h"

static int     fd = 0;
static DCCycle dcc;
static char    result[32];
static char    QX[4][4]={"Q X", "X", "Q", ""};
static int     crate;

int Tclcam_Init ( Tcl_Interp *interp )
{
  char max_crate[2];
  extern int tclcamCmd _ANSI_ARGS_(( ClientData clientData, 
                                     Tcl_Interp *interp, 
                                     int argc, char *argv[] ));
  Tcl_CreateCommand(interp, "camac", tclcamCmd,
                    (ClientData) NULL, (Tcl_CmdDeleteProc *)NULL );
  sprintf(max_crate, "%1d", MAX_CRATE-1);
  Tcl_SetVar(interp, "MAX_CRATE", max_crate, TCL_GLOBAL_ONLY);
  return TCL_OK;
}

#define checkargc(narg,msg) \
if(argc!=narg){Tcl_SetResult(interp,msg,TCL_STATIC);return TCL_ERROR;}
#define checknaf(f1,f2) \
if ((dcc.n = atoi(argv[2])) <= 0 || dcc.n > 24 ||\
    (dcc.a = atoi(argv[3])) <  0 || dcc.a > 15 ||\
    (dcc.f = atoi(argv[4])) < f1 || dcc.f > f2) {\
   Tcl_SetResult(interp,"Error: invalid (n,a,f)",TCL_STATIC);\
   return TCL_ERROR;}

int tclcamCmd _ANSI_ARGS_(( ClientData clientData, 
			   Tcl_Interp *interp, 
			   int argc, char *argv[] )) 
{
  if (!fd) fd = open("/dev/dc", O_RDWR);

  if (*argv[1] == 'c' && !strcmp(argv[1], "crate")) {
    checkargc(3,"Error: crate number must be given.");
    if ((crate = atoi(argv[2])) < 0 || crate >= MAX_CRATE) {
      Tcl_SetResult(interp, "Error: invalid crate#", TCL_STATIC);
      return TCL_ERROR;
    }
    if (ioctl(fd, DC_INITIAL, crate)) {
      Tcl_SetResult(interp, "Error: camac off-line", TCL_STATIC);
      return TCL_ERROR;
    }
    return TCL_OK;
  }

  if (*argv[1] == 'r' && !strcmp(argv[1], "read")) {
    checkargc(6,"Error: n a f var must be given.");
    checknaf(0,7);
    ioctl(fd, DC_INITIAL, crate);
    if (ioctl(fd, DC_CYCLE, &dcc)) {
      Tcl_SetResult(interp, "Error: I/O time out", TCL_STATIC);
      return TCL_ERROR;
    }
    sprintf(result, "%ld", dcc.data);
    if (Tcl_SetVar(interp, argv[5], (char *)result, TCL_LEAVE_ERR_MSG)
	== NULL) return TCL_ERROR;
    Tcl_SetResult(interp, (char *)QX[(int)dcc.stat], TCL_STATIC);
    return TCL_OK;
  }

  if (*argv[1] == 'w' && !strcmp(argv[1], "write")) {
    checkargc(6,"Error: n a f data must be given.");
    checknaf(16,23);
    dcc.data = atol(argv[5]);
    ioctl(fd, DC_INITIAL, crate);
    if (ioctl(fd, DC_CYCLE, &dcc)) {
      Tcl_SetResult(interp, "Error: I/O time out", TCL_STATIC);
      return TCL_ERROR;
    }
    Tcl_SetResult(interp, (char *)QX[(int)dcc.stat], TCL_STATIC);
    return TCL_OK;
  }

  if (*argv[1] == 'n' && !strcmp(argv[1], "naf")) {
    checkargc(5,"Error: n a f must be given.");
    checknaf(0,31);
    ioctl(fd, DC_INITIAL, crate);
    if (ioctl(fd, DC_CYCLE, &dcc)) {
      Tcl_SetResult(interp, "Error: I/O time out", TCL_STATIC);
      return TCL_ERROR;
    }
    Tcl_SetResult(interp, (char *)QX[(int)dcc.stat], TCL_STATIC);
    return TCL_OK;
  }

  if (*argv[1] == 'l' && !strcmp(argv[1], "lam")) {
    unsigned long lam; int i;
    checkargc(2,"Error: extra argument.");
    ioctl(fd, DC_INITIAL, crate);
    if (ioctl(fd, DC_L_E, &lam)) {
      Tcl_SetResult(interp, "Error: I/O time out", TCL_STATIC);
      return TCL_ERROR;}
    for (i = 0; i < 24; i++,lam>>=1)
      if (lam & 1) result[i] = '1'; else result[i] = '0';
    result[24] = 0;
    Tcl_SetResult(interp, (char *)result, TCL_STATIC);
    return TCL_OK;
  }

  if ((*argv[1] == 'Z' && !strcmp(argv[1], "Z"))||
      (*argv[1] == 'i' && !strcmp(argv[1], "initialize"))) {
    checkargc(2,"Error: extra argument.");
    ioctl(fd, DC_INITIAL, crate);
    if (ioctl(fd, DC_Z, 0)) {
      Tcl_SetResult(interp, "Error: I/O time out", TCL_STATIC);
      return TCL_ERROR;
    } else return TCL_OK;
  }

  if ((*argv[1] == 'C' && !strcmp(argv[1], "C"))||
      (*argv[1] == 'c' && !strcmp(argv[1], "clear"))) {
    checkargc(2,"Error: extra argument.");
    ioctl(fd, DC_INITIAL, crate);
    if (ioctl(fd, DC_C, 0)) {
      Tcl_SetResult(interp, "Error: I/O time out", TCL_STATIC);
      return TCL_ERROR;
    } else return TCL_OK;
  }

  if ((*argv[1] == 'I' && !strcmp(argv[1], "I"))||
      (*argv[1] == 'i' && !strcmp(argv[1], "inhibit"))) {
    checkargc(3,"Error: 1 (=ON) or 0 (=OFF) must be given");
    ioctl(fd, DC_INITIAL, crate);
    ioctl(fd, DC_I, atoi(argv[2]));
    return TCL_OK;
  }

  Tcl_SetResult(interp, "Error: subcommand missing", TCL_STATIC);
  return TCL_ERROR;
}

#include <fcntl.h>

#include <sys/types.h>
#include <sys/ioctl.h>
#include <sys/wait.h>
#include <unistd.h>
#include <stdio.h>

#include "dc.h"

#define WAIT   10000L
#define REPEAT 20

int main(int argc, char *argv[])
{
  int fd, i, j;
  DCCycle dcc;
  if (argc < 2) {
    printf("LED station# = ");
    scanf("%d", &i);
  } else {
    sscanf(argv[1], "%d", &i);
  }
  printf("open      : %d\n", (fd = open("/dev/dc", O_RDWR)) );
  printf("DC_INITIAL: %d\n", ioctl(fd, DC_INITIAL, 0) );
  printf("DC_Z      : %d\n", ioctl(fd, DC_Z      , 0) );
  dcc.n    =  i;
  dcc.f    = 16;
  dcc.a    =  0;
  dcc.data =  3;
  for (i = 0; i < REPEAT; i++) {
    for (j = 0; j < 23; j++) {
      ioctl(fd, DC_CYCLE, &dcc);
      usleep(WAIT);
      dcc.data <<= 1;
    }
    for (j = 0; j < 23; j++) {
      ioctl(fd, DC_CYCLE, &dcc);
      usleep(WAIT);
      dcc.data >>= 1;
    }
  }
  close(fd);
  exit(0);
}

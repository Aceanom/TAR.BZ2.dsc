/*
    player -- DAQ raw-data analyzer in off-line mode
     (see "crashm.h" for available commands)
*/

#include <fcntl.h>
#include <stdio.h>
#include <unistd.h>
#include <signal.h>
#include <string.h>

#define  COMMANDER
#include "crashm.h"

extern void hstdef_();
extern void event1_(unsigned short *);
extern void hstend_();

#define MAX_EVL 2048

/* Signal handlers for Child Process */
static int loop=0;
void break_loop() {loop = 0;}
static unsigned long rwcnt=0, ancnt=0, ercnt=0;
void show_count() {
  printf("%ld %ld %ld\n", rwcnt, ancnt, ercnt); fflush(stdout);
  signal(SIGUSR2, show_count);
}

/* Signal handler for Parent Process */
static int acquire=0, opened=0;
void read_stop() {puts("<< STOPPED >>"); fflush(stdout); acquire = 0;}
void data_end () {puts("<< CLOSED >>" ); fflush(stdout); opened  = 0;}

#define gets(s) (fgets(s,sizeof(s),stdin)?s[strlen(s)-1]=0,s:NULL)
int main()
{
  int   pid, fdi[2], fdo[2];

  pipe(fdi); pipe(fdo);
  if ((pid = fork())) {
    /* Parent Process */
    FILE *fi, *fo;
    char  s[256], path[255];
    fi = fdopen(fdo[0], "r"); fo = fdopen(fdi[1], "w");
    while (gets(s)) {
      switch (check_cmd(s)) {
      case CMD_INITIALIZE:
	break;
      case CMD_RESET:
	fputs("RESET\n", fo); fflush(fo);
	break;
      case CMD_START:
	if (!opened) {
	  puts("# File not opened"); fflush(stdout);
	} else {
	  signal(SIGUSR1, read_stop);
	  fputs("START\n", fo); fflush(fo);
	  acquire = 1;
	}
	break;
      case CMD_STOP:
	kill(pid, SIGUSR1);
	break;
      case CMD_OPEN:
	gets(path);
	if (opened) {
	  puts("# Close file before opening new one"); fflush(stdout);
	} else {
	  fprintf(fo, "OPEN\n%s\n", path); fflush(fo);
	  fgets(s, sizeof(s), fi);
	  printf("<< COMMENT >>\n%s", s); fflush(stdout);
	  signal(SIGUSR2, data_end );
	  opened = 1;
	}
	break;
      case CMD_CLOSE:
	if (opened) {fputs("CLOSE\n", fo); fflush(fo);}
	break;
      case CMD_SCALER:
	gets(s); /* dummy input */
	break;
      case CMD_COUNT:
	kill(pid, SIGUSR2);
	fgets(s, sizeof(s), fi);
	printf("<< COUNT >>\n0 0 %s", s); fflush(stdout);
	break;
      case CMD_EXIT:
	goto EXIT;
      default:
	printf("# Illigal Command (%s).\n", s);
	fflush(stdout);
	break;
      }
    }
  } else {
    /* Child Process */
    char  s[256], path[256];
    int   fd=-1;
    unsigned short event[MAX_EVL];
#   define sizeof_event ((event[0]<2*MAX_EVL)?event[0]:2*MAX_EVL)-sizeof(short)
    hstdef_(); fflush(stdout);
    close(0); dup(fdi[0]); close(1); dup(fdo[1]);
    signal(SIGUSR2, show_count);
    while (gets(s)) {
      switch (check_cmd(s)) {
      case CMD_RESET:
	rwcnt = 0; ancnt = 0; ercnt = 0;
	break;
      case CMD_START:
	loop = 1; signal(SIGUSR1, break_loop);
	while (read(fd, &event, sizeof(short)) > 0) {
	  read(fd, &(event[1]), sizeof_event );
	  rwcnt++; event1_(event); ancnt++;
	  if (!loop) break;
	}
	signal(SIGUSR1, SIG_DFL);
	kill(getppid(), SIGUSR1);
	if (loop) {
	  loop = 0; close(fd); usleep(100000L);
	  kill(getppid(), SIGUSR2);
	}
	break;
      case CMD_OPEN:
	gets(path);
	fd = open(path, O_RDONLY);
	read(fd,   event    , sizeof(short)); 
	read(fd, &(event[1]), sizeof_event );
	puts(strncpy(s, (char *)(&(event[1])), 255)); fflush(stdout);
	break;
      case CMD_CLOSE:
	close(fd); kill(getppid(), SIGUSR2);
	break;
      }
    }
  }
 EXIT:
  kill(pid, SIGKILL);
  hstend_();
  exit(0);
}

/*                                                          */
/*            ... ... ... <<< dc.h >>> ... ... ...          */
/*                                                          */
/*                      Header file of                      */
/*                                                          */
/*                      A device driver                     */
/*          for Toyo CC/7x00 CAMAC crate controller         */
/*                on Linux 2.0 & 2.2 kernels                */
/*                                                          */

#ifndef DC_H
#define DC_H

/*
 *
 *  CAMAC DATA structure
 *
 */

typedef struct {
  char onoff;
} DCI;

typedef struct {
  long lamp;
} DCLP;

typedef struct {
  char  lame;
} DCLE;

typedef struct {
  char n , f, a, stat; long data;
} DCCycle;

typedef union {
  DCI        dci;
  DCLP       dclp;
  DCLE       dcle;
  DCCycle    dccycle;
} DCD;

/*
 *
 * IOCTL functions
 *
 * see 'linux/Documentation/ioctl-number.txt' for MAGIC nubmer
 *
 */

#define DC_IOC         'd'

#define DC_INITIAL     _IOW (DC_IOC, 10, long   )
#define DC_Z           _IO  (DC_IOC, 11         )
#define DC_C           _IO  (DC_IOC, 12         )
#define DC_I           _IOW (DC_IOC, 13, long   )
#define DC_L_P         _IOR (DC_IOC, 14, long   )
#define DC_L_E         _IOR (DC_IOC, 15, long   )
#define DC_CYCLE       _IOWR(DC_IOC, 16, DCCycle)

#define DC_INTTST      _IO  (DC_IOC, 30         )
#define DC_INTON       _IO  (DC_IOC, 31         )
#define DC_INTOFF      _IO  (DC_IOC, 32         )
#define DC_INTCLR      _IO  (DC_IOC, 33         )
#define DC_INTCNT      _IOR (DC_IOC, 34, long   )
#define DC_INTLOS      _IOR (DC_IOC, 35, long   )
#define DC_INTWRD      _IOR (DC_IOC, 36, long   )
#define DC_INTEOF      _IO  (DC_IOC, 40         )

#define DC_USERST      _IO  (DC_IOC, 80         )

#endif /* DC_H */

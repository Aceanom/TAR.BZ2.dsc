/*
    commander -- DAQ main control program
     (see "crashm.h" for available commands)
*/

#include <sys/types.h>
#include <sys/ipc.h>
#include <sys/shm.h>
#include <sys/sem.h>
#include <sys/wait.h>
#include <sys/stat.h>
#include <sys/ioctl.h>
#include <fcntl.h>
#include <unistd.h>
#include <stdlib.h>
#include <stdio.h>
#include <string.h>

#include "dc.h"
#define  COMMANDER
#include "crashm.h"

static int     shmid, semid;
static CRASHM *shmp;

static int     fd;
static DCCycle dcc;
static long    cnt;
static long    los;

static int     scaler_adr=0;
static int     scaler_ch =0;

#define gets(s) (fgets(s,sizeof(s),stdin)?s[strlen(s)-1]=0,s:NULL)
int main()
{
  char s[256]; int i;
  if ((shmid = shmget(SHMKEY, sizeof(CRASHM), IPC_CREAT|0600)) == -1)
    {puts("! Cannot create shared memory"); fflush(stdout); exit(2);}
  if ((semid = semget(SEMKEY, 1             , IPC_CREAT|0600)) == -1)
    {puts("! Cannot create semaphore"); fflush(stdout); exit(2);}
  shmp = (CRASHM *)shmat(shmid, 0, 0);
  shmp->acquire = 0;
  shmp->rawdat = 0; shmp->path[0] = 0; shmp->comment[0] = 0;
  shmp->rwcnt = 0; shmp->ancnt = 0; shmp->ercnt = 0;
  shmp->rp = 0; shmp->wp = 0;
  while (gets(s)) {
    switch (check_cmd(s)) {
    case CMD_INITIALIZE:
      fd = open(DEVICE, O_RDWR);
      if (ioctl(fd, DC_INITIAL, 0))
	{puts("# Crate is OFFLINE"); fflush(stdout);}
      ioctl(fd, DC_Z      , 0);
      ioctl(fd, DC_C      , 0);
      ioctl(fd, DC_I      , 1); /* inhibit scalers */
      ioctl(fd, DC_INTCLR , 0);
      break;
    case CMD_RESET:
      ioctl(fd, DC_INTCLR , 0);
      usleep(100000L);
      ioctl(fd, DC_C      , 0);
      shmp->rp = 0; shmp->wp = 0;
      shmp->rwcnt = 0; shmp->ancnt = 0; shmp->ercnt = 0;
      break;
    case CMD_START:
      ioctl(fd, DC_I      , 0); /* activate scalers */
      ioctl(fd, DC_INTON  , 0);
      shmp->acquire = 1;
      break;
    case CMD_STOP:
      ioctl(fd, DC_INTOFF , 0);
      ioctl(fd, DC_I      , 1); /* inhibit scalers */
      shmp->acquire = 0;
      break;
    case CMD_OPEN:
      gets(shmp->path);
      gets(shmp->comment);
      if (shmp->rawdat)
	{puts("# Close file before writing new one"); fflush(stdout);}
      break;
    case CMD_CLOSE:
      ioctl(fd, DC_INTEOF , 0); /* write EOF & wait for file really closed */
      usleep(200000L);
      ioctl(fd, DC_INTEOF , 0); /* confirm !? */
      for (i = 0; i < 20; i++) {if (!shmp->rawdat) break; usleep(100000L);}
      if (i == 20)
	puts("# Timeout, Recorder does not respond");
      else
	{shmp->path[0] = 0; puts("<< CLOSED >>");}
      fflush(stdout);
      break;
    case CMD_SCALER:
      if (scanf("%d %d\n", &scaler_adr, &scaler_ch) != 2) scaler_adr = 0;
      if ((scaler_adr > 24) | (scaler_adr < 0) |
	  (scaler_ch  > 16) | (scaler_ch  < 0))
	{puts("# Invalid Parameter for \"SCALER\""); fflush(stdout);}
      break;
    case CMD_COUNT:
      ioctl(fd, DC_INTCNT , &cnt);
      ioctl(fd, DC_INTLOS , &los);
      puts("<< COUNT >>");
      printf("%ld %ld %ld %ld %ld\n",
	     cnt, los, shmp->rwcnt, shmp->ancnt, shmp->ercnt);
      if (scaler_adr && scaler_ch) {
	printf("<< SCALER >>\n%d\n", scaler_ch);
	dcc.n = scaler_adr; dcc.f = 0;
	for (dcc.a = 0; dcc.a < scaler_ch; dcc.a++) {
	  ioctl(fd, DC_CYCLE, &dcc);
	  printf("%ld\n", dcc.data);
	}
      }
      fflush(stdout);
      break;
    case CMD_EXIT:
      goto EXIT;
    default:
      printf("# Illigal Command (%s).\n", s);
      fflush(stdout);
      break;
    }
  }
 EXIT:
  close(fd);
  shmdt((char *)shmp);
  shmctl(shmid, IPC_RMID, 0);
  semctl(semid, 0, IPC_RMID, 0);
  exit(0);
}

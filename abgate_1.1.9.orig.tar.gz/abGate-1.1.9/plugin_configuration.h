#define KNOB_PNG (const char *)("/usr/lib/lv2/abGate.lv2/knob.png")
#define BYPASS_ON_PNG (const char *)("/usr/lib/lv2/abGate.lv2/bypass_on.png")
#define BYPASS_OFF_PNG (const char *)("/usr/lib/lv2/abGate.lv2/bypass_off.png")
#define BACKGROUND_PNG (const char *)("/usr/lib/lv2/abGate.lv2/background.png")

# Publishing aardvark-dns crate to crates.io
### Steps
* Make sure you have already done `cargo login` on your current session with a valid token.
* `cd aardvark-dns`
* Git checkout the version which you want to publish.
* `make crate-publish`
* New version should be reflected here: https://crates.io/crates/aardvark-dns/versions

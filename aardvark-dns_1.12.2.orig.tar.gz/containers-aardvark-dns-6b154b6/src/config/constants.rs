pub static AARDVARK_PID_FILE: &str = "aardvark.pid";
pub static INTERNAL_SUFFIX: &str = "%int";

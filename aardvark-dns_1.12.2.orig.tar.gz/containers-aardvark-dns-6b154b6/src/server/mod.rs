// Serve DNS requests on the given bind addresses.
pub mod serve;

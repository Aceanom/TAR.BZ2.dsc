"""
AAFigure directive for reStructuredText.

This is open source software under the BSD license. See LICENSE.txt for more
details.
"""

from aafigure import process, render, UnsupportedFormatError, AsciiArtImage

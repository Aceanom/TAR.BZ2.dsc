#ifndef MENU_H
#define MENU_H

#include "Main.h"

void showSettings();
void showAbout();

#endif

#ifndef ICONS_H
#define ICONS_H

#include "Main.h"

int selectIcon();

#endif

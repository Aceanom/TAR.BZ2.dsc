#ifndef SPLASH_H
#define SPLASH_H

#include "Main.h"

void showSplashScreen();
void showIntro();

#endif

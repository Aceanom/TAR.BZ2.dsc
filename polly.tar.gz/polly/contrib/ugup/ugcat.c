#include <stdio.h>
#include <string.h>
#define LLINE 256

int main(int argc, char *argv[])
{
  int first = 1, pages = 0;
  int i, prolog;
  FILE *fd;
  char line[LLINE];
  for (i = 1; i < argc; i++) {
    prolog = 1;
    if ((fd = fopen(argv[i], "r")) == NULL)
      {fprintf(stderr, "File open error (%s).\n", argv[i]); exit(2);}
    while (fgets(line, LLINE, fd) != NULL) {
      if (strcmp(line, "%%Trailer\n") == 0) break;
      if (first || !prolog) {
	if (strncmp(line, "%%Page: ",8) == 0)
	  {pages++; printf("%%%%Page: %d %d\n", pages, pages);}
	else
	  fputs(line, stdout);
      }
      if (strcmp(line, "%%EndProlog\n") == 0) prolog = 0;
    }
    fclose(fd);
    first = 0;
  }
  printf("%%%%Trailer\n%%%%Pages: %d\n", pages);
}

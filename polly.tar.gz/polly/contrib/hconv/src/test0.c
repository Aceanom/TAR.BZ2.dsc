#include <stdio.h>

int main()
{
  int  i,buf[1000000];
  for (;;) {
    fread(buf,sizeof(int),8,stdin);
    if (feof(stdin)) break;
    for (i=0; i<8; i++) printf("%8d",buf[i]); puts("");
    fread(buf,sizeof(int),buf[3]+2,stdin);
  }
  return 0;
}

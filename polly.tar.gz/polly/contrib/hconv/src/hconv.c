#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <errno.h>
#ifdef    Linux
#include <getopt.h>
#endif /* Linux */
#ifdef    AIX
// Nothing special needed.
#endif /* AIX   */

#define uint unsigned int
#define SINT sizeof(int)
#define SDBL sizeof(double)

#define RDBLK(n) \
if ( fread(s,SINT,n+2,fi)!=n+2 ||\
     s[0]!=s[n+1] ||\
     (swap(&s[0],&d[0],SINT),(s[0]!=n*SINT&&d[0]!=n*SINT)) ) {\
if (!feof(fi)) {fprintf(stderr,"File read error\n"); status=2;}\
break;}

#define WRBLK(n) \
if (fwrite(d,SINT,n+2,fo)!=n+2) \
    {fprintf(stderr,"File write error\n"); status=2; break;}

void swap(void *s0, void *d0, int n)
{
  char *s=(char *)s0, *d=(char *)d0;
  int   i;
  for (i=0; i<n; i++) d[i]=s[n-i-1];
}
#define IntBlkSWAP(i1,i2,ofs) \
for (i=i1; i<=i2; i++ ) swap(&s[ofs+i], &d[ofs+i], SINT)
#define DblBlkSWAP(i1,i2,ofs) \
for (i=i1; i<=i2; i+=2) swap(&s[ofs+i], &d[ofs+i], SDBL)
#define WrdBlkSWAP(i1,i2,ofs) \
for (i=i1; i<=i2; i++ ) swab(&s[ofs+i], &d[ofs+i], SINT)
#define BytBlkSWAP(i1,i2,ofs) \
memcpy(&d[ofs+i1],&s[ofs+i1],(i2-(i1)+1)*SINT)

#define SETVAL(a,v) if (export) a=v; else swap(&v,&a,SINT)

void usage(char *cmd)
{
  fprintf(stderr,
	  "\nConvert a 'pollyanna' histogram file to another endian,\n"
	  "automatically detecting the mode of import or export.\n"
	  "\nUsage: %s [option] [infile [outfile]]\n\n"
	  "\toption:\t-d[lvl]\tdebug-level (0..2, default=0)\n"
	  "\t\t\t0 = no info.\n"
	  "\t\t\t1 = ID, dim & titles\n"
	  "\t\t\t2 = ID, dim & node-info.\n"
	  "\t\t-h\tshow this message\n\n"
	  "Files written to stdout (read from stdin) "
	  "if outfile (infile) not given.\n\n", cmd);
}

int main(int argc, char *argv[])
{
  FILE  *fi=stdin, *fo=stdout;
  int    bufwrd=1000000;  // default 4MB
# define BUFSIZE (bufwrd+2)*SINT
  uint  *s=malloc(BUFSIZE), *d=malloc(BUFSIZE);
  int    c, status=0, export=-1, DEBUG=0;

  while ((c=getopt(argc,argv,"d:h"))!=-1)
    switch (c) {
    case 'd': DEBUG=atoi(optarg); break;
    case 'h': usage(argv[0]); return 0;
    default : usage(argv[0]); return 2;
    }
  if (argc-optind>1)
    if ((fo=fopen(argv[optind+1],"w"))==NULL)
      {fprintf(stderr,"%s (%s)\n",strerror(errno), argv[optind+1]); return 2;}
  if (argc-optind>0)
    if ((fi=fopen(argv[optind  ],"r"))==NULL)
      {fprintf(stderr,"%s (%s)\n",strerror(errno), argv[optind  ]); return 2;}

  for (;;) {
    int  i, k, nwrd, MPARM, MSTAT, MBINS, MTITL, MDISP, MUSER, NDIM;
    //
    // header
    //
    RDBLK(6);
    if (export<0)
      if (export=(s[0]==6*SINT))
	fputs("Export a file; home => target CPU\n",stderr);
      else
	fputs("Import a file; target => home CPU\n",stderr);
    SETVAL(nwrd , s[3]);
    IntBlkSWAP( 1, 8, -1);
    WRBLK(6);
    //
    // node contents
    //
    if (nwrd>bufwrd)
      {bufwrd=nwrd; free(s); free(d); s=malloc(BUFSIZE); d=malloc(BUFSIZE);}
    memset(d, 0, BUFSIZE);
    RDBLK(nwrd);
    // block length
    swap(&s[0     ], &d[0     ], SINT);
    swap(&s[nwrd+1], &d[nwrd+1], SINT);
    // control block
    IntBlkSWAP( 1,  5,     0);
    BytBlkSWAP( 6,  6,     0); // A4ID
    IntBlkSWAP( 7, 15,     0);
    SETVAL(NDIM , s[ 5]);
    // parameter block
    SETVAL(MPARM, s[10]);
    IntBlkSWAP( 1, 18, MPARM);
    // statistics block
    SETVAL(MSTAT, s[11]);
    if (MSTAT) {
      IntBlkSWAP( 1,  6, MSTAT);
      DblBlkSWAP( 7, 14, MSTAT);
      if (NDIM==2) {
	IntBlkSWAP(15, 20, MSTAT);
	DblBlkSWAP(21, 26, MSTAT);
      }
    }
    // histogram bins block
    SETVAL(MBINS, s[12]);
    if (MBINS) {
      int    IMS,NBIN,KBIN;
      SETVAL(IMS  , s[MPARM+1]);
      SETVAL(NBIN , s[MPARM+2]);
      KBIN = NBIN - (NDIM!=2?3:9);
      switch (IMS) {
      case  1: // L*1 : 1*1
      case 11: // EF1 : 1*2
      case 14: // AS1 : 1*2
	BytBlkSWAP( 1, KBIN, MBINS); break;
      case  2: // I*2 : 2*1
      case 10: // EF2 : 2*2
      case 13: // AS2 : 2*2
	WrdBlkSWAP( 1, KBIN, MBINS); break;
      case  3: // I*4 : 4*1
      case  4: // R*4 : 4*1
      case  5: // E*4 : 4*2
      case  6: // M*4 : 4*2
      case  7: // WEV : 4*2
      case  8: // A*4 : 4*3
      case  9: // EFF : 4*2
      case 12: // ASM : 4*2
	IntBlkSWAP( 1, KBIN, MBINS); break;
      default:
	fprintf(stderr,"Invalid storage type (%d)\n",IMS);
	status=2; break;
      }
      IntBlkSWAP(KBIN+1, NBIN, MBINS);
    }
    // display parameter block
    SETVAL(MDISP, s[14]);
    k = (NDIM!=2 ? 15 : 21);
    IntBlkSWAP(   1, k   , MDISP);
    IntBlkSWAP(k+ 1, k+ 4, MDISP);      // bit  param. (OPT= 1..32)
    BytBlkSWAP(k+ 5, k+10, MDISP);      // byte param. (OPT=33..56)
    WrdBlkSWAP(k+11, k+16, MDISP);      // hwrd param. (OPT=57..68)
    // title block
    SETVAL(MTITL, s[13]);
    BytBlkSWAP( 1, MDISP-MTITL, MTITL);
    // user block
    SETVAL(MUSER, s[15]);
    if (MUSER) {
      BytBlkSWAP( 1,    16, MUSER);
      IntBlkSWAP(17, MUSER, MUSER);
    }
    WRBLK(nwrd);
    if (DEBUG) {
      int  ID;
      SETVAL(ID,s[4]);
      fprintf(stderr,"ID=%4d NDIM=%d ",ID,NDIM);
      if (DEBUG==1) {
	for (i=0; i<80; i++)
	  if (*((char*)&s[MTITL+1]+i)=='@') break;
	  else fprintf(stderr,"%c",*((char*)&s[MTITL+1]+i));
	fputs("@\n",stderr);
      } else
	fprintf(stderr,
		"MPARM=%d MSTAT=%d MBINS=%d MTITL=%d MDISP=%d MUSER=%d\n",
		MPARM,MSTAT,MBINS,MTITL,MDISP,MUSER);
    }
  }

  fclose(fi); free(s);
  fclose(fo); free(d);

  return status;
}

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>

#define uint unsigned int
#define SINT sizeof(int)
#define SDBL sizeof(double)

#define RDBLK(n) \
if (fread(s,SINT,n+2,fi)!=n+2 ||\
    s[0  ]!=n*SINT ||\
    s[n+1]!=n*SINT ) {\
    if (!feof(fi)) {fprintf(stderr,"File read error\n"); status=2;}\
break;}

#define WRBLK(n) \
if (fwrite(d,SINT,n+2,fo)!=n+2) \
    {fprintf(stderr,"File write error\n"); status=2; break;}

#define MPARM s[10]      /* offset for parameter block             */
#define MSTAT s[11]      /* offset for statistics block, 0 if none */
#define MBINS s[12]      /* offset for histogram bins, 0 if none   */
#define MTITL s[13]      /* offset for title block                 */
#define MDISP s[14]      /* offset for display options block       */
#define MUSER s[15]      /* offset for user block, 0 if none       */
#define NDIM  s[ 5]      /* dimension (0,1,2) */
#define NUSER s[ 8]      /* size of user block */
#define IMS   s[MPARM+1] /* mode of storage */
#define NBIN  s[MPARM+2] /* words for bin storage */
#define M2R(i) *(float*)&s[i]

void swap(void *s0, void *d0, int n)
{
  char *s=(char *)s0, *d=(char *)d0;
  int   i;
  for (i=0; i<n; i++) d[i]=s[n-i-1];
}
#define IntBlkSWAP(i1,i2,ofs) \
for (i=i1; i<=i2; i++ ) swap(&s[ofs+i], &d[ofs+i], SINT)
#define DblBlkSWAP(i1,i2,ofs) \
for (i=i1; i<=i2; i+=2) swap(&s[ofs+i], &d[ofs+i], SDBL)
#define WrdBlkSWAP(i1,i2,ofs) \
for (i=i1; i<=i2; i++ ) swab(&s[ofs+i], &d[ofs+i], SINT)
#define BytBlkSWAP(i1,i2,ofs) \
memcpy(&d[ofs+i1],&s[ofs+i1],(i2-(i1)+1)*SINT)

int main(int argc, char *argv[])
{
  FILE  *fi,*fo;
  int    bufwrd=1000000;  // default 4MB
# define BUFSIZE (bufwrd+2)*SINT
  uint  *s=malloc(BUFSIZE), *d=malloc(BUFSIZE);
  int    i,k,ID,nwrd,status=0;
  int    DEBUG=2;

  fi=fopen(argv[1],"r");
  fo=fopen("hst/conv.hst","w");

  for (;;) {
    //
    // header
    //
    RDBLK(6); ID=s[1]; nwrd=s[3];
    if (DEBUG==2)
      {printf("HDR :"); for (i=0; i<8; i++) printf("%8d",s[i]); puts("");}
    IntBlkSWAP( 0, 7, 0);
    for (i=0; i<6+2; i++) swap(&s[i], &d[i], SINT);
    WRBLK(6);
    //
    // node contents
    //
    if (nwrd>bufwrd)
      {bufwrd=nwrd; free(s); free(d); s=malloc(BUFSIZE); d=malloc(BUFSIZE);}
    memset(d, 0, BUFSIZE);
    RDBLK(nwrd);
    if (DEBUG==2)
      printf("NODE:%8d%8d%8d\n",s[0],s[nwrd+1],ID);
    if (DEBUG) {
      printf("ID=%4d ND=%1d MS=%2d NBIN=%d\n'",ID,NDIM,IMS,NBIN);
      for (i=0; i<80; i++)
	if (*((char*)&s[MTITL+1]+i)=='@') break;
	else printf("%c",*((char*)&s[MTITL+1]+i)); puts("@'");
      printf("  xb=%d xl=%g xw=%g xu=%g",
	     s[MPARM+5],M2R(MPARM+ 6),M2R(MPARM+ 7),M2R(MPARM+ 8));
      if (NDIM==2)
      printf(", yb=%d yl=%g yw=%g yu=%g",
	     s[MPARM+9],M2R(MPARM+10),M2R(MPARM+11),M2R(MPARM+12));
      puts("");
      printf("  MPARM=%d MSTAT=%d MBINS=%d MTITL=%d MDISP=%d MUSER=%d\n",
	     MPARM,MSTAT,MBINS,MTITL,MDISP,MUSER);
      printf("  size of node = %d\n",s[7]);
    }
    swap(&s[0     ], &d[0     ], SINT); // block length
    swap(&s[nwrd+1], &d[nwrd+1], SINT);
    IntBlkSWAP( 1,  5,     0);          // control block
    BytBlkSWAP( 6,  6,     0);          //       A4ID
    IntBlkSWAP( 7, 15,     0);
    IntBlkSWAP( 1, 18, MPARM);          // parameter block
    if (MSTAT) {                        // statistics block
      IntBlkSWAP( 1,  6, MSTAT);
      DblBlkSWAP( 7, 14, MSTAT);
      if (NDIM==2) {
	IntBlkSWAP(15, 20, MSTAT);
	DblBlkSWAP(21, 26, MSTAT);
      }
    }
    if (MBINS) {                        // histogram bins block
      int    KBIN=NBIN-(NDIM!=2?3:9);
      //printf("KBIN=%d\n",KBIN);
      switch (IMS) {
      case  1: // L*1 : 1*1
      case 11: // EF1 : 1*2
      case 14: // AS1 : 1*2
	BytBlkSWAP( 1, KBIN, MBINS); break;
      case  2: // I*2 : 2*1
      case 10: // EF2 : 2*2
      case 13: // AS2 : 2*2
	WrdBlkSWAP( 1, KBIN, MBINS); break;
      case  3: // I*4 : 4*1
      case  4: // R*4 : 4*1
      case  5: // E*4 : 4*2
      case  6: // M*4 : 4*2
      case  7: // WEV : 4*2
      case  8: // A*4 : 4*3
      case  9: // EFF : 4*2
      case 12: // ASM : 4*2
	IntBlkSWAP( 1, KBIN, MBINS); break;
      default:
	fprintf(stderr,"Invalid storage type (%d)\n",IMS);
	status=2; break;
      }
      IntBlkSWAP(KBIN+1, NBIN, MBINS);
    }
    BytBlkSWAP( 1, MDISP-MTITL, MTITL); // title block
    k = (NDIM!=2 ? 15 : 21);
    IntBlkSWAP(   1, k   , MDISP);      // display parameter block
    IntBlkSWAP(k+ 1, k+ 4, MDISP);      // bit  param. (OPT= 1..32)
    BytBlkSWAP(k+ 5, k+10, MDISP);      // byte param. (OPT=33..56)
    WrdBlkSWAP(k+11, k+16, MDISP);      // hwrd param. (OPT=57..68)
    if (MUSER) {                        // user block
      //printf("NUSER=%d\n",NUSER);
      BytBlkSWAP( 1,    16, MUSER);
      IntBlkSWAP(17, MUSER, MUSER);
    }
    WRBLK(nwrd);
  }
  fclose(fi);
  fclose(fo);
  free(s); free(d);
  return status;
}

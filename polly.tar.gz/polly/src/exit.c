int exit_(status)
int      *status;
{
  exit(*status);
}

#!/bin/csh -f
foreach i (*.F) 
  grep "/hcom/" $i > /dev/null
  @ found = $status == 0
  if ($found) then
    echo "\n"$i
    grep -n "\(nhcom\|nodend\|node1\|hshloc\|hshcnt\|sctloc\|m *(.*hshloc.*)\|m *(.*nod.* *+ *1 *)\|m *(.*nod.* *+ *3 *)\)" $i
  endif
end

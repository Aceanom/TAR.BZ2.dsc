#! /bin/sh

if [[ `echo 'puts $tcl_version' | tclsh` > 8.3 ]]
then
    echo Found tk-version on this system is greater than 8.3, 
    echo thus automatically update tcl-sources to fit to it, 
    echo which use the namespace 'tk' for private procedures, 
    echo i.e. by converting \"tk[A-Z]*\" to \"tk::[A-Z]*\" .  
    echo
    for i in polly *.tcl
    do
	sed -e 's/tk\([A-Z][A-Za-z]\+\)/tk::\1/g' $i > ../$i
	touch -r $i ../$i
	echo \n=== $i ===\n
	diff $i ../$i
    done
    chmod +x ../polly
else
    echo Found tk-version is on this system less than or equal to 8.3, 
    echo thus copy original tcl-sources for tk4.2 - tk8.3 .  
    echo
    cp -pf polly *.tcl ..
fi


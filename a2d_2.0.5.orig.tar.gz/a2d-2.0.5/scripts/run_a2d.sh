#!/bin/sh

python3 -m a2d.runscripts

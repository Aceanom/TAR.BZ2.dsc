#!/bin/bash

# Path
URL="http://localhost:9333"

# Open the determined URL
xdg-open "$URL"

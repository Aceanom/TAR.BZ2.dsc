#### MIT License

Copyright (c) 2023 NGC2023

a2d/static/bootstrap/css/cdn_bootstrap_5-3_min.css  
Copyright: 2011-2023 The Bootstrap Authors  
License: MIT

a2d/static/bootstrap/js/cdn_bootstrap_5-3.js  
Copyright: 2011-2023 The Bootstrap Authors  
License: MIT

Permission is hereby granted, free of charge, to any person obtaining a copy of
this software and associated documentation files (the "Software"), to deal in
the Software without restriction, including without limitation the rights to
use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of
the Software, and to permit persons to whom the Software is furnished to do so,
subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS
FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR
COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER
IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN
CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.

#### CC-BY-3.0 License

a2d/static/bootstrap/css/bootstrap_docs_5-3.css  
Copyright: 2011-2023 The Bootstrap Authors  
License: CC-BY-3.0

a2d/static/bootstrap/js/bootstrap_5-3_mode.js  
Copyright: 2011-2023 The Bootstrap Authors  
License: CC-BY-3.0

We have made modifications to a portion of the Bootstrap code to suit our
project's requirements. These minor modifications enable the Color mode toggler
from Bootstrap's docs to work with a2d. Licensed under the Creative Commons
Attribution 3.0 Unported License. For details, see
[https://creativecommons.org/licenses/by/3.0/](https://creativecommons.org/licenses/by/3.0/).
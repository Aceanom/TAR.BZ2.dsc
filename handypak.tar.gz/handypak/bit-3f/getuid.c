#include <unistd.h>

int getuid_()
{
  return (int)getuid();
}

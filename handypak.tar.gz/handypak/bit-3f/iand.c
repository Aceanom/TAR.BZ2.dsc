unsigned iand_( unsigned *a, unsigned *b ) { return ( *a & *b ); }

#include <stddef.h>
#include <stdarg.h>
#include <f2c.h>

void sub_(int *arg, ...)
/* integer *arg; */
{
  va_list ap;
  int  *ival, *i, *i1, *i2, *i3, *i4;

  i = (i1 = arg);
  va_start(ap, arg);
  printf("arg 1 = %8.8X  %d  %8.8X\n", i, *i, ap);
  if (++i != (i2 = va_arg(ap, int)))
    test1_(i1);
  else {
  printf("arg 2 = %8.8X  %d  %8.8X\n", i, *i, ap);
  if (++i != (i3 = va_arg(ap, int)))
    test2_(i1, i2);
  else {
  printf("arg 3 = %8.8X  %d  %8.8X\n", i, *i, ap);
  if (++i != (i4 = va_arg(ap, int)))
    test3_(i1, i2, i3);
  else {
  printf("arg 4 = %8.8X  %d  %8.8X\n", i, *i, ap);
  test4_(i1, i2, i3, i4);
  }}}

  va_end(ap);
}

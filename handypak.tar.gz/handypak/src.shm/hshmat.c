#include <sys/types.h>
#include <sys/ipc.h>
#include <sys/shm.h>
#include <stdio.h>
#include <errno.h>

static int    shmid;
static char  *shmadr;
static struct shmid_ds buf;

int hshmat_(int *key, int *isize, int *iflag, int *icode)
{
  int size=*isize*4, flag;
#ifdef SHMMAX
  if (size > SHMMAX) {*icode = SHMMAX / 4; return -1;}
#else
  /* I don't know how to get shminfo.shmmax ... */
#endif
  flag = *iflag | IPC_CREAT;
  shmid = shmget(*key, size, flag|IPC_EXCL);
  if (shmid != -1) { /* New segment */
    *icode = 0;
    shmadr = shmat(shmid, 0, 0);
    return (int)shmadr;
  } else {
    *icode = 1;
    if (errno == EEXIST) { /* Segment already exists */
      shmid = shmget(*key, size, flag);
      if (shmid == -1) {
        if (errno == EACCES) *icode = 13;
        return -1;
      } else {
        shmctl(shmid, IPC_STAT, &buf);
        *isize = buf.shm_segsz / 4;
	shmadr = shmat(shmid, 0, 0);
        return (int)shmadr;
      }
    }
    return -1;
  }
}

void hfreem_()
{
  shmctl(shmid, IPC_RMID, &buf);
  shmdt(shmadr);
}

#!/bin/csh -f
foreach i (*.F) 
  grep hcom.INC $i > /dev/null
  @ found = $status == 0
  if ($found) then
    echo "\n"$i
    grep -n "\(NHCOM\|NODEND\|NODE1\|HSHLOC\|HSHCNT\|SCTLOC\|M *(.*HSHLOC.*)\|M *(.*NOD.* *+ *1 *)\|M *(.*NOD.* *+ *3 *)\)" $i
  endif
end

#!/bin/csh -f
foreach i (*.F)
  echo "\n$i"
  gcc -E $i | grep -n "\(NNODES\|NHCOM\|NODEND\|NODE1\|HSHLOC\|HSHCNT\|HSHLEN\|SCTLOC\|SCTLEN\|SCTUNI\|SCTUSE\|SCTREC\|SCTTOT\|SCTMAX\)"
end

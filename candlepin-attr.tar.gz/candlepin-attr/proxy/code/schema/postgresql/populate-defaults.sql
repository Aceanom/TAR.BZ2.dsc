insert into cp_consumer_type(id, label) values(NEXTVAL('SEQ_CONSUMER_TYPE'), 'system');

package org.fedoraproject.candlepin.model;

import java.io.Serializable;

public interface Persisted {
    public Serializable getId();
}

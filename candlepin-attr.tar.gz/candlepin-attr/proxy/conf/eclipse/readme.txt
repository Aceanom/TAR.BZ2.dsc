Don't forget the following hidden files located in this directory:

.externalToolBuilders/
.classpath
.project

